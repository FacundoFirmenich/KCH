#!/usr/bin/env python3
"""CSC-KCH v12 cross-runner transparent quorum research gate.

This file is intentionally self-contained for GitHub Actions conformance. It is
not a production runtime. Embedded Ed25519 keys are TEST-ONLY fixtures.
"""
from __future__ import annotations

import argparse
import base64
import copy
import hashlib
import json
import sqlite3
import subprocess
import tempfile
import unittest
from pathlib import Path
from typing import Any, Iterable, Sequence

PRIVATE_KEYS = {
    "w1": """-----BEGIN PRIVATE KEY-----\nMC4CAQAwBQYDK2VwBCIEIM7wcSKvb12z/waszghIS8NXtdyMyajV3AKnGR7xAwVc\n-----END PRIVATE KEY-----\n""",
    "w2": """-----BEGIN PRIVATE KEY-----\nMC4CAQAwBQYDK2VwBCIEIIxuINfghwulnkV40pNHDNhoB+RA+KdXys9Y4FAuW5LV\n-----END PRIVATE KEY-----\n""",
    "w3": """-----BEGIN PRIVATE KEY-----\nMC4CAQAwBQYDK2VwBCIEIK8IiQMpi9vZ0n1ppDAaViY1hwHTUKjXJcswqL2xQGRJ\n-----END PRIVATE KEY-----\n""",
}
PUBLIC_KEYS = {
    "w1": """-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAN2iV0FsqzhhtY/Y5NHzr4WlRKjH9B3KCZz9hQ/kgtmE=\n-----END PUBLIC KEY-----\n""",
    "w2": """-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAeNtTLJWQVn542Mb3LH7kjVu8ar0hHgr1cqdNQbz00IA=\n-----END PUBLIC KEY-----\n""",
    "w3": """-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAI1Ak11bey4bDVlfe5FeFN//craLWoJLaoR13kIqGeAw=\n-----END PUBLIC KEY-----\n""",
}
TRUST_DOMAINS = {"w1": "domain-alpha", "w2": "domain-beta", "w3": "domain-gamma"}
REQUIRED_LEAF_TYPES = {
    "policy_support_vectors", "key_registry", "transition_request",
    "proof_bundle", "lease", "attestation", "reservation_intent",
}
BINDING_FIELDS = (
    "epoch", "transition_hash", "lease_hash", "attestation_hash",
    "proof_bundle_hash", "policy_support_vectors_sha256",
    "checkpoint_root", "checkpoint_tree_size", "reservation_hash",
)


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def sha256_hex(value: bytes | str | Any) -> str:
    if isinstance(value, bytes): payload = value
    elif isinstance(value, str): payload = value.encode()
    else: payload = canonical_json(value)
    return hashlib.sha256(payload).hexdigest()


def leaf_hash(value: Any) -> str:
    return hashlib.sha256(b"\x00" + canonical_json(value)).hexdigest()


def node_hash(left: str, right: str) -> str:
    return hashlib.sha256(b"\x01" + bytes.fromhex(left) + bytes.fromhex(right)).hexdigest()


def merkle_levels(leaves: Sequence[Any]) -> list[list[str]]:
    if not leaves: return [[hashlib.sha256(b"").hexdigest()]]
    levels = [[leaf_hash(item) for item in leaves]]
    while len(levels[-1]) > 1:
        current = levels[-1]; nxt=[]
        for index in range(0, len(current), 2):
            left=current[index]; right=current[index+1] if index+1<len(current) else left
            nxt.append(node_hash(left,right))
        levels.append(nxt)
    return levels


def merkle_root(leaves: Sequence[Any]) -> str:
    return merkle_levels(leaves)[-1][0]


def inclusion_proof(leaves: Sequence[Any], index: int) -> list[dict[str,str]]:
    if index < 0 or index >= len(leaves): raise IndexError(index)
    proof=[]; cursor=index
    for level in merkle_levels(leaves)[:-1]:
        sibling_index=cursor^1
        sibling=level[sibling_index] if sibling_index<len(level) else level[cursor]
        proof.append({"side":"left" if sibling_index<cursor else "right","hash":sibling})
        cursor//=2
    return proof


def verify_inclusion(leaf: Any, index: int, tree_size: int, proof: Sequence[dict[str,str]], expected_root: str) -> bool:
    if tree_size<=0 or index<0 or index>=tree_size: return False
    current=leaf_hash(leaf)
    for item in proof:
        if item["side"]=="left": current=node_hash(item["hash"],current)
        elif item["side"]=="right": current=node_hash(current,item["hash"])
        else: return False
    return current==expected_root


def _with_key_file(pem: str, suffix: str):
    class Context:
        def __enter__(self):
            self.directory=tempfile.TemporaryDirectory(); self.path=Path(self.directory.name)/suffix
            self.path.write_text(pem,encoding="ascii"); return self.path
        def __exit__(self,*args): self.directory.cleanup()
    return Context()


def public_fingerprint(witness_id: str) -> str:
    with _with_key_file(PUBLIC_KEYS[witness_id],"public.pem") as path:
        der=subprocess.check_output(["openssl","pkey","-pubin","-in",str(path),"-outform","DER"])
    return sha256_hex(der)


def sign(witness_id: str, payload: bytes) -> str:
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary); message=root/"message.bin"; signature=root/"signature.bin"; key=root/"private.pem"
        message.write_bytes(payload); key.write_text(PRIVATE_KEYS[witness_id],encoding="ascii")
        subprocess.run(["openssl","pkeyutl","-sign","-rawin","-inkey",str(key),"-in",str(message),"-out",str(signature)],check=True,capture_output=True)
        return base64.b64encode(signature.read_bytes()).decode("ascii")


def verify_signature(witness_id: str, payload: bytes, signature_b64: str) -> bool:
    try:
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary); message=root/"message.bin"; signature=root/"signature.bin"; key=root/"public.pem"
            message.write_bytes(payload); signature.write_bytes(base64.b64decode(signature_b64,validate=True)); key.write_text(PUBLIC_KEYS[witness_id],encoding="ascii")
            result=subprocess.run(["openssl","pkeyutl","-verify","-rawin","-pubin","-inkey",str(key),"-in",str(message),"-sigfile",str(signature)],capture_output=True)
            return result.returncode==0
    except Exception:
        return False


def binding(prepared: dict[str,Any]) -> dict[str,Any]:
    return {
        "epoch":prepared["epoch"], "transition_hash":prepared["transition_hash"],
        "lease_hash":prepared["lease_hash"], "attestation_hash":prepared["attestation_hash"],
        "proof_bundle_hash":prepared["proof_bundle_hash"],
        "policy_support_vectors_sha256":prepared["policy_support_vectors_sha256"],
        "checkpoint_root":prepared["checkpoint"]["root"],
        "checkpoint_tree_size":prepared["checkpoint"]["tree_size"],
        "reservation_hash":prepared["reservation_hash"],
    }


def validate_prepared(prepared: dict[str,Any]) -> None:
    leaves=prepared["transparency_leaves"]; checkpoint=prepared["checkpoint"]
    if checkpoint["tree_size"]!=len(leaves): raise ValueError("checkpoint tree size mismatch")
    if merkle_root(leaves)!=checkpoint["root"]: raise ValueError("checkpoint root mismatch")
    for record in prepared["inclusion_records"]:
        if not verify_inclusion(record["leaf"],int(record["index"]),int(checkpoint["tree_size"]),record["proof"],checkpoint["root"]):
            raise ValueError("invalid inclusion proof")
    for object_key,hash_key in (("transition_request","transition_hash"),("proof_bundle","proof_bundle_hash"),("lease","lease_hash"),("attestation","attestation_hash"),("reservation_intent","reservation_hash")):
        if sha256_hex(prepared[object_key])!=prepared[hash_key]: raise ValueError(f"{object_key} hash mismatch")
    leaves_by_type={leaf.get("type"):leaf for leaf in leaves}
    if set(leaves_by_type)!=REQUIRED_LEAF_TYPES: raise ValueError("unexpected or duplicate transparency leaf types")
    policy_hash=prepared["policy_support_vectors_sha256"]
    if leaves_by_type["policy_support_vectors"].get("sha256")!=policy_hash: raise ValueError("policy vector hash is not committed")
    if prepared["transition_request"].get("policy_support_vectors_sha256")!=policy_hash: raise ValueError("transition policy hash mismatch")
    if prepared["proof_bundle"].get("policy_support_vectors_sha256")!=policy_hash: raise ValueError("proof policy hash mismatch")
    if leaves_by_type["key_registry"].get("value")!=prepared["key_registry"]: raise ValueError("key registry leaf mismatch")
    for leaf_type,key in (("transition_request","transition_request"),("proof_bundle","proof_bundle"),("lease","lease"),("attestation","attestation"),("reservation_intent","reservation_intent")):
        if leaves_by_type[leaf_type].get("value")!=prepared[key]: raise ValueError(f"{leaf_type} leaf mismatch")
    if prepared["reservation_intent"].get("transition_hash")!=prepared["transition_hash"]: raise ValueError("reservation transition mismatch")
    if prepared["reservation_intent"].get("effect_id")!=prepared["transition_request"].get("effect_id"): raise ValueError("reservation effect mismatch")


def validate_registry(prepared: dict[str,Any], witness_id: str, trust_domain: str) -> None:
    matches=[item for item in prepared["key_registry"] if item["witness_id"]==witness_id]
    if len(matches)!=1: raise ValueError("witness missing or duplicated")
    item=matches[0]
    if item["status"]!="ACTIVE": raise ValueError("witness key inactive")
    if item["trust_domain"]!=trust_domain: raise ValueError("trust domain mismatch")
    if item["public_key_sha256"]!=public_fingerprint(witness_id): raise ValueError("public key mismatch")


def make_vote(prepared: dict[str,Any], witness_id: str, trust_domain: str, antirollback_floor: int=0) -> dict[str,Any]:
    validate_prepared(prepared); validate_registry(prepared,witness_id,trust_domain); bound=binding(prepared)
    if int(bound["checkpoint_tree_size"])<antirollback_floor: raise ValueError("checkpoint rollback")
    body={"schema":"CSC_KCH_V12_WITNESS_VOTE_V1","witness_id":witness_id,"trust_domain":trust_domain,"public_key_sha256":public_fingerprint(witness_id),"decision":"APPROVE",**bound}
    return {**body,"signature_b64":sign(witness_id,canonical_json(body)),"vote_hash":sha256_hex(body)}


def verify_vote(vote: dict[str,Any], prepared: dict[str,Any]) -> None:
    validate_prepared(prepared)
    for key,value in binding(prepared).items():
        if vote.get(key)!=value: raise ValueError(f"vote binding mismatch: {key}")
    witness_id=str(vote["witness_id"]); validate_registry(prepared,witness_id,str(vote["trust_domain"]))
    if vote.get("decision")!="APPROVE": raise ValueError("non-approve vote")
    body={key:value for key,value in vote.items() if key not in {"signature_b64","vote_hash"}}
    if sha256_hex(body)!=vote.get("vote_hash"): raise ValueError("vote hash mismatch")
    if not verify_signature(witness_id,canonical_json(body),str(vote["signature_b64"])): raise ValueError("invalid signature")


def aggregate_votes(prepared: dict[str,Any], votes: Sequence[dict[str,Any]], quorum: int=2) -> dict[str,Any]:
    validate_prepared(prepared)
    if len(votes)<quorum: raise ValueError("insufficient witness votes")
    ids=set(); domains=set()
    for vote in votes:
        verify_vote(vote,prepared); witness_id=str(vote["witness_id"])
        if witness_id in ids: raise ValueError("duplicate witness")
        ids.add(witness_id); domains.add(str(vote["trust_domain"]))
    if len(ids)<quorum: raise ValueError("quorum not met")
    if len(domains)<quorum: raise ValueError("trust-domain diversity not met")
    body={"schema":"CSC_KCH_V12_QUORUM_CERTIFICATE_V1","quorum":quorum,"witness_ids":sorted(ids),"trust_domains":sorted(domains),"vote_hashes":sorted(v["vote_hash"] for v in votes),**binding(prepared)}
    return {**body,"certificate_hash":sha256_hex(body)}


def detect_split_view(checkpoints: Iterable[dict[str,Any]]) -> None:
    by_size={}; highest={}
    for checkpoint in checkpoints:
        log_id=str(checkpoint["log_id"]); size=int(checkpoint["tree_size"]); root=str(checkpoint["root"]); key=(log_id,size)
        if key in by_size and by_size[key]!=root: raise ValueError("split view detected")
        by_size[key]=root
        if size<highest.get(log_id,0): raise ValueError("checkpoint rollback detected")
        highest[log_id]=max(size,highest.get(log_id,0))


def initialize_db(path: Path) -> None:
    connection=sqlite3.connect(path)
    try:
        connection.executescript("""PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS effects(effect_id TEXT PRIMARY KEY,payload_hash TEXT NOT NULL,status TEXT NOT NULL,receipt_json TEXT); CREATE TABLE IF NOT EXISTS counter(name TEXT PRIMARY KEY,value INTEGER NOT NULL); INSERT OR IGNORE INTO counter(name,value) VALUES('global',0);""")
        connection.commit()
    finally: connection.close()


def execute_once(db_path: Path, effect_id: str, payload: dict[str,Any], certificate: dict[str,Any], crash_after_commit: bool=False) -> dict[str,Any]:
    initialize_db(db_path); payload_hash=sha256_hex(payload); connection=sqlite3.connect(db_path)
    try:
        connection.execute("BEGIN IMMEDIATE")
        existing=connection.execute("SELECT payload_hash,status,receipt_json FROM effects WHERE effect_id=?",(effect_id,)).fetchone()
        if existing:
            if existing[0]!=payload_hash: raise ValueError("effect-id collision")
            if existing[1]=="COMMITTED" and existing[2]: connection.rollback(); return json.loads(existing[2])
            connection.rollback(); raise RuntimeError("intermediate effect state")
        connection.execute("INSERT INTO effects(effect_id,payload_hash,status) VALUES(?,?,?)",(effect_id,payload_hash,"PREPARED"))
        connection.execute("UPDATE counter SET value=value+1 WHERE name='global'")
        value=connection.execute("SELECT value FROM counter WHERE name='global'").fetchone()[0]
        receipt={"schema":"CSC_KCH_V12_EFFECT_RECEIPT_V1","effect_id":effect_id,"payload_hash":payload_hash,"counter_value":value,"quorum_certificate_hash":certificate["certificate_hash"],"checkpoint_root":certificate["checkpoint_root"],"reservation_hash":certificate["reservation_hash"]}
        connection.execute("UPDATE effects SET status='COMMITTED',receipt_json=? WHERE effect_id=?",(json.dumps(receipt,sort_keys=True),effect_id)); connection.commit()
        if crash_after_commit: raise RuntimeError("simulated crash after durable commit")
        return receipt
    finally: connection.close()


def recover_effect(db_path: Path, effect_id: str) -> dict[str,Any]:
    connection=sqlite3.connect(db_path)
    try:
        row=connection.execute("SELECT status,receipt_json FROM effects WHERE effect_id=?",(effect_id,)).fetchone()
        if not row or row[0]!="COMMITTED" or not row[1]: raise RuntimeError("effect is not durably committed")
        return json.loads(row[1])
    finally: connection.close()


def counter_value(db_path: Path) -> int:
    connection=sqlite3.connect(db_path)
    try: return int(connection.execute("SELECT value FROM counter WHERE name='global'").fetchone()[0])
    finally: connection.close()


def prepare(vectors: Path, output: Path, commit: str) -> dict[str,Any]:
    vectors_sha=sha256_hex(vectors.read_bytes())
    key_registry=[{"witness_id":wid,"trust_domain":TRUST_DOMAINS[wid],"public_key_sha256":public_fingerprint(wid),"status":"ACTIVE","epoch":12} for wid in ("w1","w2","w3")]
    transition={"schema":"PCGT_V12_TRANSITION_REQUEST_V1","transition_id":"pcgt-v12-cross-runner-demo","epoch":12,"generation":1,"principal":"research-runner","mission":"validate-transparent-quorum","action":"filesystem_counter_increment","effect_class":"NON_IDEMPOTENT_COUNTER","effect_id":sha256_hex("pcgt-v12-effect"),"policy_support_vectors_sha256":vectors_sha,"source_commit":commit}
    proof={"schema":"PCGT_V12_PROOF_BUNDLE_V1","identity":True,"jurisdiction":True,"cas_sufficiency":True,"authority":True,"lease":True,"qas_support":True,"receipt_required":True,"future_only":True,"policy_support_vectors_sha256":vectors_sha}
    lease={"schema":"PCGT_V12_LEASE_V1","lease_id":sha256_hex("pcgt-v12-lease"),"principal":transition["principal"],"mission":transition["mission"],"action":transition["action"],"effect_id":transition["effect_id"],"uses":1,"generation":1,"epoch":12}
    attestation={"schema":"PCGT_V12_SOFTWARE_ATTESTATION_V1","host_class":"github-actions-ephemeral-runner","adapter":"counter-adapter-v1","code_hash":sha256_hex("counter-adapter-v1"),"epoch":12,"claim_boundary":"software-only; not hardware attestation"}
    reservation={"schema":"PCGT_V12_RESERVATION_INTENT_V1","reservation_id":sha256_hex("pcgt-v12-reservation"),"transition_hash":sha256_hex(transition),"effect_id":transition["effect_id"],"epoch":12,"generation":1,"uses":1}
    leaves=[{"type":"policy_support_vectors","sha256":vectors_sha},{"type":"key_registry","value":key_registry},{"type":"transition_request","value":transition},{"type":"proof_bundle","value":proof},{"type":"lease","value":lease},{"type":"attestation","value":attestation},{"type":"reservation_intent","value":reservation}]
    root=merkle_root(leaves)
    prepared={"schema":"CSC_KCH_V12_PREPARED_BUNDLE_V1","epoch":12,"transition_request":transition,"transition_hash":sha256_hex(transition),"proof_bundle":proof,"proof_bundle_hash":sha256_hex(proof),"lease":lease,"lease_hash":sha256_hex(lease),"attestation":attestation,"attestation_hash":sha256_hex(attestation),"reservation_intent":reservation,"reservation_hash":sha256_hex(reservation),"policy_support_vectors_sha256":vectors_sha,"key_registry":key_registry,"transparency_leaves":leaves,"checkpoint":{"schema":"CSC_KCH_V12_CHECKPOINT_V1","log_id":"kch-v12-ci-log","tree_size":len(leaves),"root":root,"epoch":12},"inclusion_records":[{"index":i,"leaf":leaves[i],"proof":inclusion_proof(leaves,i)} for i in (0,1,2,6)]}
    output.parent.mkdir(parents=True,exist_ok=True); output.write_text(json.dumps(prepared,indent=2)); return prepared


def read_votes(directory: Path) -> tuple[list[dict[str,Any]],list[str]]:
    votes=[]; offline=[]
    for path in sorted(directory.glob("*.json")):
        item=json.loads(path.read_text())
        if item.get("status")=="OFFLINE": offline.append(item["witness_id"])
        elif item.get("signature_b64"): votes.append(item)
    return votes,offline


def cmd_prepare(args): print(json.dumps({"root":prepare(args.vectors,args.output,args.commit)["checkpoint"]["root"]},indent=2))
def cmd_witness(args):
    args.output.parent.mkdir(parents=True,exist_ok=True)
    if args.offline: item={"schema":"CSC_KCH_V12_OFFLINE_WITNESS_V1","witness_id":args.witness_id,"trust_domain":args.trust_domain,"status":"OFFLINE"}
    else: item=make_vote(json.loads(args.prepared.read_text()),args.witness_id,args.trust_domain,args.antirollback_floor)
    args.output.write_text(json.dumps(item,indent=2)); print(json.dumps(item,indent=2))
def cmd_aggregate(args):
    prepared=json.loads(args.prepared.read_text()); votes,offline=read_votes(args.votes); certificate=aggregate_votes(prepared,votes,args.quorum); payload={"operation":"increment","counter":"global","amount":1,"transition_hash":prepared["transition_hash"]}; effect_id=prepared["transition_request"]["effect_id"]
    try: execute_once(args.state_db,effect_id,payload,certificate,True)
    except RuntimeError as error:
        if "simulated crash" not in str(error): raise
    recovered=recover_effect(args.state_db,effect_id); replayed=execute_once(args.state_db,effect_id,payload,certificate); value=counter_value(args.state_db)
    if value!=1 or recovered!=replayed: raise RuntimeError("exactly-once invariant failed")
    result={"schema":"CSC_KCH_V12_AGGREGATE_RESULT_V1","status":"PASS","configured_witnesses":3,"online_votes":len(votes),"offline_witnesses":offline,"quorum":args.quorum,"quorum_certificate":certificate,"receipt":recovered,"counter_after_recovery_and_replay":value,"exactly_once":True,"cross_runner":True,"physical_host_independence_claimed":False,"organizational_independence_claimed":False,"result_hash":sha256_hex({"certificate":certificate,"receipt":recovered})}
    args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_text(json.dumps(result,indent=2)); print(json.dumps(result,indent=2))
def cmd_redteam(args):
    prepared=json.loads(args.prepared.read_text()); votes,_=read_votes(args.votes); attacks=[]
    def reject(name,fn):
        try: fn()
        except Exception as error: attacks.append({"attack":name,"rejected":True,"error":type(error).__name__})
        else: attacks.append({"attack":name,"rejected":False})
    reject("insufficient_quorum",lambda:aggregate_votes(prepared,votes[:1],2)); reject("duplicate_witness",lambda:aggregate_votes(prepared,[votes[0],votes[0]],2))
    duplicate=copy.deepcopy(votes[1]); duplicate["trust_domain"]=votes[0]["trust_domain"]; reject("trust_domain_collapse",lambda:aggregate_votes(prepared,[votes[0],duplicate],2))
    tampered=copy.deepcopy(votes[0]); tampered["checkpoint_root"]="00"*32; reject("tampered_binding",lambda:verify_vote(tampered,prepared))
    forged=copy.deepcopy(votes[0]); forged["signature_b64"]=votes[1]["signature_b64"]; reject("forged_signature",lambda:verify_vote(forged,prepared))
    revoked=copy.deepcopy(prepared); revoked["key_registry"][0]["status"]="REVOKED"; reject("revoked_key",lambda:make_vote(revoked,"w1","domain-alpha"))
    reject("antirollback_floor",lambda:make_vote(prepared,"w1","domain-alpha",prepared["checkpoint"]["tree_size"]+1))
    split=copy.deepcopy(prepared["checkpoint"]); split["root"]="11"*32; reject("signed_split_view",lambda:detect_split_view([prepared["checkpoint"],split]))
    rollback=copy.deepcopy(prepared["checkpoint"]); rollback["tree_size"]-=1; reject("checkpoint_rollback",lambda:detect_split_view([prepared["checkpoint"],rollback]))
    wrong=copy.deepcopy(prepared); wrong["policy_support_vectors_sha256"]="22"*32; reject("policy_vector_substitution",lambda:make_vote(wrong,"w1","domain-alpha"))
    report={"schema":"CSC_KCH_V12_REDTEAM_V1","status":"PASS" if all(a["rejected"] for a in attacks) else "FAIL","attacks":attacks,"rejected":sum(a["rejected"] for a in attacks),"total":len(attacks)}
    args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_text(json.dumps(report,indent=2)); print(json.dumps(report,indent=2))
    if report["status"]!="PASS": raise RuntimeError("red-team failure")


class Tests(unittest.TestCase):
    def test_merkle(self):
        leaves=[{"i":i} for i in range(7)]; root=merkle_root(leaves)
        for i,leaf in enumerate(leaves): self.assertTrue(verify_inclusion(leaf,i,len(leaves),inclusion_proof(leaves,i),root))
    def test_split(self):
        with self.assertRaises(ValueError): detect_split_view([{"log_id":"l","tree_size":2,"root":"a"},{"log_id":"l","tree_size":2,"root":"b"}])
    def test_signatures(self):
        payload=b"hello"; signature=sign("w1",payload); self.assertTrue(verify_signature("w1",payload,signature)); self.assertFalse(verify_signature("w2",payload,signature))
    def test_local_flow(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary); vectors=root/"vectors.json"; vectors.write_text("[]"); prepared=prepare(vectors,root/"prepared.json","test"); v1=make_vote(prepared,"w1","domain-alpha",7); v2=make_vote(prepared,"w2","domain-beta",7); certificate=aggregate_votes(prepared,[v1,v2],2); db=root/"state.sqlite"
            with self.assertRaises(RuntimeError): execute_once(db,prepared["transition_request"]["effect_id"],{"amount":1},certificate,True)
            recovered=recover_effect(db,prepared["transition_request"]["effect_id"]); replayed=execute_once(db,prepared["transition_request"]["effect_id"],{"amount":1},certificate); self.assertEqual(recovered,replayed); self.assertEqual(counter_value(db),1)
    def test_policy_substitution(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary); vectors=root/"vectors.json"; vectors.write_text("[]"); prepared=prepare(vectors,root/"prepared.json","test"); prepared["policy_support_vectors_sha256"]="22"*32
            with self.assertRaises(ValueError): make_vote(prepared,"w1","domain-alpha")


def cmd_selftest(_args):
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests); result=unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful(): raise SystemExit(1)


def parser() -> argparse.ArgumentParser:
    root=argparse.ArgumentParser(); sub=root.add_subparsers(dest="command",required=True)
    p=sub.add_parser("prepare"); p.add_argument("--vectors",type=Path,required=True); p.add_argument("--output",type=Path,required=True); p.add_argument("--commit",default="unknown"); p.set_defaults(func=cmd_prepare)
    p=sub.add_parser("witness"); p.add_argument("--prepared",type=Path,required=True); p.add_argument("--witness-id",required=True,choices=sorted(PRIVATE_KEYS)); p.add_argument("--trust-domain",required=True); p.add_argument("--output",type=Path,required=True); p.add_argument("--antirollback-floor",type=int,default=0); p.add_argument("--offline",action="store_true"); p.set_defaults(func=cmd_witness)
    p=sub.add_parser("aggregate"); p.add_argument("--prepared",type=Path,required=True); p.add_argument("--votes",type=Path,required=True); p.add_argument("--state-db",type=Path,required=True); p.add_argument("--output",type=Path,required=True); p.add_argument("--quorum",type=int,default=2); p.set_defaults(func=cmd_aggregate)
    p=sub.add_parser("redteam"); p.add_argument("--prepared",type=Path,required=True); p.add_argument("--votes",type=Path,required=True); p.add_argument("--output",type=Path,required=True); p.set_defaults(func=cmd_redteam)
    p=sub.add_parser("selftest"); p.set_defaults(func=cmd_selftest)
    return root


def main():
    args=parser().parse_args(); args.func(args)
if __name__=="__main__": main()
