# Robust Resolution-Defect and Successive-Refinement Theorem

For target T, sensor s, and adversarial error budget t, define

D_s^(t)(T) = {(h_i,h_j): T(h_i) != T(h_j) and
              Delta_s(h_i,h_j) < 2t+1},

where Delta_s is the Hamming distance between the complete response
codewords exposed by sensor s over all available probes.

For nested sensors ACTIONABLE <- MODE <- EXACT,

D_EXACT^(t)(T) subseteq D_MODE^(t)(T) subseteq D_ACTIONABLE^(t)(T).

Thus a pair inside D_s^(t)(T) cannot be t-error-corrected by any protocol that
uses only sensor s. Escalation to a richer sensor, legitimate target coarsening,
or abstention is necessary.

Successive refinement exploits the quotient chain

EXACT -> MODE -> ACTIONABLE.

If a parent quotient class is singleton with respect to the next finer target,
the finer stage is unnecessary. A stagewise decoder that is independently
t-error-correcting at every stage is conservative but correct under any global
transcript containing at most t errors, because no individual stage can contain
more than t of those errors.

This stagewise construction is not claimed globally query-optimal. Its purpose
is to bound and localize rich-sensor expenditure.
