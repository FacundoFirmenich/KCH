# Symbolic Cost Region

Let a, m, e > 0 denote measured costs of ACTIONABLE, MODE and EXACT queries.

The conservative stagewise worst-case cost bounds are:

t=0:
    C_stage <= 13 a + max(4 m, 2 m + e)

t=1:
    C_stage <= 35 a + max(10 m, 6 m + 3 e)

t=2:
    C_stage <= 63 a + max(11 m + 2 e, 10 m + 5 e)

The corresponding all-EXACT fixed minima cost:

t=0: 6 e
t=1: 19 e
t=2: 34 e

No numerical a,m,e values are assumed. The stagewise design is intended for
regimes where rich-sensor exposure is materially more expensive or constrained
than low-resolution interrogation.

Worst-case EXACT exposure falls from 6/19/34 to at most 1/3/5 respectively,
at the cost of more low-resolution queries.
