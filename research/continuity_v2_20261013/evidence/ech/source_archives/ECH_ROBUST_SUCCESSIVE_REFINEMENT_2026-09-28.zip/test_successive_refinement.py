from pathlib import Path
import json, pandas as pd

ROOT=Path(__file__).parent
P=json.loads((ROOT/"successive_refinement_policy.json").read_text())
M=pd.read_csv(ROOT/"local_mode_refinement.csv")
E=pd.read_csv(ROOT/"local_exact_refinement.csv")
S=pd.read_csv(ROOT/"stagewise_conservative_summary.csv")

def test_quotient_counts():
    assert P["actionable_parent_count"] == 46
    assert P["mode_parent_count"] == 63
    sizes=sorted(len(v) for v in P["actionable_groups"].values())
    assert sizes.count(1)==40
    assert sizes.count(2)==3
    assert sizes.count(4)==2
    assert sizes.count(11)==1

def test_final_exact_refinement():
    for t,need in [(0,1),(1,3),(2,5)]:
        d=E[(E.t==t)&(E.exact_children>1)]
        assert len(d)==2
        assert set(d.min_exact_fixed.astype(int))=={need}

def test_unique_t2_mode_defect_and_repair():
    d=M[(M.t==2)&(M.mode_children>1)]
    assert d.min_mode_fixed.isna().sum()==1
    assert int(d[d.min_mode_fixed.isna()].parent_actionable_id.iloc[0])==2
    repair=P["stage2_mode"]["2"]["2"]
    assert repair["status"]=="MODE_REFINEMENT_WITH_EXACT_REPAIR"
    assert len(repair["exact_repair_probes"])==2
    assert len(repair["mode_probes"])==11

def test_stagewise_exact_exposure():
    vals=dict(zip(S.t,S.worst_exact_queries_on_any_path))
    assert vals=={0:1,1:3,2:5}
