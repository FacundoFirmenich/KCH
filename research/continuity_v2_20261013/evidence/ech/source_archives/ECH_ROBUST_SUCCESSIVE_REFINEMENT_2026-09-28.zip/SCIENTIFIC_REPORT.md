# ECH Robust Successive Semantic Refinement

## Executive result

A direct robust mixed-resolution decoder was first constructed for exact
constitutional identification. It exposed an important negative result:
a naive `ACTIONABLE -> MODE -> EXACT` ordering can consume almost its entire
reserve under adversarial corruption. In the verified construction:

| t | mixed reserve | worst issued | A | M | E |
|---:|---:|---:|---:|---:|---:|
| 0 | 9 | 9 | 6 | 2 | 1 |
| 1 | 23 | 23 | 14 | 4 | 5 |
| 2 | 39 | 38 | 23 | 7 | 8 |

Thus **lazy escalation under zero noise does not automatically imply lazy
robust escalation**.

The successful robust architecture is instead quotient-first successive
refinement:

`ACTIONABLE -> MODE -> EXACT`.

## Quotient geometry

The 65 exact functions collapse to:

- 46 ACTIONABLE functions;
- 63 MODE functions;
- 65 EXACT functions.

ACTIONABLE parent sizes:

- 40 singleton parents;
- 3 parents of size 2;
- 2 parents of size 4;
- 1 parent of size 11.

Therefore:
- **40/65 exact functions terminate after ACTIONABLE identification**;
- **25/65 enter MODE refinement**;
- only **4/65 ultimately require final EXACT refinement**.

The MODE quotient contains 61 singleton parents and only two parents of size 2.

## Local MODE refinement

Only 6 of the 46 ACTIONABLE parents contain more than one MODE function.

For t=0 the largest minimum local MODE codebook is 4 probes.
For t=1 it is 10 probes.

For t=2, five of those six parents remain MODE-resolvable; exactly one
11-function parent becomes structurally non-correctable using MODE alone.
That entire global impossibility is localized to ACTIONABLE parent 2.

The defective t=2 parent is repaired optimally by:
- 2 EXACT probes;
- 11 MODE probes.

The solver found the lexicographic minimum `2E + 11M`.

## Final EXACT refinement

Only two MODE parents remain non-singleton at exact resolution. Each contains
two exact functions.

Their exact robust refinement costs are exactly:

- t=0: 1 EXACT probe;
- t=1: 3 EXACT probes;
- t=2: 5 EXACT probes.

These are the expected `2t+1` repetitions needed to correct t arbitrary
categorical errors for a binary residual collision.

## Conservative stagewise bounds

The construction gives:

| t | worst total fixed queries | max EXACT on any path | all-EXACT fixed minimum |
|---:|---:|---:|---:|
| 0 | 17 | **1** | 6 |
| 1 | 45 | **3** | 19 |
| 2 | 78 | **5** | 34 |

This is intentionally not presented as a total-query speedup. It is a
**rich-sensor exposure trade-off**.

The maximum EXACT exposure is reduced by:

- t=0: 83.33%
- t=1: 84.21%
- t=2: 85.29%

relative to the all-EXACT fixed minima.

The stagewise protocol spends many more cheap/coarse probes. Whether it is
operationally preferable depends on measured costs, privacy, compute, or
authority constraints.

## Robust defect spectrum

For the EXACT target, the minimum sensor needed by each of the 2,080 function
pairs is:

| t | ACTIONABLE | MODE | EXACT |
|---:|---:|---:|---:|
| 0 | 2010 | 68 | 2 |
| 1 | 2010 | 68 | 2 |
| 2 | 2010 | 67 | 3 |
| 3 | 2010 | 67 | 3 |
| 4 | 1999 | 78 | 3 |

At t=0 and t=1, only two pairs intrinsically require EXACT. At t=2, one
additional pair migrates from MODE to EXACT. Robustness therefore changes not
only redundancy but, for some pairs, the minimum sufficient sensor resolution.

## Formal interpretation

The correct robust object is not merely a codebook. It is a quotient tree with
local error-correcting refinements.

Global robust coding asks every class to pay for distinctions relevant only to
a few collisions.

Successive refinement asks:

1. Which coarse equivalence class are we in?
2. Is that parent already singleton at the next resolution?
3. If not, which local codebook is required?
4. Does the local sensor have enough distance for the requested t?
5. If not, escalate only inside that defective parent.

This is **local authority applied to sensing itself**.

## QAS transfer

For QAS-P2 the analogous hierarchy should be tested prospectively:

`ACTIVITY -> SUPPORT_CLASS -> EXACT_MASK`

with progressively richer sensors:

`SCALARS -> TOP-K -> MICROPROBE -> PARTIAL/FULL OPERATOR`.

If 90%+ of trajectories terminate at a coarse support-equivalence class,
full coordinate reconstruction should be treated as a local refinement problem,
not as the default prediction task.

No QAS-P2 empirical claim is made here; the current result is a finite exact
constitutional construction and experimental design rule.

## Authority boundary

Every decoder result remains epistemic. `permission_granted=false`.
KCH remains the authority layer.
