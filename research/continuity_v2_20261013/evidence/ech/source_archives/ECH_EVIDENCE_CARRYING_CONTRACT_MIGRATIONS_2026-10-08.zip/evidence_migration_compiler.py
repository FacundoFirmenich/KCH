#!/usr/bin/env python3
from __future__ import annotations
import argparse, ast, csv, json
from pathlib import Path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--migration-table", type=Path, required=True)
    parser.add_argument("--source-contract", required=True)
    parser.add_argument("--destination-contract", required=True)
    args = parser.parse_args()

    rows = list(csv.DictReader(args.migration_table.open()))
    matches = [
        row for row in rows
        if row["source_contract"] == args.source_contract
        and row["destination_contract"] == args.destination_contract
    ]
    if len(matches) != 1:
        print(json.dumps({
            "status": "TRANSITION_NOT_COMPILED_AS_ADJACENT",
            "permission_granted": False
        }, indent=2))
        return

    row = matches[0]
    additional = int(float(row["additional_queries"]))
    selected = json.loads(row["selected_probe_masks"])
    print(json.dumps({
        "status": (
            "ZERO_COST_CLAIM_MIGRATION"
            if additional == 0 else "BRIDGE_REQUIRED"
        ),
        "transition_type": row["transition_type"],
        "source_contract": row["source_contract"],
        "destination_contract": row["destination_contract"],
        "additional_queries": additional,
        "acquisition_sensor": row["destination_sensor"],
        "selected_probe_masks": selected,
        "source_evidence_is_preserved": True,
        "canonical_destination_codebook_substitution": False,
        "permission_granted": False
    }, indent=2))

if __name__ == "__main__":
    main()
