# Evidence-Carrying Assurance Morphisms

## State object

A migration state is not a contract label. It is:

\[
\mathfrak S=(E,C),
\]

where \(E\) is the actual typed evidence ledger and \(C\) is the claim currently
certified by that ledger.

An observation is typed at least by:

\[
(\text{probe},\text{sensor},\text{value},\text{provenance}).
\]

## Valid migration

A valid migration

\[
m:(E,C)\rightarrow(E',C')
\]

must satisfy:

\[
E'=E\cup\Delta E
\]

and:

\[
E'\models C'.
\]

No migration may replace \(E\) by the codebook conventionally associated with
\(C'\) unless those observations were actually acquired.

## Safe composition

If:

\[
(E_0,C_0)\rightarrow(E_1,C_1)
\]

and:

\[
(E_1,C_1)\rightarrow(E_2,C_2),
\]

then:

\[
E_0\subseteq E_1\subseteq E_2.
\]

Composition is safe because the same evidence genealogy is carried through the
chain.

## Failure of label-only composition

A zero-query change of claim label does not materialize the canonical codebook
of the destination label. Therefore arrows between labels cannot generally be
composed by substituting canonical evidence.

The exact witness in this release is:

`MODE__MODE__d1 -> MODE__EXACT__d1 -> EXACT__EXACT__d1`.

The actual initial MODE evidence leaves exact-class pairs `(11,19)` and
`(55,56)` at distance zero. The false composition appears only if the inherited
ledger is silently replaced by the canonical MODE/EXACT codebook.

## Distinct operations

- `CLAIM_WEAKEN`: certify a weaker target or distance from the same evidence.
- `CLAIM_STRENGTHEN`: add the exact bridge required by the stronger claim.
- `SENSOR_REBIND`: change allowed future acquisition channels; no raw readings
  are created.
- `SENSOR_MATERIALIZE`: actually acquire readings at the new sensor.
- `CANONICALIZE`: acquire a destination's conventional codebook. This is
  optional representation work, not semantic migration.
- `NEW_CONTRACT`: required when universe, policy, object or provenance boundary
  changes incompatibly.
