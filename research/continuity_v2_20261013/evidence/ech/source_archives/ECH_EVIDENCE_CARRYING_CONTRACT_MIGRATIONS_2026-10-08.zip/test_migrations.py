from pathlib import Path
import json
import pandas as pd

ROOT=Path(__file__).parent
M=pd.read_csv(ROOT/"adjacent_contract_migrations.csv")
C=json.loads((ROOT/"label_only_composition_counterexample.json").read_text())

def test_transition_counts():
    S=M.groupby("transition_type").additional_queries.agg(
        total="size",
        zero=lambda x:int((x==0).sum()),
        positive=lambda x:int((x>0).sum()))
    assert tuple(S.loc["DISTANCE"])==(44,22,22)
    assert tuple(S.loc["TARGET"])==(26,14,12)
    assert tuple(S.loc["SENSOR"])==(26,26,0)

def test_all_bridges_closed():
    assert M.additional_queries.notna().all()
    assert M.lp_lower_bound.notna().all()
    P=M[M.additional_queries>0]
    assert (P.additional_queries >= P.lp_lower_bound-1e-8).all()

def test_mode_to_exact_refinement():
    D=M[(M.source_target=="MODE")&
        (M.destination_target=="EXACT")&
        (M.source_sensor=="EXACT")&
        (M.transition_type=="TARGET")].sort_values("source_distance")
    assert list(D.additional_queries)==[0,1,1,1,1]

def test_counterexample():
    assert C["actual_initial_evidence_min_distance_for_EXACT_target"]==0
    assert C["exact_target_pairs_unseparated_by_actual_evidence"]==[[11,19],[55,56]]
    assert C["permission_granted"] is False
