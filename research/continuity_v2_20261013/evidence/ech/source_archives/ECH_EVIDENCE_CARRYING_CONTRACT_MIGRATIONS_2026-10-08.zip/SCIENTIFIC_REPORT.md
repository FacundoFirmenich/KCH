# ECH Evidence-Carrying Contract Migrations

## Executive result

A contract label and the evidence that supports it are different objects.

The exact adjacent-migration compiler evaluated 96 one-step transitions:

| Transition family | Total | Zero-query | Bridge required | Maximum bridge |
|---|---:|---:|---:|---:|
| Robustness distance | 44 | 22 | 22 | 15 |
| Target resolution | 26 | 14 | 12 | 4 |
| Sensor rebinding | 26 | 26 | 0 | 0 |

Overall, **62 of 96** adjacent claim migrations need no new observation.
The remaining 34 have exact MILP bridges and were replay-verified against every
relevant destination pair.

## Robustness migration

All 22 robustness downgrades are zero-query.

The 22 one-level upgrades require between 6 and 15 new observations. Rich
EXACT/MODE interfaces usually require 6 to 8. The binary
ACTIONABLE/ACTIONABLE interface requires 10, 13, 14 and 15.

These are bridge costs from the actual inherited ledger, not sizes of
independently recompiled destination codebooks.

## Target migration

Every target coarsening is zero-query.

Refinement is local:

- MODE to EXACT under an EXACT sensor costs zero at distance 1 and exactly one
  new probe (`00e`) at distances 2 through 5.
- ACTIONABLE to MODE under EXACT costs 1, 1, 2, 3 and 2 probes.
- ACTIONABLE to MODE under MODE costs 2, 3 and 4 probes.

A stronger semantic distinction therefore does not generally require rebuilding
the evidence base.

## Sensor rebinding is not sensor materialization

All 26 adjacent sensor changes preserve the current target/distance service at
zero query cost. The inherited ledger already supports the claim.

But acquiring the destination's conventional canonical codebook would require
between **6 and 50** additional readings in these same
transitions.

Therefore:

`service satisfaction != sensor materialization != canonicalization`.

A zero-query sensor rebind changes which channel may be used later. It does not
create raw readings that were never acquired.

## Exact counterexample to label-only composition

The actual `MODE__MODE__d1` ledger contains:

```text
01e, 027, 031, 04b, 071, 442, 580
```

It leaves exact-class pairs `(11,19)` and `(55,56)` at distance zero.

A zero-query rebind to the label `MODE__EXACT__d1` does not replace those
observations with the canonical MODE/EXACT codebook. If labels were composed by
canonical substitution, one would falsely infer a zero-cost refinement to
`EXACT__EXACT__d1`.

Thus:

`contract label != evidence state`.

The compositional state is:

`(actual typed evidence, certified claim)`.

## Direct satisfaction atlas

The 28 frozen evidence ledgers were checked against all 28 destination labels.

**353 of 784** source-evidence/destination-claim combinations are
already satisfied without a new query.

The 28 ledgers induce only **21** distinct claim-satisfaction
profiles. These profiles are useful for caching and deduplication, but they do
not authorize replacing one ledger with another that happens to satisfy the same
claims.

## Safe composition

A valid migration has the form:

`E' = E union DeltaE`

and must verify that `E'` satisfies the destination claim.

Composition is safe only because the same evidence genealogy is carried through
the chain. Destination canonicalization is a separate acquisition operation.

## KCH consequence

A lease migration must bind:

- source evidence-set hash;
- source contract;
- inherited typed observations;
- bridge observations;
- destination claim;
- final evidence-set hash.

Two states with the same contract label but different evidence ledgers are not
the same constitutional state.

## QAS-P2 consequence

The same rule applies when moving among activity evidence, support-class
evidence, exact masks and closure/robustness certificates.

A predicted support cannot promote itself by substituting the canonical mask of
a stronger class. The actual logits, probes and mask observations must remain in
the genealogy.

## Boundary

This release compiles adjacent migrations in the frozen constitutional family.
It does not yet establish token-level QAS migration costs; those require the
prospective label-complete campaign.
