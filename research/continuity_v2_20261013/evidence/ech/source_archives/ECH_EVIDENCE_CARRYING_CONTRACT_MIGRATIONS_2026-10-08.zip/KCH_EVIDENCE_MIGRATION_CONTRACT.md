# KCH/ECH Evidence Migration Contract

Every migration receipt must bind:

- source evidence-set hash;
- source contract and source universe/policy hashes;
- destination claim;
- inherited typed observations;
- newly acquired bridge observations;
- final evidence-set hash;
- solver/compiler release;
- authority status.

The migration layer may certify a claim. It may not:
- invent destination observations;
- substitute a canonical codebook for inherited evidence;
- erase contradictory evidence;
- grant permission.

Sensor rebinding changes future acquisition capability. It does not imply
sensor materialization.
