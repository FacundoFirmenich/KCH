# Helical Lift Theorem for Evidence-Carrying Contracts

Let K be the graph of contract labels and let S be the space of full states

    s = (C, E, G),

where C is the active contract, E is an append-only typed evidence ledger and G
is the append-only receipt genealogy. Let pi:S->K forget E and G.

A contract loop gamma in K satisfies pi(s_n)=pi(s_0). Its lifted execution in S
satisfies

    E_0 subseteq E_1 subseteq ... subseteq E_n

and

    G_0 proper-subset G_1 proper-subset ... proper-subset G_n

for every executed nonempty sequence of receipts.

Therefore s_n != s_0 for every nontrivial executed loop. Two cases exist:

1. Evidence monodromy: E_n \ E_0 is nonempty.
2. Pure genealogical monodromy: E_n = E_0 but G_n != G_0.

Hence cycles in contract-label space lift to helices in full state space.
Rollback of a claim is not erasure of evidence or genealogy.

For two commuting label changes a and b, the square may fail to commute after
lifting: the two paths can have the same terminal contract while producing
different evidence ledgers, different costs and different lineage heads.
Thus evidence-carrying migration is generally path-dependent and
noncommutative.
