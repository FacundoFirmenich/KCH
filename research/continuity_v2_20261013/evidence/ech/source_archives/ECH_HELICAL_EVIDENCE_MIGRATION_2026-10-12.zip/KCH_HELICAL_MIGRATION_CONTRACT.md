# KCH Helical Migration Contract

A governed migration state MUST include:
- active_contract_id;
- evidence_content_hash;
- lineage_head;
- generation;
- source policy/universe hashes.

A transition MUST emit:
- parent_lineage_head;
- source_contract;
- destination_contract;
- typed evidence delta;
- resulting evidence_content_hash;
- resulting lineage_head;
- authority receipt or permission_granted=false.

Hard invariants:
1. Evidence ledgers are append-only within a lineage.
2. Claim downgrade does not delete evidence.
3. Contract equality does not imply state equality.
4. A contract loop must produce a successor state.
5. Path-dependent ledgers may not be canonicalized silently.
6. Revocation affects authority/visibility, not historical provenance.
