#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

def h(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()

def initial_state(contract,evidence):
    content={"contract":contract,"evidence":sorted(evidence)}
    content_hash=h(content)
    genesis=h({"genesis":content_hash})
    return {"contract":contract,"evidence":sorted(evidence),"content_hash":content_hash,
            "lineage_head":genesis,"generation":0,"receipts":[]}

def apply(state,destination,new_evidence,transition_type):
    old=set(state["evidence"]); delta=set(new_evidence)
    if not old.issubset(old|delta): raise ValueError("evidence deletion forbidden")
    evidence=sorted(old|delta)
    content_hash=h({"contract":destination,"evidence":evidence})
    receipt={"source_contract":state["contract"],"destination_contract":destination,
             "transition_type":transition_type,"evidence_delta":sorted(delta-old),
             "parent_lineage_head":state["lineage_head"],"generation":state["generation"]+1,
             "permission_granted":False}
    receipt_hash=h(receipt)
    lineage_head=h({"parent":state["lineage_head"],"receipt":receipt_hash,"content":content_hash})
    return {"contract":destination,"evidence":evidence,"content_hash":content_hash,
            "lineage_head":lineage_head,"generation":state["generation"]+1,
            "receipts":state["receipts"]+[dict(receipt,receipt_hash=receipt_hash)]}

def main():
    p=argparse.ArgumentParser();p.add_argument("--state",type=Path);p.add_argument("--contract",required=True)
    p.add_argument("--new-evidence",type=Path);p.add_argument("--transition-type",required=True);a=p.parse_args()
    state=json.loads(a.state.read_text())
    delta=[] if a.new_evidence is None else json.loads(a.new_evidence.read_text())
    print(json.dumps(apply(state,a.contract,delta,a.transition_type),indent=2))
if __name__=="__main__": main()
