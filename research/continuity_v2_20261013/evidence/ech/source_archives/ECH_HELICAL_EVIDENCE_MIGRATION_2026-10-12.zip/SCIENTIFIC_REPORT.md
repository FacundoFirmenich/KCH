# ECH Helical Evidence Migration and Noncommutative Contract Planning

## Executive result

Contract labels form an ordinary graph with upgrades, downgrades, refinements
and sensor rebindings. Full constitutional states do not. Once the actual typed
evidence ledger and append-only receipts are included, a return to the same
contract is generally a successor state rather than a return to the origin.

This release executes every adjacent two-edge contract loop and every valid
positive migration square in the frozen 28-contract family.

## Two-edge loops

There are 48 undirected adjacent contract relations and
96 oriented two-edge loops.

34 loops acquire new evidence before
returning to their initial contract. The remaining
62 have zero evidence monodromy,
but all executed loops add two receipts and therefore have nonzero genealogical
monodromy.

No nontrivial loop returns to the same genealogical state.

### By transition family

| transition_type   |   oriented_loops |   positive_evidence_monodromy |   zero_evidence_monodromy |   max_evidence_monodromy |   mean_evidence_monodromy |
|:------------------|-----------------:|------------------------------:|--------------------------:|-------------------------:|--------------------------:|
| DISTANCE          |               44 |                            22 |                        22 |                       15 |                  4        |
| SENSOR            |               26 |                             0 |                        26 |                        0 |                  0        |
| TARGET            |               26 |                            12 |                        14 |                        4 |                  0.846154 |

The maximum evidence monodromy in a two-edge loop is
15 typed observations.

## Migration squares

There are 23 valid positive squares formed by two independent adjacent
changes among target refinement, sensor enrichment and robustness increase.
Both orders reach the same contract label and both satisfy the destination
claim.

However:

- 17/23 squares are noncommutative in query cost;
- 22/23 are noncommutative in final evidence;
- the largest order-induced cost difference is
  10 queries;
- the largest final-ledger symmetric difference is
  20 typed coordinates.

Thus label-level commutativity does not imply state-level commutativity.

## Helical state

The full state must distinguish:

1. contract label;
2. evidence content hash;
3. genealogical lineage head.

A zero-evidence sensor-rebinding loop can return to the same contract and same
evidence content while still producing a new lineage head. A robustness or
target-refinement loop usually returns with a strictly richer evidence ledger.

This is the operational form of the helical principle:

    recurrence of form != recurrence of state.

## Rollback semantics

A downgrade or claim revocation may restore an earlier contract label, but it
must not delete acquired evidence or receipts. The correct operation is:

    new successor state with weaker active claim and inherited ledger.

True deletion would destroy provenance and invalidate future bridge accounting.
Privacy or retention policies may tombstone access, but the tombstone itself is
an append-only event rather than retroactive nonexistence.

## Noncommutative planning consequence

Migration planning cannot optimize over contract labels alone. The cost of a
future transition depends on which typed observations were acquired along the
path. Therefore the planner state is

    (contract, evidence ledger, lineage),

not merely `contract_id`.

The same destination contract can be reached through ledgers with different
upgrade potential, canonicalization cost and provenance.

## KCH consequence

Every transition receipt should bind:

- parent lineage head;
- source and destination contracts;
- evidence delta;
- resulting evidence-content hash;
- policy/universe hashes;
- permission_granted=false at ECH level.

KCH may authorize a transition, but it may not collapse distinct evidence
histories into one state merely because their contract labels agree.

## QAS consequence

For QAS-P2, changing from ACTIVITY to SUPPORT_CLASS and then to EXACT_MASK can
be order-dependent. A microprobe collected early may reduce later full-operator
cost; a canonical exact mask substituted by label does not. QAS receipts must
therefore carry the actual mask/probe/logit evidence, not only the support-class
name.

## Boundary

The numerical atlas is exact for the frozen finite constitutional family. The
helical-lift theorem is structural for append-only evidence/receipt systems.
Token-level QAS path costs remain prospective until the label-complete campaign
runs.
