#!/usr/bin/env python3
"""CFL-UEP G1 discovery run on the measured FIPS walnut tomography dataset.

This script is deliberately self-contained. It downloads the exact Data82.mat
snapshot through a public GitHub mirror, verifies it against the FIPS/Zenodo MD5,
audits the MATLAB payload, creates deterministic angular train/validation/test
splits, and compares matched-budget reconstruction families.

The "proto-TOS" arm is a discovery implementation, not a canonical proof of
TOS\\. It preserves O1/O2 reconstructions separately, constructs a discrepancy-
and edge-aware field Phi12, and performs an O3 closure solve using only the same
O1+O2 measured projections used by matched multiview baselines. Withheld angles
are touched only after hyperparameters are frozen inside each fold.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import platform
import subprocess
import sys
import time
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy
import scipy.io
import scipy.sparse as sp
import scipy.sparse.linalg as spla

PROGRAM_ID = "CFL-UEP-G1-REAL-TOMO-DISCOVERY-20260926"
SEED = 101
N = 82
N_ANGLES = 120
EXPECTED_SHAPE_A = (9840, 6724)
EXPECTED_SHAPE_M = (82, 120)
EXPECTED_SIZE = 8_083_003
EXPECTED_MD5 = "5698942708300bc34b87931c6d91f6b6"
DATA_URL = (
    "https://raw.githubusercontent.com/UBCMath/MATH307/"
    "e50e49baf8915a2fa4991b490101ee04222b732f/notebooks/data/ct.mat"
)
UPSTREAM_ZENODO_DOI = "10.5281/zenodo.1254206"
MIRROR_COMMIT = "e50e49baf8915a2fa4991b490101ee04222b732f"
MIRROR_BLOB_SHA = "36588d2036873452f2b833f199d7af4036f1ea57"
ALPHAS = [0.1, 1.0, 10.0, 100.0]
BETAS = [0.1, 1.0, 10.0, 100.0]
GAMMA_DISAGREEMENT = 1.0
DCT_K = 16
CG_RTOL = 2e-5
CG_MAXITER = 400
NOISE_FRACTION = 0.005
SUPPORT_MARGIN = 0.02
FALSE_CLOSURE_TRAIN_TOL = 0.02
FALSE_CLOSURE_TEST_MARGIN = 0.05


@dataclass
class SolveResult:
    image: np.ndarray
    info: int
    seconds: float
    iterations: int


@dataclass
class Candidate:
    method: str
    alpha: float
    beta: float
    val_nrmse: float
    train_nrmse: float
    solve_seconds: float
    cg_info: int
    cg_iterations: int
    image: np.ndarray


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def md5_file(path: Path) -> str:
    h = hashlib.md5()  # noqa: S324 -- used only to verify published checksum
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def download_exact(url: str, path: Path) -> None:
    if path.exists() and path.stat().st_size == EXPECTED_SIZE and md5_file(path) == EXPECTED_MD5:
        return
    tmp = path.with_suffix(path.suffix + ".part")
    if tmp.exists():
        tmp.unlink()
    req = urllib.request.Request(url, headers={"User-Agent": "CFL-UEP-G1/0.1"})
    with urllib.request.urlopen(req, timeout=180) as r, tmp.open("wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
    tmp.replace(path)


def rows_for_angles(angles: Iterable[int], detector_count: int = N) -> np.ndarray:
    return np.concatenate(
        [np.arange(int(a) * detector_count, (int(a) + 1) * detector_count, dtype=np.int64) for a in angles]
    )


def subset(A: sp.spmatrix, m: np.ndarray, angles: np.ndarray) -> tuple[sp.csr_matrix, np.ndarray]:
    rows = rows_for_angles(angles, m.shape[0])
    return A[rows, :].tocsr(), np.asarray(m[:, angles], dtype=np.float64).reshape(-1, order="F")


def nrmse(pred: np.ndarray, target: np.ndarray) -> float:
    denom = float(np.linalg.norm(target))
    return float(np.linalg.norm(pred - target) / max(denom, 1e-12))


def corr(pred: np.ndarray, target: np.ndarray) -> float:
    x = np.asarray(pred, dtype=float).ravel()
    y = np.asarray(target, dtype=float).ravel()
    if np.std(x) <= 1e-15 or np.std(y) <= 1e-15:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def build_laplacian(weights_h: np.ndarray | None = None, weights_v: np.ndarray | None = None) -> sp.csr_matrix:
    if weights_h is None:
        weights_h = np.ones((N, N - 1), dtype=np.float64)
    if weights_v is None:
        weights_v = np.ones((N - 1, N), dtype=np.float64)
    rows: list[int] = []
    cols: list[int] = []
    vals: list[float] = []
    diag = np.zeros(N * N, dtype=np.float64)

    def idx(r: int, c: int) -> int:
        return r + c * N  # MATLAB/Fortran vectorization

    for r in range(N):
        for c in range(N - 1):
            i, j = idx(r, c), idx(r, c + 1)
            w = float(weights_h[r, c])
            diag[i] += w
            diag[j] += w
            rows.extend([i, j])
            cols.extend([j, i])
            vals.extend([-w, -w])
    for r in range(N - 1):
        for c in range(N):
            i, j = idx(r, c), idx(r + 1, c)
            w = float(weights_v[r, c])
            diag[i] += w
            diag[j] += w
            rows.extend([i, j])
            cols.extend([j, i])
            vals.extend([-w, -w])
    rows.extend(range(N * N))
    cols.extend(range(N * N))
    vals.extend(diag.tolist())
    return sp.coo_matrix((vals, (rows, cols)), shape=(N * N, N * N)).tocsr()


def robust_scale(x: np.ndarray) -> float:
    z = np.asarray(x, dtype=float).ravel()
    positive = z[z > 0]
    if positive.size == 0:
        return 1.0
    return float(np.median(positive) + 1e-12)


def phi12_laplacian(x1: np.ndarray, x2: np.ndarray) -> tuple[sp.csr_matrix, dict[str, float]]:
    i1 = x1.reshape((N, N), order="F")
    i2 = x2.reshape((N, N), order="F")
    h1, h2 = np.diff(i1, axis=1), np.diff(i2, axis=1)
    v1, v2 = np.diff(i1, axis=0), np.diff(i2, axis=0)
    edge_h = 0.5 * (np.abs(h1) + np.abs(h2))
    edge_v = 0.5 * (np.abs(v1) + np.abs(v2))
    disagree_h = np.abs(h1 - h2)
    disagree_v = np.abs(v1 - v2)
    se_h, se_v = robust_scale(edge_h), robust_scale(edge_v)
    sd_h, sd_v = robust_scale(disagree_h), robust_scale(disagree_v)
    wh = np.exp(-edge_h / se_h) * (1.0 + GAMMA_DISAGREEMENT * disagree_h / sd_h)
    wv = np.exp(-edge_v / se_v) * (1.0 + GAMMA_DISAGREEMENT * disagree_v / sd_v)
    wh = np.clip(wh, 0.03, 8.0)
    wv = np.clip(wv, 0.03, 8.0)
    field_stats = {
        "edge_h_median": float(np.median(edge_h)),
        "edge_v_median": float(np.median(edge_v)),
        "disagreement_h_median": float(np.median(disagree_h)),
        "disagreement_v_median": float(np.median(disagree_v)),
        "weight_h_min": float(np.min(wh)),
        "weight_h_max": float(np.max(wh)),
        "weight_v_min": float(np.min(wv)),
        "weight_v_max": float(np.max(wv)),
    }
    return build_laplacian(wh, wv), field_stats


def solve_quadratic(
    A: sp.csr_matrix,
    b: np.ndarray,
    alpha: float,
    beta: float = 0.0,
    L: sp.csr_matrix | None = None,
    x0: np.ndarray | None = None,
) -> SolveResult:
    n = A.shape[1]
    rhs = np.asarray(A.T @ b).ravel()
    iterations = 0

    def mv(x: np.ndarray) -> np.ndarray:
        out = np.asarray(A.T @ (A @ x)).ravel() + alpha * x
        if beta > 0 and L is not None:
            out = out + beta * np.asarray(L @ x).ravel()
        return out

    def callback(_: np.ndarray) -> None:
        nonlocal iterations
        iterations += 1

    op = spla.LinearOperator((n, n), matvec=mv, dtype=np.float64)
    diag = np.asarray(A.power(2).sum(axis=0)).ravel() + alpha
    if beta > 0 and L is not None:
        diag = diag + beta * L.diagonal()
    inv_diag = 1.0 / np.maximum(diag, 1e-12)
    preconditioner = spla.LinearOperator((n, n), matvec=lambda x: inv_diag * x, dtype=np.float64)
    t0 = time.perf_counter()
    x, info = spla.cg(
        op, rhs, x0=x0, rtol=CG_RTOL, atol=0.0, maxiter=CG_MAXITER,
        M=preconditioner, callback=callback,
    )
    seconds = time.perf_counter() - t0
    return SolveResult(np.asarray(x, dtype=np.float64), int(info), float(seconds), int(iterations))


def tune(
    method: str,
    A_train: sp.csr_matrix,
    b_train: np.ndarray,
    A_val: sp.csr_matrix,
    b_val: np.ndarray,
    alphas: list[float],
    betas: list[float],
    L: sp.csr_matrix | None,
) -> tuple[Candidate, list[dict[str, Any]]]:
    records: list[dict[str, Any]] = []
    best: Candidate | None = None
    for alpha in alphas:
        for beta in betas:
            sol = solve_quadratic(A_train, b_train, alpha, beta, L)
            val_score = nrmse(A_val @ sol.image, b_val)
            train_score = nrmse(A_train @ sol.image, b_train)
            rec = {
                "method": method,
                "alpha": alpha,
                "beta": beta,
                "val_nrmse": val_score,
                "train_nrmse": train_score,
                "solve_seconds": sol.seconds,
                "cg_info": sol.info,
                "cg_iterations": sol.iterations,
            }
            records.append(rec)
            cand = Candidate(method, alpha, beta, val_score, train_score, sol.seconds, sol.info, sol.iterations, sol.image)
            if best is None or (cand.val_nrmse, cand.alpha, cand.beta) < (best.val_nrmse, best.alpha, best.beta):
                best = cand
    assert best is not None
    return best, records


def dct_basis(n: int = N, k: int = DCT_K) -> np.ndarray:
    x = np.arange(n, dtype=np.float64)
    C = np.empty((n, k), dtype=np.float64)
    for j in range(k):
        scale = math.sqrt(1 / n) if j == 0 else math.sqrt(2 / n)
        C[:, j] = scale * np.cos(math.pi * (2 * x + 1) * j / (2 * n))
    cols = [np.outer(C[:, a], C[:, b]).reshape(-1, order="F") for a in range(k) for b in range(k)]
    return np.column_stack(cols)


def reduced_fisher(A: sp.csr_matrix, B: np.ndarray) -> dict[str, Any]:
    J = np.asarray(A @ B, dtype=np.float64)
    s = np.linalg.svd(J, compute_uv=False)
    tol = float(max(J.shape) * np.finfo(float).eps * (s[0] if s.size else 0.0))
    rank = int(np.sum(s > tol))
    nonzero = s[s > tol]
    cond = float(nonzero[0] / nonzero[-1]) if nonzero.size else None
    return {
        "basis": f"2D_DCT_{DCT_K}x{DCT_K}",
        "dimension": int(B.shape[1]),
        "rank": rank,
        "nullity": int(B.shape[1] - rank),
        "tolerance": tol,
        "largest_singular": float(s[0]) if s.size else 0.0,
        "smallest_identified_singular": float(nonzero[-1]) if nonzero.size else None,
        "condition_number_identified_subspace": cond,
    }


def epsilon_linear(x3: np.ndarray, x1: np.ndarray, x2: np.ndarray) -> tuple[float, list[float]]:
    Z = np.column_stack([x1, x2, np.ones_like(x1)])
    coef, *_ = np.linalg.lstsq(Z, x3, rcond=None)
    fitted = Z @ coef
    eps = float(np.linalg.norm(x3 - fitted) / max(np.linalg.norm(x3), 1e-12))
    return eps, [float(v) for v in coef]


def fold_angles(fold: int) -> dict[str, np.ndarray]:
    # Six angular lattices. One is sealed test, the antipodal offset is validation;
    # the remaining four lattices are split into two complementary O1/O2 sets.
    test = np.arange(fold, N_ANGLES, 6, dtype=int)
    val = np.arange((fold + 3) % 6, N_ANGLES, 6, dtype=int)
    used = set(test.tolist()) | set(val.tolist())
    train = np.array([a for a in range(N_ANGLES) if a not in used], dtype=int)
    o1 = train[(train % 4 == 0) | (train % 4 == 1)]
    o2 = train[(train % 4 == 2) | (train % 4 == 3)]
    # The mod-4 split can be 39/41 after removing test/val. Rebalance deterministically.
    if abs(len(o1) - len(o2)) > 1:
        merged = np.sort(train)
        o1, o2 = merged[::2], merged[1::2]
    return {"test": test, "val": val, "train": train, "o1": np.sort(o1), "o2": np.sort(o2)}


def evaluate_candidate(cand: Candidate, A_train: sp.csr_matrix, b_train: np.ndarray, A_test: sp.csr_matrix, b_test: np.ndarray) -> dict[str, Any]:
    return {
        "method": cand.method,
        "alpha": cand.alpha,
        "beta": cand.beta,
        "validation_nrmse": cand.val_nrmse,
        "training_nrmse": nrmse(A_train @ cand.image, b_train),
        "test_nrmse": nrmse(A_test @ cand.image, b_test),
        "test_correlation": corr(A_test @ cand.image, b_test),
        "cg_info": cand.cg_info,
        "cg_iterations": cand.cg_iterations,
        "solve_seconds_selected_fit": cand.solve_seconds,
    }


def save_montage(path: Path, images: dict[str, np.ndarray]) -> None:
    names = list(images)
    fig, axes = plt.subplots(2, 3, figsize=(12, 8))
    finite = np.concatenate([images[n][np.isfinite(images[n])] for n in names])
    vmin, vmax = np.percentile(finite, [1, 99])
    for ax, name in zip(axes.ravel(), names):
        ax.imshow(images[name].reshape((N, N), order="F"), cmap="gray", vmin=vmin, vmax=vmax)
        ax.set_title(name)
        ax.axis("off")
    for ax in axes.ravel()[len(names):]:
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def environment_snapshot() -> dict[str, Any]:
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "matplotlib": matplotlib.__version__,
        "git_sha": os.environ.get("GITHUB_SHA"),
        "github_run_id": os.environ.get("GITHUB_RUN_ID"),
        "github_run_attempt": os.environ.get("GITHUB_RUN_ATTEMPT"),
    }


def main() -> int:
    np.random.seed(SEED)
    root = Path(os.environ.get("G1_WORKDIR", "g1_work")).resolve()
    data_dir = root / "data"
    out = root / "results"
    data_dir.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    data_path = data_dir / "Data82.mat"

    download_exact(DATA_URL, data_path)
    observed_size = data_path.stat().st_size
    observed_md5 = md5_file(data_path)
    observed_sha256 = sha256_file(data_path)
    checksum_ok = observed_size == EXPECTED_SIZE and observed_md5 == EXPECTED_MD5
    if not checksum_ok:
        raise RuntimeError(
            f"Dataset checksum/size mismatch: size={observed_size}, md5={observed_md5}"
        )

    raw = scipy.io.loadmat(data_path)
    if "A" not in raw or "m" not in raw:
        raise RuntimeError(f"Missing A/m variables. Available: {sorted(k for k in raw if not k.startswith('__'))}")
    A = raw["A"]
    m = np.asarray(raw["m"], dtype=np.float64)
    if not sp.issparse(A):
        raise RuntimeError("A is not sparse")
    A = A.tocsr().astype(np.float64)
    if A.shape != EXPECTED_SHAPE_A or m.shape != EXPECTED_SHAPE_M:
        raise RuntimeError(f"Unexpected shapes A={A.shape}, m={m.shape}")
    finite_ok = bool(np.isfinite(A.data).all() and np.isfinite(m).all())
    if not finite_ok:
        raise RuntimeError("Non-finite values found; silent imputation is forbidden")

    audit = {
        "program_id": PROGRAM_ID,
        "acquisition": {
            "url": DATA_URL,
            "upstream_doi": UPSTREAM_ZENODO_DOI,
            "mirror_repository": "UBCMath/MATH307",
            "mirror_commit": MIRROR_COMMIT,
            "mirror_blob_sha": MIRROR_BLOB_SHA,
        },
        "file": {
            "path": str(data_path.relative_to(root)),
            "size_bytes": observed_size,
            "md5": observed_md5,
            "sha256": observed_sha256,
            "published_md5_match": checksum_ok,
        },
        "mat_payload": {
            "keys": sorted(k for k in raw if not k.startswith("__")),
            "A_shape": list(A.shape),
            "A_format": A.getformat(),
            "A_nnz": int(A.nnz),
            "A_density": float(A.nnz / (A.shape[0] * A.shape[1])),
            "m_shape": list(m.shape),
            "finite": finite_ok,
            "missingness": 0,
            "imputation_performed": False,
        },
    }
    write_json(out / "DATA_AUDIT.json", audit)

    L_fixed = build_laplacian()
    B = dct_basis()
    all_fold_results: list[dict[str, Any]] = []
    tuning_records: list[dict[str, Any]] = []
    selected_images_fold0: dict[str, np.ndarray] = {}

    for fold in range(3):
        parts = fold_angles(fold)
        A1, b1 = subset(A, m, parts["o1"])
        A2, b2 = subset(A, m, parts["o2"])
        Atr, btr = subset(A, m, parts["train"])
        Aval, bval = subset(A, m, parts["val"])
        Atest, btest = subset(A, m, parts["test"])

        c1, r1 = tune("O1_TIKHONOV", A1, b1, Aval, bval, ALPHAS, [0.0], None)
        c2, r2 = tune("O2_TIKHONOV", A2, b2, Aval, bval, ALPHAS, [0.0], None)
        joint, rj = tune("MATCHED_JOINT_TIKHONOV", Atr, btr, Aval, bval, ALPHAS, [0.0], None)
        fixed, rf = tune("MATCHED_FIXED_LAPLACIAN", Atr, btr, Aval, bval, ALPHAS, BETAS, L_fixed)
        L_phi, phi_stats = phi12_laplacian(c1.image, c2.image)
        tos, rt = tune("PROTO_TOS_PHI12_O3", Atr, btr, Aval, bval, ALPHAS, BETAS, L_phi)

        for recs in (r1, r2, rj, rf, rt):
            for rec in recs:
                rec["fold"] = fold
                tuning_records.append(rec)

        # Oracle leak upper bound: test angles are deliberately included and this
        # result is never eligible as evidence.
        leak_angles = np.sort(np.concatenate([parts["train"], parts["test"]]))
        Aleak, bleak = subset(A, m, leak_angles)
        leak_sol = solve_quadratic(Aleak, bleak, joint.alpha)
        oracle = Candidate(
            "ORACLE_TEST_LEAK_FORBIDDEN", joint.alpha, 0.0,
            float("nan"), nrmse(Aleak @ leak_sol.image, bleak), leak_sol.seconds,
            leak_sol.info, leak_sol.iterations, leak_sol.image,
        )

        methods = [c1, c2, joint, fixed, tos, oracle]
        evaluations = [evaluate_candidate(c, Atr if c.method not in {"O1_TIKHONOV", "O2_TIKHONOV"} else (A1 if c.method.startswith("O1") else A2),
                                          btr if c.method not in {"O1_TIKHONOV", "O2_TIKHONOV"} else (b1 if c.method.startswith("O1") else b2),
                                          Atest, btest) for c in methods]
        metric_by_method = {e["method"]: e for e in evaluations}

        eps_lin, eps_coef = epsilon_linear(tos.image, c1.image, c2.image)
        f_o1 = reduced_fisher(A1, B)
        f_o2 = reduced_fisher(A2, B)
        f_joint = reduced_fisher(Atr, B)
        full_nullity_lb = {
            "O1": max(0, A.shape[1] - A1.shape[0]),
            "O2": max(0, A.shape[1] - A2.shape[0]),
            "joint": max(0, A.shape[1] - Atr.shape[0]),
        }

        rng = np.random.default_rng(SEED + fold)
        scale = NOISE_FRACTION * float(np.std(btr))
        btr_noisy = btr + rng.normal(0.0, scale, size=btr.shape)
        tos_noisy_sol = solve_quadratic(Atr, btr_noisy, tos.alpha, tos.beta, L_phi, x0=tos.image)
        perturbation = {
            "noise_fraction_of_training_std": NOISE_FRACTION,
            "relative_image_change": float(np.linalg.norm(tos_noisy_sol.image - tos.image) / max(np.linalg.norm(tos.image), 1e-12)),
            "clean_test_nrmse": metric_by_method["PROTO_TOS_PHI12_O3"]["test_nrmse"],
            "perturbed_test_nrmse": nrmse(Atest @ tos_noisy_sol.image, btest),
        }

        strongest_baseline = min(
            [metric_by_method["MATCHED_JOINT_TIKHONOV"], metric_by_method["MATCHED_FIXED_LAPLACIAN"]],
            key=lambda z: z["test_nrmse"],
        )
        tos_eval = metric_by_method["PROTO_TOS_PHI12_O3"]
        relative_gain = float((strongest_baseline["test_nrmse"] - tos_eval["test_nrmse"]) / strongest_baseline["test_nrmse"])
        false_closure = bool(
            tos_eval["training_nrmse"] <= strongest_baseline["training_nrmse"] * (1 + FALSE_CLOSURE_TRAIN_TOL)
            and tos_eval["test_nrmse"] >= strongest_baseline["test_nrmse"] * (1 + FALSE_CLOSURE_TEST_MARGIN)
        )

        fold_result = {
            "fold": fold,
            "angles": {k: [int(v) for v in arr] for k, arr in parts.items()},
            "counts": {k: int(len(arr)) for k, arr in parts.items()},
            "evaluations": evaluations,
            "strongest_matched_baseline": strongest_baseline["method"],
            "proto_tos_relative_gain_vs_strongest_baseline": relative_gain,
            "false_closure": false_closure,
            "epsilon_linear": eps_lin,
            "epsilon_linear_coefficients_a_b_c": eps_coef,
            "phi12_field": phi_stats,
            "fisher_reduced": {"O1": f_o1, "O2": f_o2, "joint": f_joint},
            "full_object_space_nullity_lower_bound_from_row_count": full_nullity_lb,
            "perturbation_persistence": perturbation,
            "oracle_is_non_evidentiary": True,
        }
        all_fold_results.append(fold_result)

        if fold == 0:
            selected_images_fold0 = {
                "O1": c1.image,
                "O2": c2.image,
                "Joint Tikhonov": joint.image,
                "Fixed Laplacian": fixed.image,
                "Proto-TOS O3": tos.image,
                "Oracle leak": oracle.image,
            }

    save_montage(out / "FOLD0_RECONSTRUCTION_MONTAGE.png", selected_images_fold0)

    evidentiary_gains = [r["proto_tos_relative_gain_vs_strongest_baseline"] for r in all_fold_results]
    support_count = sum(g >= SUPPORT_MARGIN for g in evidentiary_gains)
    worse_count = sum(g <= -SUPPORT_MARGIN for g in evidentiary_gains)
    false_closure_count = sum(bool(r["false_closure"]) for r in all_fold_results)
    fisher_reduction_all = all(
        r["fisher_reduced"]["joint"]["nullity"] < r["fisher_reduced"]["O1"]["nullity"]
        and r["fisher_reduced"]["joint"]["nullity"] < r["fisher_reduced"]["O2"]["nullity"]
        for r in all_fold_results
    )
    o1_best = []
    joint_best = []
    for r in all_fold_results:
        em = {e["method"]: e for e in r["evaluations"]}
        o1_best.append(min(em["O1_TIKHONOV"]["test_nrmse"], em["O2_TIKHONOV"]["test_nrmse"]))
        joint_best.append(min(em["MATCHED_JOINT_TIKHONOV"]["test_nrmse"], em["MATCHED_FIXED_LAPLACIAN"]["test_nrmse"], em["PROTO_TOS_PHI12_O3"]["test_nrmse"]))
    complementarity_score_improved = all(j < o for j, o in zip(joint_best, o1_best))

    if support_count >= 2 and false_closure_count == 0:
        h1 = "LOCAL_SUPPORT"
    elif worse_count >= 2:
        h1 = "REFUTED_IN_DOMAIN"
    else:
        h1 = "BASELINE_EQUIVALENT"
    h4 = "LOCAL_SUPPORT" if fisher_reduction_all and complementarity_score_improved else "NOT_IDENTIFIABLE"
    h6 = "PROTOFORM_ONLY"  # one object and no intrinsic non-Euclidean ground truth

    summary = {
        "program_id": PROGRAM_ID,
        "status": "DISCOVERY_EXECUTED_NOT_CONFIRMED",
        "dataset_sha256": observed_sha256,
        "folds": all_fold_results,
        "aggregate": {
            "proto_tos_relative_gains": evidentiary_gains,
            "median_proto_tos_relative_gain": float(np.median(evidentiary_gains)),
            "support_margin": SUPPORT_MARGIN,
            "support_fold_count": support_count,
            "worse_fold_count": worse_count,
            "false_closure_count": false_closure_count,
            "fisher_nullity_reduced_in_all_folds": fisher_reduction_all,
            "complementarity_improved_score_in_all_folds": complementarity_score_improved,
        },
        "adjudication": {
            "H1_TOS_NONREDUCIBLE_CLOSURE": h1,
            "H4_FISHER_COMPLEMENTARITY": h4,
            "H6_EUCLIDEANIZATION_CONTAMINATION": h6,
            "authority": "NONE",
            "promotion": "BLOCKED",
            "confirmation": "NOT_PERFORMED",
            "replication": "NOT_PERFORMED",
        },
        "important_limitations": [
            "The proto-TOS closure is a discovery implementation, not the canonical CFL Transmuter.",
            "All folds use one measured physical object; angle-block validation is not object-level replication.",
            "Reduced Fisher diagnostics are task-relative to a fixed 256-dimensional low-frequency DCT subspace.",
            "Full-space nullity values are row-count lower bounds, not exact ranks.",
            "H6 cannot be established from this single Euclideanized measurement matrix.",
            "The oracle leak arm is explicitly forbidden as evidence.",
        ],
    }
    write_json(out / "RESULTS.json", summary)

    with (out / "TUNING_TRACES.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(tuning_records[0].keys()))
        writer.writeheader()
        writer.writerows(tuning_records)

    run_manifest = {
        "program_id": PROGRAM_ID,
        "seed": SEED,
        "dataset_sha256": observed_sha256,
        "protocol": {
            "alpha_grid": ALPHAS,
            "beta_grid": BETAS,
            "gamma_disagreement": GAMMA_DISAGREEMENT,
            "dct_basis_k": DCT_K,
            "cg_rtol": CG_RTOL,
            "cg_maxiter": CG_MAXITER,
            "noise_fraction": NOISE_FRACTION,
            "support_margin": SUPPORT_MARGIN,
            "false_closure_train_tolerance": FALSE_CLOSURE_TRAIN_TOL,
            "false_closure_test_margin": FALSE_CLOSURE_TEST_MARGIN,
            "test_touched_after_validation_selection": True,
            "silent_imputation": False,
        },
        "environment": environment_snapshot(),
    }
    run_manifest["manifest_sha256"] = hashlib.sha256(canonical_json(run_manifest)).hexdigest()
    write_json(out / "RUN_MANIFEST.json", run_manifest)

    report_lines = [
        "# CFL–UEP G1 real tomography discovery run",
        "",
        f"- Program: `{PROGRAM_ID}`",
        f"- Dataset SHA-256: `{observed_sha256}`",
        f"- Published MD5 matched: `{checksum_ok}`",
        "- Status: `DISCOVERY_EXECUTED_NOT_CONFIRMED`",
        f"- H1: `{h1}`",
        f"- H4: `{h4}`",
        f"- H6: `{h6}`",
        f"- Proto-TOS fold gains vs strongest matched baseline: `{evidentiary_gains}`",
        f"- False closures: `{false_closure_count}`",
        "",
        "## Interpretation boundary",
        "",
        "This run tests a preregistered discovery surrogate on one measured walnut dataset. "
        "It does not validate CFL universally, does not promote the proto-TOS implementation "
        "to canonical status, and does not establish a non-Euclidean ontology.",
        "",
    ]
    report = "\n".join(report_lines)
    (out / "REPORT.md").write_text(report, encoding="utf-8")

    # Compute artifact-internal checksums last, excluding the checksum file itself.
    checksum_lines = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS.txt":
            checksum_lines.append(f"{sha256_file(path)}  {path.relative_to(root).as_posix()}")
    (out / "SHA256SUMS.txt").write_text("\n".join(checksum_lines) + "\n", encoding="utf-8")

    print(json.dumps({
        "program_id": PROGRAM_ID,
        "dataset_sha256": observed_sha256,
        "H1": h1,
        "H4": h4,
        "H6": h6,
        "median_gain": float(np.median(evidentiary_gains)),
        "false_closure_count": false_closure_count,
        "results_dir": str(out),
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
