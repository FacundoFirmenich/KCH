#!/usr/bin/env python3
from __future__ import annotations
import dataclasses, hashlib, itertools, json, math, os, random, statistics, time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

import numpy as np
import sympy as sp
from sklearn.cross_decomposition import CCA
from sklearn.decomposition import PCA
from sklearn.kernel_ridge import KernelRidge

PROGRAM_ID='CFL-UEP-G3.3-OBSERVATIONAL-CHART-AND-BASIS-GENESIS'
VERSION='0.1.0'
RNG_SEED=330927
x,y,z=sp.symbols('x y z')

# ---------- canonical IO ----------
def canon(v):
    if dataclasses.is_dataclass(v): return canon(asdict(v))
    if isinstance(v,dict): return {str(k):canon(v[k]) for k in sorted(v,key=lambda q:str(q))}
    if isinstance(v,(list,tuple)): return [canon(q) for q in v]
    if isinstance(v,set): return sorted(canon(q) for q in v)
    if isinstance(v,np.generic): return v.item()
    if isinstance(v,sp.Basic): return sp.srepr(v)
    if isinstance(v,float): return None if not math.isfinite(v) else float(v)
    return v

def cjson(v): return json.dumps(canon(v),sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h(v): return hashlib.sha256(cjson(v).encode()).hexdigest()
def write_json(p:Path,v): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(canon(v),indent=2,sort_keys=True)+'\n')
def write_jsonl(p:Path,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w') as f:
        for r in rows:f.write(cjson(r)+'\n')

DIMS={'graph':5,'algebra':4,'number':2,'mechanics':4}
DOMAINS=tuple(DIMS)

@dataclass
class Task:
    task_id:str; domain:str; split:str; regime:str; d:int
    demos_x_obs:list[tuple[int,...]]; o1:list[tuple[int,...]]; o2:list[tuple[int,...]]
    target_x_obs:tuple[int,...]; truth_y_obs:tuple[int,...]
    truth_x_latent:list[tuple[int,...]]; truth_y_latent:list[tuple[int,...]]
    truth_A:tuple[tuple[int,...],...]; truth_b:tuple[int,...]
    truth_chart:tuple[int,...]; qsplit:int; origin_leak:bool; metadata:dict[str,Any]

@dataclass
class Pred:
    method:str; state:str; candidate:Any|None; evals:int; runtime_ms:float; reason:str; origin_risk:bool=False

# ---------- latent domains ----------
def valid(domain,v):
    if domain=='graph': return len(v)==5 and all(q in (0,1) for q in v)
    if domain=='algebra': return len(v)==4 and v[0]!=v[1] and v[2]!=0 and max(abs(q) for q in v)<=30
    if domain=='number': return len(v)==2 and v[0]>v[1]>0 and v[0]<=40
    if domain=='mechanics': return len(v)==4 and min(v)>0 and max(v)<=30
    return False

def sample_x(domain,rng):
    if domain=='graph': return tuple(rng.randint(0,1) for _ in range(5))
    if domain=='algebra':
        while True:
            q=(rng.randint(-4,1),rng.randint(2,7),rng.choice([-2,-1,1,2]),rng.randint(-4,4))
            if valid(domain,q): return q
    if domain=='number':
        n=rng.randint(1,6);m=rng.randint(n+1,14);return (m,n)
    if domain=='mechanics': return tuple(rng.randint(1,6) for _ in range(4))

# ---------- latent affine operators ----------
def generate_operator(domain,d,rng,length):
    if domain=='graph':
        A=np.eye(d,dtype=np.uint8);b=np.zeros(d,dtype=np.uint8)
        for _ in range(length):
            typ=rng.choice(['xor','swap','flip'])
            if typ=='xor':
                i,j=rng.sample(range(d),2);A[i]^=A[j];b[i]^=b[j]
            elif typ=='swap':
                i,j=rng.sample(range(d),2);A[[i,j]]=A[[j,i]];b[[i,j]]=b[[j,i]]
            else:b[rng.randrange(d)]^=1
        return tuple(tuple(int(q) for q in row) for row in A.tolist()),tuple(int(q) for q in b.tolist())
    A=np.eye(d,dtype=np.int64);b=np.zeros(d,dtype=np.int64)
    positive=domain in ('number','mechanics')
    for _ in range(length):
        typ=rng.choice(['shear','shift'] if positive else ['shear','swap','shift'])
        if typ=='shear':
            i,j=rng.sample(range(d),2);sgn=1 if positive else rng.choice([-1,1]);A[i]=A[i]+sgn*A[j];b[i]=b[i]+sgn*b[j]
        elif typ=='swap':
            i,j=rng.sample(range(d),2);A[[i,j]]=A[[j,i]];b[[i,j]]=b[[j,i]]
        else:
            i=rng.randrange(d);b[i]+=rng.choice([1,2] if positive else [-2,-1,1,2])
    return tuple(tuple(int(q) for q in row) for row in A.tolist()),tuple(int(q) for q in b.tolist())

def apply_op(domain,A,b,v):
    if domain=='graph':
        yy=(np.asarray(A,dtype=np.uint8)@np.asarray(v,dtype=np.uint8)+np.asarray(b,dtype=np.uint8))%2
        return tuple(int(q) for q in yy.tolist())
    yy=np.asarray(A,dtype=np.int64)@np.asarray(v,dtype=np.int64)+np.asarray(b,dtype=np.int64)
    return tuple(int(q) for q in yy.tolist())

# ---------- nonlinear hidden charts ----------
def chart_candidates(domain,d):
    if domain=='graph':
        # c1 controls linear triangular term; c_i>=2 controls nonlinear AND term.
        return [tuple(c) for c in itertools.product((0,1), repeat=d-1)]
    return [tuple(c) for c in itertools.product((-1,0,1), repeat=d-1)]

def chart_nontrivial(domain,c):
    if domain=='graph': return sum(c)>=2 and any(c[i] for i in range(1,len(c)))
    return sum(1 for q in c if q) >= 1

def chart_apply(domain,c,v):
    v=list(map(int,v)); w=[0]*len(v); w[0]=v[0]
    if domain=='graph':
        if len(v)>1:w[1]=v[1] ^ (c[0]&v[0])
        for i in range(2,len(v)):
            w[i]=v[i] ^ (c[i-1] & (v[i-1]&v[i-2]))
        return tuple(w)
    for i in range(1,len(v)):
        w[i]=v[i] + int(c[i-1])*(v[i-1]**2)
    return tuple(w)

def chart_inv(domain,c,w):
    w=list(map(int,w)); v=[0]*len(w); v[0]=w[0]
    if domain=='graph':
        if len(w)>1:v[1]=w[1] ^ (c[0]&v[0])
        for i in range(2,len(w)):
            v[i]=w[i] ^ (c[i-1] & (v[i-1]&v[i-2]))
        return tuple(v)
    for i in range(1,len(w)):
        v[i]=w[i] - int(c[i-1])*(v[i-1]**2)
    return tuple(v)

# ---------- exact affine solvers ----------
def rank2(M):
    A=M.copy()%2;r=0
    for c in range(A.shape[1]):
        piv=next((i for i in range(r,A.shape[0]) if A[i,c]),None)
        if piv is None: continue
        A[[r,piv]]=A[[piv,r]]
        for i in range(A.shape[0]):
            if i!=r and A[i,c]: A[i]^=A[r]
        r+=1
    return r

def affine_rank(xs,domain):
    if domain=='graph': return rank2(np.array([list(v)+[1] for v in xs],dtype=np.uint8))
    return int(sp.Matrix([list(v)+[1] for v in xs]).rank())

def solve_affine(domain,xs,ys):
    d=len(xs[0])
    if domain=='graph':
        X=np.array([list(v)+[1] for v in xs],dtype=np.uint8)%2
        rX=rank2(X)
        if rX<d+1:return 'UNDERIDENTIFIED',None,None
        cols=[]
        for j in range(d):
            Y=np.array([v[j] for v in ys],dtype=np.uint8).reshape(-1,1)%2
            aug=np.concatenate([X,Y],axis=1)
            if rank2(aug)>rX:return 'INCONSISTENT',None,None
            A=aug.copy();r=0;piv=[]
            for c in range(d+1):
                p=next((i for i in range(r,len(A)) if A[i,c]),None)
                if p is None:continue
                A[[r,p]]=A[[p,r]]
                for i in range(len(A)):
                    if i!=r and A[i,c]:A[i]^=A[r]
                piv.append(c);r+=1
            sol=np.zeros(d+1,dtype=np.uint8)
            for rr,c in enumerate(piv):sol[c]=A[rr,-1]
            cols.append(sol.tolist())
        AA=tuple(tuple(int(cols[j][i]) for i in range(d)) for j in range(d));bb=tuple(int(cols[j][d]) for j in range(d))
        return 'IDENTIFIED',AA,bb
    X=sp.Matrix([list(v)+[1] for v in xs])
    if X.rank()<d+1:return 'UNDERIDENTIFIED',None,None
    cols=[]
    for j in range(d):
        Y=sp.Matrix([v[j] for v in ys]); sol=sp.linsolve((X,Y))
        if sol==sp.EmptySet:return 'INCONSISTENT',None,None
        vals=list(sol)
        if len(vals)!=1:return 'UNDERIDENTIFIED',None,None
        vv=vals[0]
        if any(getattr(q,'free_symbols',set()) for q in vv):return 'UNDERIDENTIFIED',None,None
        if any(not q.is_integer for q in vv):return 'INCONSISTENT',None,None
        cols.append([int(q) for q in vv])
    AA=tuple(tuple(cols[j][i] for i in range(d)) for j in range(d));bb=tuple(cols[j][d] for j in range(d))
    return 'IDENTIFIED',AA,bb

# ---------- task generation ----------
def make_task(domain,split,regime,seed):
    rng=random.Random(seed);d=DIMS[domain];oplen=2 if split=='IID' else 3
    candcharts=[c for c in chart_candidates(domain,d) if chart_nontrivial(domain,c)]
    for _ in range(500):
        c=rng.choice(candcharts); A,b=generate_operator(domain,d,rng,oplen)
        ndemo=(d+3 if regime!='UNDERIDENTIFIED' else max(2,d-1))
        xs=[]
        for _j in range(ndemo):xs.append(sample_x(domain,rng))
        if regime!='UNDERIDENTIFIED' and affine_rank(xs,domain)<d+1:continue
        ys=[apply_op(domain,A,b,v) for v in xs]
        tx=sample_x(domain,rng);ty=apply_op(domain,A,b,tx)
        if not all(valid(domain,v) for v in ys+[ty]):continue
        xobs=[chart_apply(domain,c,v) for v in xs]; yobs=[chart_apply(domain,c,v) for v in ys]
        txobs=chart_apply(domain,c,tx);tyobs=chart_apply(domain,c,ty)
        break
    else:raise RuntimeError('task generation failed')
    qsplit=(d+1)//2;o1=[v[:qsplit] for v in yobs];o2=[v[qsplit:] for v in yobs]
    origin=False;meta={'truth_chart_hash':h(c),'truth_operator_hash':h({'A':A,'b':b}),'operator_length':oplen}
    if regime=='ANTI':
        # corrupt one observation until no chart in the declared meta-grammar yields an affine fit
        found=False
        for row in range(len(o2)):
            for col in range(len(o2[row])):
                cand=[list(v) for v in o2]
                cand[row][col]=(cand[row][col]^1) if domain=='graph' else cand[row][col]+1
                if not compatible_predictions(domain,xobs,o1,[tuple(v) for v in cand],txobs,max_charts=None,stop_after=1)[0]:
                    o2=[tuple(v) for v in cand];found=True;break
            if found:break
        if not found:raise RuntimeError('ANTI construction failed')
    elif regime=='UNDERIDENTIFIED':
        # ndemo already insufficient; ensure multiple compatible target predictions exist
        pass
    elif regime=='OVERSUFFICIENT':
        meta['__truth_chart__']=c;meta['__truth_operator__']={'A':A,'b':b};origin=True
    tid=h({'domain':domain,'split':split,'regime':regime,'seed':seed})[:20]
    return Task(tid,domain,split,regime,d,[tuple(v) for v in xobs],o1,o2,tuple(txobs),tuple(tyobs),xs,ys,A,b,c,qsplit,origin,meta)

def generate_split(split,n_construct,n_adv,base):
    out=[]
    for di,domain in enumerate(DOMAINS):
        for i in range(n_construct):out.append(make_task(domain,split,'CONSTRUCT',base+di*10000+i))
        regs=['ANTI','UNDERIDENTIFIED','OVERSUFFICIENT']
        for j in range(n_adv):out.append(make_task(domain,split,regs[j%3],base+di*10000+5000+j))
    return out

# ---------- chart/operator identification ----------
def joint_y_obs(task):return [tuple(a)+tuple(b) for a,b in zip(task.o1,task.o2)]

def compatible_predictions(domain,xobs,o1,o2,target_xobs,max_charts=None,stop_after=None):
    d=len(target_xobs); preds={}; fits=[]; evals=0
    for c in chart_candidates(domain,d):
        evals+=1
        if max_charts is not None and evals>max_charts:break
        try:
            xs=[chart_inv(domain,c,v) for v in xobs]
            ys=[chart_inv(domain,c,tuple(a)+tuple(b)) for a,b in zip(o1,o2)]
            tx=chart_inv(domain,c,target_xobs)
        except Exception:continue
        status,A,b=solve_affine(domain,xs,ys)
        if status!='IDENTIFIED':continue
        # exact demo verification and latent validity
        if any(apply_op(domain,A,b,x)!=y for x,y in zip(xs,ys)):continue
        ty=apply_op(domain,A,b,tx)
        if not valid(domain,ty):continue
        yobs=chart_apply(domain,c,ty)
        preds.setdefault(yobs,[]).append(c);fits.append((c,A,b,yobs))
        if stop_after and len(preds)>=stop_after:break
    return preds,fits,evals

def identify_exact(task,max_charts=None):
    return compatible_predictions(task.domain,task.demos_x_obs,task.o1,task.o2,task.target_x_obs,max_charts=max_charts)

# ---------- approximate baselines ----------
def arrays(task):
    X=np.asarray(task.demos_x_obs,float);Y=np.asarray(joint_y_obs(task),float);xt=np.asarray(task.target_x_obs,float)
    return X,Y,xt

def rounded_valid_candidate(task,yhat):
    yy=tuple(int(round(float(q))) for q in np.asarray(yhat).reshape(-1))
    return yy

def mkpred(name,state,cand,evals,t0,reason,origin=False):return Pred(name,state,cand,evals,(time.perf_counter()-t0)*1000,reason,origin)

def raw_affine(task):
    t0=time.perf_counter();name='RAW_COORD_AFFINE'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    X,Y,xt=arrays(task);Xa=np.c_[X,np.ones(len(X))]
    coef=np.linalg.lstsq(Xa,Y,rcond=None)[0];pred=np.r_[xt,1.]@coef
    return mkpred(name,'1',rounded_valid_candidate(task,pred),1,t0,'raw observed-coordinate affine fit')

def pca_svd(task):
    t0=time.perf_counter();name='PCA_SVD_CHART'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    X,Y,xt=arrays(task);k=max(1,min(task.d,len(X)-1))
    px=PCA(n_components=k,svd_solver='full').fit(X);py=PCA(n_components=k,svd_solver='full').fit(Y)
    ZX=px.transform(X);ZY=py.transform(Y);coef=np.linalg.lstsq(np.c_[ZX,np.ones(len(ZX))],ZY,rcond=None)[0]
    zt=np.r_[px.transform(xt.reshape(1,-1))[0],1.]@coef;pred=py.inverse_transform(zt.reshape(1,-1))[0]
    return mkpred(name,'1',rounded_valid_candidate(task,pred),1,t0,'linear latent SVD/PCA chart')

def cca_baseline(task):
    t0=time.perf_counter();name='CCA_MULTIVIEW'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    X,Y,xt=arrays(task);k=max(1,min(task.d,len(X)-1))
    try:
        cca=CCA(n_components=k,max_iter=1000,tol=1e-10,scale=True).fit(X,Y)
        Xc,Yc=cca.transform(X,Y);coef=np.linalg.lstsq(np.c_[Xc,np.ones(len(Xc))],Yc,rcond=None)[0]
        xc=cca.transform(xt.reshape(1,-1))[0];yc=np.r_[xc,1.]@coef
        # Recover Y from canonical coordinates via least squares Yc -> Y.
        back=np.linalg.lstsq(np.c_[Yc,np.ones(len(Yc))],Y,rcond=None)[0];pred=np.r_[yc,1.]@back
    except Exception:
        pred=np.zeros(task.d)
    return mkpred(name,'1',rounded_valid_candidate(task,pred),1,t0,'CCA latent alignment')

def kernel_ridge(task):
    t0=time.perf_counter();name='KERNEL_NONLINEAR_LATENT'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    X,Y,xt=arrays(task);best=None
    for gamma in (0.01,0.1,1.0):
        model=KernelRidge(alpha=1e-6,kernel='rbf',gamma=gamma).fit(X,Y)
        pred=model.predict(xt.reshape(1,-1))[0]
        train=np.mean((model.predict(X)-Y)**2)
        key=(train,gamma)
        if best is None or key<best[0]:best=(key,pred)
    return mkpred(name,'1',rounded_valid_candidate(task,best[1]),3,t0,'RBF kernel nonlinear predictor')

def polynomial_regression(task):
    t0=time.perf_counter();name='POLY_FEATURE_SYNTHESIS_D2'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    X,Y,xt=arrays(task)
    def phi(v):
        v=np.asarray(v,float);f=[1.0];f.extend(v.tolist())
        for i in range(len(v)):
            for j in range(i,len(v)):f.append(v[i]*v[j])
        return np.asarray(f,float)
    P=np.stack([phi(v) for v in X]);pt=phi(xt);coef=np.linalg.lstsq(P,Y,rcond=None)[0];pred=pt@coef
    return mkpred(name,'1',rounded_valid_candidate(task,pred),1,t0,'degree-2 symbolic feature regression')

# ---------- exact chart synthesis baseline + TOS ----------
def exact_chart_identification(task):
    t0=time.perf_counter();name='EXACT_SYMBOLIC_CHART_IDENTIFICATION'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin chart/operator leaked',True)
    if len(task.demos_x_obs) < task.d + 1:return mkpred(name,'0',None,0,t0,'insufficient demonstrations for affine operator identification')
    preds,fits,evals=identify_exact(task)
    if not preds:return mkpred(name,'-1',None,evals,t0,'no chart+operator in meta-grammar fits all observations')
    if len(preds)>1:return mkpred(name,'0',None,evals,t0,'chart/operator fiber yields multiple target predictions')
    out=next(iter(preds));return mkpred(name,'1',out,evals,t0,'exact chart plus operator identified')

def tos_no_phi(task):
    t0=time.perf_counter();name='TOS_NO_PHI'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin gate',True)
    return mkpred(name,'0',None,0,t0,'single-view chart remains non-identifiable')

def tos_no_o3(task):
    t0=time.perf_counter();name='TOS_NO_O3'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin gate',True)
    if len(task.demos_x_obs) < task.d + 1:return mkpred(name,'0',None,0,t0,'Phi12 detects insufficient demonstrations')
    preds,fits,evals=identify_exact(task)
    if not preds:return mkpred(name,'-1',None,evals,t0,'Phi12 detects no consistent joint chart')
    if len(preds)>1:return mkpred(name,'0',None,evals,t0,'Phi12 leaves chart fiber non-singleton')
    return mkpred(name,'+0',None,evals,t0,'chart+operator identifiable but O3 withheld')

def tos_full(task):
    t0=time.perf_counter();name='TOS_FULL_CHART_PLUS_OPERATOR_GENESIS'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'oversufficiency gate',True)
    if len(task.demos_x_obs) < task.d + 1:return mkpred(name,'0',None,0,t0,'joint observational fiber underdetermined by demo count')
    # Phi12: exact intersection of chart/operator explanations compatible with both partial output views.
    preds,fits,evals=identify_exact(task)
    if not preds:return mkpred(name,'-1',None,evals,t0,'no globally consistent chart/operator')
    if len(preds)>1:return mkpred(name,'0',None,evals,t0,'joint observational fiber not collapsed')
    out=next(iter(preds));return mkpred(name,'1',out,evals,t0,'Phi12 chart genesis + exact O3 operator synthesis')

METHODS=[raw_affine,pca_svd,cca_baseline,kernel_ridge,polynomial_regression,exact_chart_identification,tos_no_phi,tos_no_o3,tos_full]

# ---------- evaluation ----------
def expected_state(t):return {'CONSTRUCT':'1','ANTI':'-1','UNDERIDENTIFIED':'0','OVERSUFFICIENT':'MODEL_MISMATCH'}[t.regime]
def eval_tasks(tasks):
    rows=[]
    for n,t in enumerate(tasks):
        if n%25==0: print('task',n,'/',len(tasks),flush=True)
        for fn in METHODS:
            p=fn(t);succ=t.regime=='CONSTRUCT' and p.state=='1' and tuple(p.candidate)==t.truth_y_obs if p.candidate is not None else False
            fp=t.regime!='CONSTRUCT' and p.state=='1';state_ok=(p.state==expected_state(t)) if t.regime!='CONSTRUCT' else succ
            rows.append({'task_id':t.task_id,'domain':t.domain,'split':t.split,'regime':t.regime,'method':p.method,'success':bool(succ),'state_correct':bool(state_ok),'false_promotion':bool(fp),'state':p.state,'evals':p.evals,'runtime_ms':p.runtime_ms,'reason':p.reason})
    return rows

def summary(rows,split):
    sub=[r for r in rows if r['split']==split];out={}
    for m in sorted({r['method'] for r in sub}):
        z=[r for r in sub if r['method']==m];c=[r for r in z if r['regime']=='CONSTRUCT'];a=[r for r in z if r['regime']!='CONSTRUCT']
        out[m]={'construct_success':sum(r['success'] for r in c)/len(c),'state_accuracy':sum(r['state_correct'] for r in z)/len(z),'false_promotion_rate':sum(r['false_promotion'] for r in a)/len(a),'median_evals':statistics.median(r['evals'] for r in z),'median_runtime_ms':statistics.median(r['runtime_ms'] for r in z)}
    return out

def paired_boot(rows,split,a,b,n=3000):
    aa={r['task_id']:int(r['success']) for r in rows if r['split']==split and r['regime']=='CONSTRUCT' and r['method']==a};bb={r['task_id']:int(r['success']) for r in rows if r['split']==split and r['regime']=='CONSTRUCT' and r['method']==b};ids=sorted(set(aa)&set(bb));d=np.array([aa[i]-bb[i] for i in ids],float);rng=np.random.default_rng(RNG_SEED);bs=[float(np.mean(rng.choice(d,size=len(d),replace=True))) for _ in range(n)];return {'delta':float(d.mean()),'ci':[float(np.quantile(bs,.025)),float(np.quantile(bs,.975))],'n':len(d)}

def by_domain(rows,split,method):
    out={}
    for d in DOMAINS:
        z=[r for r in rows if r['split']==split and r['regime']=='CONSTRUCT' and r['domain']==d and r['method']==method];out[d]=sum(r['success'] for r in z)/len(z)
    return out

def main():
    out=Path(os.environ.get('G33_WORKDIR','/mnt/data/CFL_G3_3_CHART_GENESIS_RUN'));out.mkdir(parents=True,exist_ok=True)
    iid=generate_split('IID',10,6,510000);ood=generate_split('OOD_CHART',10,6,520000);private=generate_split('PRIVATE_HELDOUT',20,9,530000);tasks=iid+ood+private
    truth=[{'task_id':t.task_id,'domain':t.domain,'split':t.split,'regime':t.regime,'chart_hash':h(t.truth_chart),'operator_hash':h({'A':t.truth_A,'b':t.truth_b}),'target_hash':h(t.truth_y_obs)} for t in tasks]
    public=[{'task_id':t.task_id,'domain':t.domain,'split':t.split,'regime':t.regime,'demos_x_obs':t.demos_x_obs,'o1':t.o1,'o2':t.o2,'target_x_obs':t.target_x_obs,'qsplit':t.qsplit,'metadata':{k:v for k,v in t.metadata.items() if not k.startswith('__')}} for t in tasks]
    write_jsonl(out/'evidence'/'TRUTH_MANIFEST.jsonl',truth);write_jsonl(out/'evidence'/'PUBLIC_OBSERVATIONS.jsonl',public)
    rows=eval_tasks(tasks);write_jsonl(out/'results'/'PREDICTIONS.jsonl',rows)
    sums={s:summary(rows,s) for s in ('IID','OOD_CHART','PRIVATE_HELDOUT')};write_json(out/'results'/'SUMMARY.json',sums)
    tos=sums['PRIVATE_HELDOUT']['TOS_FULL_CHART_PLUS_OPERATOR_GENESIS'];base=sums['PRIVATE_HELDOUT']['EXACT_SYMBOLIC_CHART_IDENTIFICATION'];boot=paired_boot(rows,'PRIVATE_HELDOUT','TOS_FULL_CHART_PLUS_OPERATOR_GENESIS','EXACT_SYMBOLIC_CHART_IDENTIFICATION');dom=by_domain(rows,'PRIVATE_HELDOUT','TOS_FULL_CHART_PLUS_OPERATOR_GENESIS')
    gain=tos['construct_success']-base['construct_success'];support=gain>=.02 and boot['ci'][0]>0 and sum(v>base['construct_success'] for v in dom.values())>=3 and tos['false_promotion_rate']<=.02
    outcome='G3_3_CHART_GENESIS_LOCAL_SUPPORT' if support else ('G3_3_REFUTED' if gain<=-.02 else 'G3_3_BASELINE_EQUIVALENT')
    adj={'program_id':PROGRAM_ID,'version':VERSION,'outcome':outcome,'chart_genesis_demonstrated':tos['construct_success']>.95,'private_tos_success':tos['construct_success'],'private_exact_symbolic_success':base['construct_success'],'paired_bootstrap':boot,'tos_domain_success':dom,'false_promotion_rate':tos['false_promotion_rate'],'benchmark_state':'+0_CHART_GENESIS_BENCHMARK_PROTOFORM','o3_claim_state':'0_BASELINE_EQUIVALENT' if outcome=='G3_3_BASELINE_EQUIVALENT' else '+0_UNREPLICATED','authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED','interpretation':'Chart plus operator genesis is tested under an explicit nonlinear triangular chart meta-grammar. If exact symbolic chart identification matches TOS, representation genesis is demonstrated but remains reducible to chart-model selection/system identification within the supplied meta-grammar.'}
    write_json(out/'results'/'FINAL_ADJUDICATION.json',adj)
    manifest={'program_id':PROGRAM_ID,'version':VERSION,'python':os.sys.version,'numpy':np.__version__,'sympy':sp.__version__,'task_counts':{s:sum(t.split==s for t in tasks) for s in ('IID','OOD_CHART','PRIVATE_HELDOUT')},'prediction_rows':len(rows),'truth_manifest_sha256':hashlib.sha256((out/'evidence'/'TRUTH_MANIFEST.jsonl').read_bytes()).hexdigest(),'adjudication':adj};write_json(out/'results'/'RUN_MANIFEST.json',manifest)
    (out/'results'/'REPORT.md').write_text(f'''# CFL G3.3 Observational Chart & Basis Genesis\n\nOutcome: **{outcome}**\n\nPrivate constructive success: TOS = {tos['construct_success']:.4f}; exact symbolic chart identification = {base['construct_success']:.4f}; paired delta = {boot['delta']:.4f}; 95% CI = {boot['ci']}.\n\nThis benchmark withholds the nonlinear observational chart, the target operator and the target output, but supplies a bounded triangular nonlinear chart meta-grammar. It tests chart induction + operator synthesis, not open-ended meta-grammar invention. Authority remains NONE.\n''')
    print(json.dumps(adj,indent=2))

if __name__=='__main__':main()
