#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, itertools, json, math, os, random, statistics, time, sys
from pathlib import Path
from typing import Any
import numpy as np

from sklearn.kernel_approximation import Nystroem
from sklearn.kernel_ridge import KernelRidge
from sklearn.decomposition import KernelPCA

BASE_PATH = Path(os.environ.get('G34_BASE_G33', Path(__file__).with_name('base_g33.py')))
spec=importlib.util.spec_from_file_location('g33base',BASE_PATH)
g=importlib.util.module_from_spec(spec); assert spec.loader; sys.modules[spec.name]=g; spec.loader.exec_module(g)

PROGRAM_ID='CFL-UEP-G3.4-MIXED-OBSERVATIONAL-METAGRAMMAR'
VERSION='0.1.0'
RNG_SEED=340927
FAMILIES=('LINEAR','TRI_QUAD','TRI_CUBIC','PAIRWISE','MULTISCALE')
HELDOUT_FAMILIES=('TRI_CUBIC','MULTISCALE')

# ---------- mixed unlabeled chart family ----------
def _params(domain,d):
    if domain=='graph':
        return [tuple(p) for p in itertools.product((0,1), repeat=d-1) if any(p)]
    return list(itertools.product((-1,1), repeat=d-1))

def chart_candidates(domain,d):
    return [(fam,)+p for fam in FAMILIES for p in _params(domain,d)]

def chart_nontrivial(domain,c): return True

def chart_apply(domain,c,v):
    fam, p = c[0], tuple(map(int,c[1:])); v=list(map(int,v)); w=[0]*len(v); w[0]=v[0]
    if domain=='graph':
        for i in range(1,len(v)):
            ci=p[i-1]
            if fam=='LINEAR': term=v[i-1]
            elif fam=='TRI_QUAD': term=v[i-1] if i==1 else (v[i-1]&v[i-2])
            elif fam=='TRI_CUBIC': term=v[i-1] if i==1 else (v[i-1]&v[0])
            elif fam=='PAIRWISE': term=v[i-1] if i==1 else (v[i-1]|v[i-2])
            else: term=sum(v[:i])%2
            w[i]=v[i] ^ (ci & term)
        return tuple(w)
    for i in range(1,len(v)):
        ci=p[i-1]
        if fam=='LINEAR': term=v[i-1]
        elif fam=='TRI_QUAD': term=v[i-1]**2
        elif fam=='TRI_CUBIC': term=v[i-1]**3
        elif fam=='PAIRWISE': term=v[i-1] if i==1 else v[i-1]*v[i-2]
        else: term=sum(v[:i])**2
        w[i]=v[i] + ci*term
    return tuple(w)

def chart_inv(domain,c,w):
    fam,p=c[0],tuple(map(int,c[1:])); w=list(map(int,w)); v=[0]*len(w);v[0]=w[0]
    if domain=='graph':
        for i in range(1,len(w)):
            ci=p[i-1]
            if fam=='LINEAR': term=v[i-1]
            elif fam=='TRI_QUAD': term=v[i-1] if i==1 else (v[i-1]&v[i-2])
            elif fam=='TRI_CUBIC': term=v[i-1] if i==1 else (v[i-1]&v[0])
            elif fam=='PAIRWISE': term=v[i-1] if i==1 else (v[i-1]|v[i-2])
            else: term=sum(v[:i])%2
            v[i]=w[i] ^ (ci & term)
        return tuple(v)
    for i in range(1,len(w)):
        ci=p[i-1]
        if fam=='LINEAR': term=v[i-1]
        elif fam=='TRI_QUAD': term=v[i-1]**2
        elif fam=='TRI_CUBIC': term=v[i-1]**3
        elif fam=='PAIRWISE': term=v[i-1] if i==1 else v[i-1]*v[i-2]
        else: term=sum(v[:i])**2
        v[i]=w[i]-ci*term
    return tuple(v)

# patch base exact machinery
g.chart_candidates=chart_candidates; g.chart_nontrivial=chart_nontrivial; g.chart_apply=chart_apply; g.chart_inv=chart_inv


# Fast exact-verified affine solver for integer domains; GF(2) keeps the base exact elimination.
def fast_affine_rank(xs,domain):
    if domain=='graph': return g.rank2(np.array([list(v)+[1] for v in xs],dtype=np.uint8))
    X=np.asarray([list(v)+[1] for v in xs],dtype=np.float64)
    return int(np.linalg.matrix_rank(X,tol=1e-10))

def fast_solve_affine(domain,xs,ys):
    if domain=='graph':
        return BASE_SOLVE_AFFINE(domain,xs,ys)
    d=len(xs[0])
    if any(abs(int(q))>10**7 for row in xs for q in row) or any(abs(int(q))>10**7 for row in ys for q in row):
        return 'INCONSISTENT',None,None
    Xi=np.asarray([list(v)+[1] for v in xs],dtype=np.int64); X=Xi.astype(np.float64)
    if np.linalg.matrix_rank(X,tol=1e-10)<d+1: return 'UNDERIDENTIFIED',None,None
    Y=np.asarray(ys,dtype=np.int64); cols=[]
    for j in range(d):
        coef=np.linalg.lstsq(X,Y[:,j].astype(float),rcond=None)[0]
        ci=np.rint(coef).astype(np.int64)
        if not np.array_equal(Xi@ci,Y[:,j]): return 'INCONSISTENT',None,None
        cols.append(ci.tolist())
    AA=tuple(tuple(int(cols[j][i]) for i in range(d)) for j in range(d)); bb=tuple(int(cols[j][d]) for j in range(d))
    return 'IDENTIFIED',AA,bb

BASE_SOLVE_AFFINE=g.solve_affine
g.solve_affine=fast_solve_affine
g.affine_rank=fast_affine_rank

# ---------- identifiability-gated generator ----------
def _family_of_task(t): return str(t.truth_chart[0])

def make_gated(domain,split,regime,seed, family_allow=None, max_attempts=2000):
    for k in range(max_attempts):
        t=g.make_task(domain,split,regime,seed+k*1000003)
        if family_allow is not None and _family_of_task(t) not in family_allow: continue
        if regime=='CONSTRUCT':
            preds,_,_=g.identify_exact(t)
            if len(preds)!=1: continue
        elif regime=='UNDERIDENTIFIED':
            if len(t.demos_x_obs) >= t.d + 1: continue
        elif regime=='ANTI':
            preds,_,_=g.identify_exact(t)
            if preds: continue
        return t
    raise RuntimeError(f'gated generation failed {domain} {split} {regime}')

def generate_split(split,n_construct,n_adv,base):
    out=[]
    # IID excludes two families; OOD_META uses only held-out families; private mixes all.
    if split=='IID': allow=set(FAMILIES)-set(HELDOUT_FAMILIES)
    elif split=='OOD_META': allow=set(HELDOUT_FAMILIES)
    else: allow=set(FAMILIES)
    regs=['ANTI','UNDERIDENTIFIED','OVERSUFFICIENT']
    for di,domain in enumerate(g.DOMAINS):
        for i in range(n_construct):
            t=make_gated(domain,split,'CONSTRUCT',base+di*10000+i,family_allow=allow); out.append(t)
        for j in range(n_adv):
            # Adversarial tasks can use any family; the state, not family OOD, is the point.
            out.append(make_gated(domain,split,regs[j%3],base+di*10000+5000+j,family_allow=None))
    return out

# ---------- stronger baselines ----------
def mkpred(*args,**kwargs): return g.mkpred(*args,**kwargs)

def family_complexity(c):
    fam=str(c[0]); p=c[1:]
    order={'LINEAR':1,'TRI_QUAD':2,'PAIRWISE':2,'TRI_CUBIC':3,'MULTISCALE':4}[fam]
    return order + sum(abs(int(x)) for x in p)*0.05

def exact_metagrammar(task):
    t0=time.perf_counter(); name='EXACT_METAGRAMMAR_MODEL_SELECTION'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin family/chart/operator leaked',True)
    if len(task.demos_x_obs)<task.d+1:return mkpred(name,'0',None,0,t0,'insufficient demonstrations')
    preds,fits,evals=g.identify_exact(task)
    if not preds:return mkpred(name,'-1',None,evals,t0,'no family/chart/operator explanation')
    if len(preds)>1:return mkpred(name,'0',None,evals,t0,'multiple target predictions across metagrammar')
    return mkpred(name,'1',next(iter(preds)),evals,t0,'exact family+chart+operator identification')

def mdl_metagrammar(task):
    t0=time.perf_counter(); name='MDL_METAGRAMMAR_SELECTION'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    if len(task.demos_x_obs)<task.d+1:return mkpred(name,'0',None,0,t0,'insufficient demonstrations')
    preds,fits,evals=g.identify_exact(task)
    if not fits:return mkpred(name,'-1',None,evals,t0,'no exact fit')
    fit=min(fits,key=lambda q:(family_complexity(q[0]),g.h(q[0])))
    return mkpred(name,'1',fit[3],evals,t0,'minimum-description exact chart among compatible fits')

def bounded_program_synthesis(task):
    t0=time.perf_counter(); name='BOUNDED_SYMBOLIC_CHART_PROGRAM_SYNTHESIS'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    # Fixed search budget, family-order deliberately non-oracular.
    preds,fits,evals=g.compatible_predictions(task.domain,task.demos_x_obs,task.o1,task.o2,task.target_x_obs,max_charts=24)
    if not preds:return mkpred(name,'0',None,evals,t0,'budget exhausted without unique program')
    if len(preds)>1:return mkpred(name,'0',None,evals,t0,'multiple predictions inside budget')
    return mkpred(name,'1',next(iter(preds)),evals,t0,'bounded exact chart-program synthesis')

def kcca_like(task):
    t0=time.perf_counter(); name='KERNEL_CCA_PROXY'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    X,Y,xt=g.arrays(task); n=max(2,min(8,len(X)))
    try:
        # Nyström features on X and Y, then canonical-ish linear bridge.
        nx=Nystroem(kernel='rbf',gamma=.05,n_components=n,random_state=RNG_SEED).fit(X)
        ny=Nystroem(kernel='rbf',gamma=.05,n_components=n,random_state=RNG_SEED).fit(Y)
        ZX=nx.transform(X); ZY=ny.transform(Y)
        coef=np.linalg.lstsq(np.c_[ZX,np.ones(len(ZX))],ZY,rcond=None)[0]
        zt=np.r_[nx.transform(xt.reshape(1,-1))[0],1.]@coef
        back=np.linalg.lstsq(np.c_[ZY,np.ones(len(ZY))],Y,rcond=None)[0]
        pred=np.r_[zt,1.]@back
    except Exception: pred=np.zeros(task.d)
    return mkpred(name,'1',g.rounded_valid_candidate(task,pred),1,t0,'kernel multiview proxy')

def manifold_proxy(task):
    t0=time.perf_counter(); name='MANIFOLD_KERNEL_PCA'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    X,Y,xt=g.arrays(task); k=max(1,min(task.d,len(X)-1))
    try:
        px=KernelPCA(n_components=k,kernel='rbf',gamma=.05,fit_inverse_transform=True,alpha=1e-6).fit(X)
        py=KernelPCA(n_components=k,kernel='rbf',gamma=.05,fit_inverse_transform=True,alpha=1e-6).fit(Y)
        ZX=px.transform(X); ZY=py.transform(Y)
        coef=np.linalg.lstsq(np.c_[ZX,np.ones(len(ZX))],ZY,rcond=None)[0]
        zt=np.r_[px.transform(xt.reshape(1,-1))[0],1.]@coef
        pred=py.inverse_transform(zt.reshape(1,-1))[0]
    except Exception: pred=np.zeros(task.d)
    return mkpred(name,'1',g.rounded_valid_candidate(task,pred),1,t0,'kernel manifold chart proxy')

def graph_spectral(task):
    t0=time.perf_counter(); name='GRAPH_SPECTRAL_PROXY'
    if task.origin_leak:return mkpred(name,'MODEL_MISMATCH',None,0,t0,'origin leak',True)
    if task.domain!='graph': return mkpred(name,'0',None,0,t0,'not applicable outside graph-coded domain')
    # With 5-bit graph-coded states, use Walsh/parity spectral features rather than pretend a full adjacency matrix.
    X,Y,xt=g.arrays(task)
    def phi(v):
        v=np.asarray(v,int)%2; feats=[1.0]; feats.extend((1-2*v).astype(float).tolist())
        for i in range(len(v)):
            for j in range(i+1,len(v)): feats.append(float((1-2*v[i])*(1-2*v[j])))
        return np.asarray(feats)
    P=np.stack([phi(v) for v in X]); pt=phi(xt); coef=np.linalg.lstsq(P,Y,rcond=None)[0]; pred=pt@coef
    return mkpred(name,'1',g.rounded_valid_candidate(task,pred),1,t0,'Walsh relational spectral proxy')

# TOS variants using the same open metagrammar, without family labels.
def tos_no_phi(task): return g.tos_no_phi(task)
def tos_no_o3(task):
    p=g.tos_no_o3(task); p.method='TOS_NO_O3_METAGRAMMAR'; return p
def tos_full(task):
    p=g.tos_full(task); p.method='TOS_FULL_TOPOLOGY_PLUS_METAGRAMMAR_GENESIS'; return p

METHODS=[g.raw_affine,g.pca_svd,g.cca_baseline,g.kernel_ridge,g.polynomial_regression,
         kcca_like,manifold_proxy,graph_spectral,mdl_metagrammar,bounded_program_synthesis,
         exact_metagrammar,tos_no_phi,tos_no_o3,tos_full]

# ---------- evaluation ----------
def expected_state(t): return g.expected_state(t)
def eval_tasks(tasks):
    rows=[]
    for n,t in enumerate(tasks):
        if n%25==0: print('task',n,'/',len(tasks),flush=True)
        for fn in METHODS:
            p=fn(t)
            succ=bool(t.regime=='CONSTRUCT' and p.state=='1' and p.candidate is not None and tuple(p.candidate)==t.truth_y_obs)
            fp=bool(t.regime!='CONSTRUCT' and p.state=='1')
            state_ok=bool((p.state==expected_state(t)) if t.regime!='CONSTRUCT' else succ)
            rows.append({'task_id':t.task_id,'domain':t.domain,'split':t.split,'regime':t.regime,
                         'truth_family':_family_of_task(t),'method':p.method,'success':succ,'state_correct':state_ok,
                         'false_promotion':fp,'state':p.state,'evals':p.evals,'runtime_ms':p.runtime_ms,'reason':p.reason})
    return rows

def summary(rows,split):
    sub=[r for r in rows if r['split']==split]; out={}
    for m in sorted({r['method'] for r in sub}):
        z=[r for r in sub if r['method']==m]; c=[r for r in z if r['regime']=='CONSTRUCT']; a=[r for r in z if r['regime']!='CONSTRUCT']
        out[m]={'construct_success':sum(r['success'] for r in c)/len(c),
                'state_accuracy':sum(r['state_correct'] for r in z)/len(z),
                'false_promotion_rate':sum(r['false_promotion'] for r in a)/len(a),
                'median_evals':statistics.median(r['evals'] for r in z),
                'median_runtime_ms':statistics.median(r['runtime_ms'] for r in z)}
    return out

def paired_boot(rows,split,a,b,n=4000): return g.paired_boot(rows,split,a,b,n)
def by_domain(rows,split,method): return g.by_domain(rows,split,method)

def family_success(rows,split,method):
    out={}
    for fam in FAMILIES:
        z=[r for r in rows if r['split']==split and r['regime']=='CONSTRUCT' and r['truth_family']==fam and r['method']==method]
        if z: out[fam]=sum(r['success'] for r in z)/len(z)
    return out

def main():
    out=Path(os.environ.get('G34_WORKDIR','/mnt/data/CFL_G3_4_METAGRAMMAR_RUN'));out.mkdir(parents=True,exist_ok=True)
    iid=generate_split('IID',12,6,610000)
    ood=generate_split('OOD_META',12,6,620000)
    private=generate_split('PRIVATE_HELDOUT',24,9,630000)
    tasks=iid+ood+private
    truth=[{'task_id':t.task_id,'domain':t.domain,'split':t.split,'regime':t.regime,'truth_family':_family_of_task(t),
            'chart_hash':g.h(t.truth_chart),'operator_hash':g.h({'A':t.truth_A,'b':t.truth_b}),'target_hash':g.h(t.truth_y_obs)} for t in tasks]
    public=[{'task_id':t.task_id,'domain':t.domain,'split':t.split,'regime':t.regime,'demos_x_obs':t.demos_x_obs,
             'o1':t.o1,'o2':t.o2,'target_x_obs':t.target_x_obs,'qsplit':t.qsplit,
             'metadata':{k:v for k,v in t.metadata.items() if not k.startswith('__')}} for t in tasks]
    g.write_jsonl(out/'evidence'/'TRUTH_MANIFEST.jsonl',truth);g.write_jsonl(out/'evidence'/'PUBLIC_OBSERVATIONS.jsonl',public)
    rows=eval_tasks(tasks);g.write_jsonl(out/'results'/'PREDICTIONS.jsonl',rows)
    sums={s:summary(rows,s) for s in ('IID','OOD_META','PRIVATE_HELDOUT')};g.write_json(out/'results'/'SUMMARY.json',sums)
    tosname='TOS_FULL_TOPOLOGY_PLUS_METAGRAMMAR_GENESIS'; basename='EXACT_METAGRAMMAR_MODEL_SELECTION'
    tos=sums['PRIVATE_HELDOUT'][tosname]; base=sums['PRIVATE_HELDOUT'][basename]
    boot=paired_boot(rows,'PRIVATE_HELDOUT',tosname,basename); dom=by_domain(rows,'PRIVATE_HELDOUT',tosname); fam=family_success(rows,'PRIVATE_HELDOUT',tosname)
    gain=tos['construct_success']-base['construct_success']; support=gain>=.02 and boot['ci'][0]>0 and sum(v>=.95 for v in dom.values())>=3 and tos['false_promotion_rate']<=.02
    outcome='G3_4_LOCAL_SUPPORT' if support else ('G3_4_REFUTED' if gain<=-.02 else 'G3_4_BASELINE_EQUIVALENT')
    adj={'program_id':PROGRAM_ID,'version':VERSION,'outcome':outcome,'metagrammar_family_genesis_demonstrated':tos['construct_success']>=.95,
         'private_tos_success':tos['construct_success'],'private_exact_metagrammar_success':base['construct_success'],'paired_bootstrap':boot,
         'tos_domain_success':dom,'tos_family_success':fam,'false_promotion_rate':tos['false_promotion_rate'],
         'benchmark_state':'+0_MIXED_METAGRAMMAR_BENCHMARK_PROTOFORM','o3_claim_state':'0_BASELINE_EQUIVALENT' if outcome=='G3_4_BASELINE_EQUIVALENT' else '+0_UNREPLICATED',
         'authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED',
         'interpretation':'Chart-family labels are withheld and constructive tasks are pre-gated for observational identifiability. If exact metagrammar enumeration matches TOS, family/topology hypothesis selection is demonstrated but remains reducible inside the explicitly supplied finite metagrammar. Latent dimension genesis and genuinely open topology invention are not established in this v0.1.'}
    g.write_json(out/'results'/'FINAL_ADJUDICATION.json',adj)
    manifest={'program_id':PROGRAM_ID,'version':VERSION,'python':os.sys.version,'numpy':np.__version__,
              'families':FAMILIES,'heldout_families':HELDOUT_FAMILIES,
              'task_counts':{s:sum(t.split==s for t in tasks) for s in ('IID','OOD_META','PRIVATE_HELDOUT')},
              'prediction_rows':len(rows),'truth_manifest_sha256':hashlib.sha256((out/'evidence'/'TRUTH_MANIFEST.jsonl').read_bytes()).hexdigest(),'adjudication':adj}
    g.write_json(out/'results'/'RUN_MANIFEST.json',manifest)
    (out/'results'/'REPORT.md').write_text(f'''# CFL G3.4 Mixed Observational Meta-Grammar\n\nOutcome: **{outcome}**\n\nPrivate constructive success: TOS = {tos['construct_success']:.4f}; exact metagrammar selection = {base['construct_success']:.4f}; paired delta = {boot['delta']:.4f}; 95% CI = {boot['ci']}.\n\nThe benchmark hides chart-family labels and mixes five invertible observational chart families. Constructive tasks are admitted only after exact observational-identifiability checking across the full metagrammar. This v0.1 tests meta-family discovery/model selection, not unconstrained invention of a new chart family or latent dimension. Authority remains NONE.\n''')
    print(json.dumps(adj,indent=2))

if __name__=='__main__': main()
