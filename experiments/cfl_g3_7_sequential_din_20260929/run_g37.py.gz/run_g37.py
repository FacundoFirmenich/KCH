#!/usr/bin/env python3
from __future__ import annotations
import os, json, math, hashlib, random, itertools, statistics, time
from pathlib import Path
from collections import Counter, defaultdict
from functools import lru_cache
import numpy as np
from scipy.optimize import linprog

PROGRAM_ID='CFL-UEP-G3.7-SEQUENTIAL-ACTIVE-CLOSURE-DIN-POLICY'
VERSION='0.1.0'; SEED=370929
DOMAINS=('graph','algebra','number','mechanics'); P=3; N=6
HORIZONS=(1,2,3,4)
METHODS=(
 'EXACT_DYNAMIC_PROGRAMMING_CONTINUOUS_DESIGN',
 'GREEDY_CONTINUOUS_CLAIM_EIG',
 'GREEDY_CONTINUOUS_MODEL_EIG',
 'ADAPTIVE_D_OPTIMAL',
 'OPEN_LOOP_BATCH_DESIGN',
 'RANDOM_ADAPTIVE_POLICY',
 'TOS_NO_DIN_REENTRY',
 'TOS_FULL_SEQUENTIAL_DIN_POLICY',
)

def canon(v):
    if isinstance(v,dict): return {str(k):canon(v[k]) for k in sorted(v,key=str)}
    if isinstance(v,(list,tuple)): return [canon(x) for x in v]
    if isinstance(v,np.ndarray): return canon(v.tolist())
    if isinstance(v,np.generic): return v.item()
    if isinstance(v,float): return None if not math.isfinite(v) else float(v)
    return v

def cjson(v): return json.dumps(canon(v),sort_keys=True,separators=(',',':'))
def whash(v): return hashlib.sha256(cjson(v).encode()).hexdigest()
def write_json(p,v): p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(canon(v),indent=2,sort_keys=True)+'\n')
def write_jsonl(p,rows):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w') as f:
        for r in rows:f.write(cjson(r)+'\n')

def entropy(labels):
    n=len(labels)
    if n<=1:return 0.0
    c=Counter(labels);return -sum((k/n)*math.log2(k/n) for k in c.values())

def sep_lp(S,bits):
    # strict binary linear separability; complement-canonical masks only.
    n,p=S.shape; y=np.asarray([1.0 if q else -1.0 for q in bits])
    c=np.r_[np.ones(2*p),0.0]; A=[]; rhs=[]
    for i in range(n):
        A.append(np.r_[-y[i]*S[i], y[i]*S[i], -y[i]])
        rhs.append(-1.0)
    r=linprog(c,A_ub=np.asarray(A),b_ub=np.asarray(rhs),bounds=[(0,None)]*(2*p)+[(None,None)],method='highs')
    if not r.success:return None
    w=r.x[:p]-r.x[p:2*p]; b=float(r.x[-1]); norm=np.linalg.norm(w)
    if norm<1e-10:return None
    w=w/norm;b/=norm
    nz=np.flatnonzero(np.abs(w)>1e-10)
    if len(nz) and w[nz[0]]<0:w=-w;b=-b
    return w,b,float(np.sum(np.abs(w)))

def enumerate_actions(S):
    n=len(S); acts=[]; seen=set()
    # canonical first bit 0 removes complements; complement has same information.
    for mask in range(1,1<<(n-1)):
        bits=(0,)+tuple((mask>>(i-1))&1 for i in range(1,n))
        if len(set(bits))<2:continue
        q=sep_lp(S,bits)
        if q is None:continue
        w,b,comp=q
        actual=tuple(int(v>=0) for v in S@w+b)
        if actual[0]==1: actual=tuple(1-x for x in actual); w=-w;b=-b
        if actual in seen or len(set(actual))<2:continue
        seen.add(actual); acts.append({'bits':actual,'w':w,'b':b,'complexity':comp})
    acts.sort(key=lambda a:a['bits'])
    return acts

def claim_labels(task): return task['target_labels'] if task['regime']=='B' else task['family_labels']

def state_entropy(task,state): return entropy([claim_labels(task)[i] for i in state])
def closed(task,state): return len(set(claim_labels(task)[i] for i in state))<=1

def split_state(state,bits):
    a=tuple(i for i in state if bits[i]==0); b=tuple(i for i in state if bits[i]==1)
    return a,b

def action_stats(task,state,act):
    a,b=split_state(state,act['bits']); n=len(state)
    if not a or not b:return None
    h0=state_entropy(task,state); hp=(len(a)/n)*state_entropy(task,a)+(len(b)/n)*state_entropy(task,b)
    model_ig=entropy([act['bits'][i] for i in state])
    return {'claim_ig':h0-hp,'model_ig':model_ig,'expected_entropy':hp,'branches':(a,b)}

def dp_policy(task,H):
    acts=task['actions']; labels=claim_labels(task)
    @lru_cache(None)
    def V(state,h):
        state=tuple(state)
        if closed(task,state): return (0.0,1.0,0.0,None) # entropy, closure prob, expected cost, action idx
        if h<=0:return (state_entropy(task,state),0.0,0.0,None)
        best=None
        for ai,act in enumerate(acts):
            st=action_stats(task,state,act)
            if st is None:continue
            expH=0.; expC=1.; expClose=0.
            n=len(state)
            for child in st['branches']:
                p=len(child)/n
                hh,cp,cc,_=V(tuple(child),h-1)
                expH+=p*hh; expClose+=p*cp; expC+=p*cc
            key=(expH,-expClose,expC,act['complexity'],ai)
            if best is None or key<best[0]:best=(key,(expH,expClose,expC,ai))
        if best is None:return (state_entropy(task,state),0.0,0.0,None)
        return best[1]
    root=tuple(range(len(task['S']))); return V, V(root,H)

def greedy_action(task,state,mode='claim'):
    best=None
    for ai,act in enumerate(task['actions']):
        st=action_stats(task,state,act)
        if st is None:continue
        if mode=='claim': key=(st['claim_ig'],st['model_ig'],-act['complexity'],-ai)
        else:key=(st['model_ig'],st['claim_ig'],-act['complexity'],-ai)
        if best is None or key>best[0]:best=(key,ai)
    return None if best is None else best[1]

def tos_action(task,state,phi=True):
    S=task['S'][list(state)]; labels=[claim_labels(task)[i] for i in state]
    if len(state)<=1:return None
    if phi:
        groups=defaultdict(list)
        for x,l in zip(S,labels):groups[l].append(x)
        cents=np.asarray([np.mean(v,axis=0) for v in groups.values()])
        C=np.cov(cents,rowvar=False,bias=True) if len(cents)>1 else np.cov(S,rowvar=False,bias=True)
        C=np.atleast_2d(C)+0.15*np.atleast_2d(np.cov(S,rowvar=False,bias=True))
    else:C=np.atleast_2d(np.cov(S,rowvar=False,bias=True))
    vals,vecs=np.linalg.eigh(C); order=np.argsort(vals)[::-1]; best=None
    # TOS may synthesize along any Phi eigen-direction; re-entry recomputes this basis after every observation.
    for oi in order:
        w=vecs[:,oi]
        if np.linalg.norm(w)<1e-12:continue
        w=w/np.linalg.norm(w); proj=S@w; uniq=sorted(set(float(x) for x in proj))
        for x,y in zip(uniq[:-1],uniq[1:]):
            bb=-(x+y)/2; bits_full=tuple(int(v>=0) for v in task['S']@w+bb)
            a,bstate=split_state(state,bits_full)
            if not a or not bstate:continue
            h0=state_entropy(task,state); hp=len(a)/len(state)*state_entropy(task,a)+len(bstate)/len(state)*state_entropy(task,bstate)
            cig=h0-hp; mig=entropy([bits_full[i] for i in state]); comp=float(np.sum(np.abs(w)))
            kk=(cig,mig,-comp,-int(oi))
            if best is None or kk>best[0]:best=(kk,bits_full)
    if best is None:return None
    bits=best[1]
    for ai,a in enumerate(task['actions']):
        if a['bits']==bits or tuple(1-z for z in a['bits'])==bits:return ai
    return None

def dopt_action(task,state):
    S=task['S'][list(state)]
    if len(state)<=1:return None
    C=np.atleast_2d(np.cov(S,rowvar=False,bias=True)); vals,vec=np.linalg.eigh(C);w=vec[:,np.argmax(vals)]
    if np.linalg.norm(w)<1e-12:return None
    w=w/np.linalg.norm(w);proj=S@w;u=sorted(set(float(x) for x in proj));best=None
    for x,y in zip(u[:-1],u[1:]):
        b=-(x+y)/2; bits=tuple(int(v>=0) for v in task['S']@w+b);a,c=split_state(state,bits)
        if not a or not c:continue
        key=(entropy([bits[i] for i in state]),-float(np.sum(np.abs(w))))
        if best is None or key>best[0]:best=(key,bits)
    if best is None:return None
    for ai,a in enumerate(task['actions']):
        if a['bits']==best[1] or tuple(1-z for z in a['bits'])==best[1]:return ai
    return None

def best_open_loop(task,H,cap=20):
    # Search top one-step exact claim actions; fixed batch, responses do not affect later actions.
    root=tuple(range(len(task['S']))); scored=[]
    for ai,a in enumerate(task['actions']):
        st=action_stats(task,root,a)
        if st:scored.append((st['claim_ig'],st['model_ig'],-a['complexity'],ai))
    cand=[x[-1] for x in sorted(scored,reverse=True)[:cap]]
    if not cand:return []
    best=None
    for k in range(1,min(H,len(cand))+1):
        for comb in itertools.combinations(cand,k):
            buckets=defaultdict(list)
            for i in root:buckets[tuple(task['actions'][ai]['bits'][i] for ai in comb)].append(i)
            eh=sum(len(v)/len(root)*state_entropy(task,tuple(v)) for v in buckets.values())
            cp=sum(len(v)/len(root) for v in buckets.values() if closed(task,tuple(v)))
            key=(eh,-cp,k,comb)
            if best is None or key<best[0]:best=(key,list(comb))
    return best[1] if best else []

def tos_initial_candidates(task):
    state=tuple(range(len(task['S'])))
    S=task['S'][list(state)]; labels=[claim_labels(task)[i] for i in state]
    groups=defaultdict(list)
    for x,l in zip(S,labels):groups[l].append(x)
    cents=np.asarray([np.mean(v,axis=0) for v in groups.values()])
    C=np.cov(cents,rowvar=False,bias=True) if len(cents)>1 else np.cov(S,rowvar=False,bias=True)
    C=np.atleast_2d(C)+0.15*np.atleast_2d(np.cov(S,rowvar=False,bias=True))
    vals,vecs=np.linalg.eigh(C); order=np.argsort(vals)[::-1]
    cand=[]
    # Same Phi geometry, frozen at t=0; use its eigen-directions but never posterior-conditioned.
    for oi in order:
        w=vecs[:,oi]
        if np.linalg.norm(w)<1e-12:continue
        w=w/np.linalg.norm(w); proj=S@w; u=sorted(set(float(x) for x in proj))
        for x,y in zip(u[:-1],u[1:]):
            b=-(x+y)/2; bits=tuple(int(v>=0) for v in task['S']@w+b)
            for ai,a in enumerate(task['actions']):
                if a['bits']==bits or tuple(1-z for z in a['bits'])==bits:
                    if ai not in cand:cand.append(ai)
                    break
    return cand

def best_tos_open_loop(task,H):
    root=tuple(range(len(task['S']))); cand=tos_initial_candidates(task)
    if not cand:return []
    best=None
    for k in range(1,min(H,len(cand))+1):
        for comb in itertools.combinations(cand,k):
            buckets=defaultdict(list)
            for i in root:buckets[tuple(task['actions'][ai]['bits'][i] for ai in comb)].append(i)
            eh=sum(len(v)/len(root)*state_entropy(task,tuple(v)) for v in buckets.values())
            cp=sum(len(v)/len(root) for v in buckets.values() if closed(task,tuple(v)))
            comp=sum(task['actions'][ai]['complexity'] for ai in comb)
            key=(eh,-cp,k,comp,comb)
            if best is None or key<best[0]:best=(key,list(comb))
    return best[1] if best else []

def execute_policy(task,method,H,truth_idx):
    state=tuple(range(len(task['S']))); steps=0; seq=[]
    if task['regime'] in ('C','N'):
        # C is already identified. N is certified gauge equivalence with identical sensor signatures.
        return {'closed':closed(task,state),'steps':0,'residual_entropy':state_entropy(task,state),'state':state,'sequence':[],'abstained':True}
    dpV=None
    if method=='EXACT_DYNAMIC_PROGRAMMING_CONTINUOUS_DESIGN':dpV,_=dp_policy(task,H)
    open_seq=(best_open_loop(task,H) if method=='OPEN_LOOP_BATCH_DESIGN' else best_tos_open_loop(task,H) if method=='TOS_NO_DIN_REENTRY' else None)
    used=0
    while steps<H and not closed(task,state):
        remaining=H-steps; ai=None
        if method=='EXACT_DYNAMIC_PROGRAMMING_CONTINUOUS_DESIGN': ai=dpV(tuple(state),remaining)[3]
        elif method=='GREEDY_CONTINUOUS_CLAIM_EIG': ai=greedy_action(task,state,'claim')
        elif method=='GREEDY_CONTINUOUS_MODEL_EIG': ai=greedy_action(task,state,'model')
        elif method=='ADAPTIVE_D_OPTIMAL': ai=dopt_action(task,state)
        elif method=='RANDOM_ADAPTIVE_POLICY':
            inf=[i for i,a in enumerate(task['actions']) if action_stats(task,state,a)]
            if inf:
                rr=random.Random(int(hashlib.sha256(f"{task['task_id']}:{steps}".encode()).hexdigest()[:16],16));ai=rr.choice(inf)
        elif method=='TOS_FULL_SEQUENTIAL_DIN_POLICY':
            q=tos_action(task,state,True); ai=q if isinstance(q,int) else None
        elif method=='TOS_NO_DIN_REENTRY':
            ai=open_seq[used] if used < len(open_seq) else None; used+=1
        elif method=='OPEN_LOOP_BATCH_DESIGN':
            ai=open_seq[used] if used < len(open_seq) else None; used+=1
        if ai is None:break
        act=task['actions'][ai];bit=act['bits'][truth_idx];new=tuple(i for i in state if act['bits'][i]==bit)
        if len(new)==len(state):break
        seq.append(ai);state=new;steps+=1
    return {'closed':closed(task,state),'steps':steps,'residual_entropy':state_entropy(task,state),'state':state,'sequence':seq,'abstained':steps==0}

def eval_expected(task,method,H):
    # Average over each model as possible truth under uniform prior.
    rows=[execute_policy(task,method,H,i) for i in range(len(task['S']))]
    return {'closure_prob':float(np.mean([r['closed'] for r in rows])),'expected_entropy':float(np.mean([r['residual_entropy'] for r in rows])),'expected_steps':float(np.mean([r['steps'] for r in rows])),'abstention_rate':float(np.mean([r['abstained'] for r in rows])),'seq_hash':whash([r['sequence'] for r in rows])}

def domain_transform(domain,S):
    mats={
      'graph':np.array([[1,0,1],[0,1,-1],[1,1,0]],float),
      'algebra':np.array([[1,1,0],[0,1,1],[-1,0,1]],float),
      'number':np.array([[2,1,0],[0,1,-1],[1,0,1]],float),
      'mechanics':np.array([[1,-1,0],[1,1,1],[0,1,2]],float),
    }
    return S@mats[domain].T

def random_points(domain,rng,n=N):
    seen=set();pts=[]
    while len(pts)<n:
        p=tuple(rng.randint(-4,4) for _ in range(P))
        if p==(0,0,0) or p in seen:continue
        seen.add(p);pts.append(p)
    return domain_transform(domain,np.asarray(pts,float))

def label_assignment(rng,n,classes):
    while True:
        lab=[rng.randrange(classes) for _ in range(n)]
        if len(set(lab))==classes and all(lab.count(k)>=1 for k in range(classes)):return tuple(lab)

def structural_task(domain,regime,seed,require_gap=True):
    rng=random.Random(seed)
    if regime=='C':
        S=random_points(domain,rng,1); return finalize_task(domain,regime,seed,S,(0,),(0,))
    if regime=='N':
        p=random_points(domain,rng,1)[0];S=np.vstack([p,p]);return finalize_task(domain,regime,seed,S,(0,1),(0,0))
    for attempt in range(200):
        S=random_points(domain,rng,N); acts=enumerate_actions(S)
        if len(acts)<4:continue
        if regime=='A': fam=label_assignment(rng,N,3);tar=(0,)*N
        else: tar=label_assignment(rng,N,3);fam=label_assignment(rng,N,3)
        t=finalize_task(domain,regime,seed*1000+attempt,S,fam,tar,acts)
        # structural admission only: claim is unresolved initially and at least two informative actions exist.
        if closed(t,tuple(range(N))):continue
        t['generation_certificate']={'actions':len(acts),'initial_claim_entropy':state_entropy(t,tuple(range(N)))}
        return t
    raise RuntimeError(f'could not generate {domain} {regime}')

def finalize_task(domain,regime,seed,S,fam,tar,acts=None):
    if acts is None:acts=enumerate_actions(S)
    return {'task_id':f'g37_{domain}_{regime}_{seed}','domain':domain,'regime':regime,'S':np.asarray(S,float),'family_labels':tuple(fam),'target_labels':tuple(tar),'actions':acts,'truth_idx':0}

def generate_tasks():
    tasks=[]
    for di,d in enumerate(DOMAINS):
        for reg,count in [('A',4),('B',4),('C',2),('N',1)]:
            for k in range(count):tasks.append(structural_task(d,reg,SEED+di*10000+ord(reg)*100+k,require_gap=reg in ('A','B')))
    return tasks

def mean(rows,key):
    v=[r[key] for r in rows];return float(np.mean(v)) if v else None

def bootstrap_delta(pairs,nboot=4000,seed=991):
    d=np.asarray([a-b for a,b in pairs],float);rng=np.random.default_rng(seed)
    if len(d)==0:return [None,None]
    vals=np.array([np.mean(rng.choice(d,size=len(d),replace=True)) for _ in range(nboot)])
    return [float(np.quantile(vals,.025)),float(np.quantile(vals,.975))]

def main():
    out=Path(os.environ.get('G37_WORKDIR','/mnt/data/g37_work'));res=out/'results';ev=out/'evidence';res.mkdir(parents=True,exist_ok=True);ev.mkdir(parents=True,exist_ok=True)
    t0=time.perf_counter();tasks=generate_tasks();truth=[];rows=[]
    for t in tasks:
        truth.append({'task_id':t['task_id'],'domain':t['domain'],'regime':t['regime'],'S':t['S'],'family_labels':t['family_labels'],'target_labels':t['target_labels'],'n_actions':len(t['actions']),'generation_certificate':t.get('generation_certificate')})
        for H in HORIZONS:
            for m in METHODS:
                q=eval_expected(t,m,H)
                rows.append({'task_id':t['task_id'],'domain':t['domain'],'regime':t['regime'],'horizon':H,'method':m,**q})
    active=[r for r in rows if r['regime'] in ('A','B')]
    summary={'program_id':PROGRAM_ID,'version':VERSION,'task_count':len(tasks),'elapsed_s':time.perf_counter()-t0,'by_horizon':{},'by_domain_h3':{},'generation':{}}
    for H in HORIZONS:
        summary['by_horizon'][str(H)]={}
        for m in METHODS:
            rr=[r for r in active if r['horizon']==H and r['method']==m]
            summary['by_horizon'][str(H)][m]={'closure_prob':mean(rr,'closure_prob'),'expected_entropy':mean(rr,'expected_entropy'),'expected_steps':mean(rr,'expected_steps')}
    for d in DOMAINS:
        summary['by_domain_h3'][d]={}
        for m in METHODS:
            rr=[r for r in active if r['horizon']==3 and r['domain']==d and r['method']==m]
            summary['by_domain_h3'][d][m]={'closure_prob':mean(rr,'closure_prob'),'expected_entropy':mean(rr,'expected_entropy'),'expected_steps':mean(rr,'expected_steps')}
    # Horizon-resolved sequential re-entry audit.
    def per_task(m,H):return {r['task_id']:r for r in active if r['method']==m and r['horizon']==H}
    comparisons={}
    for H in (2,3,4):
        tosH=per_task('TOS_FULL_SEQUENTIAL_DIN_POLICY',H); noH=per_task('TOS_NO_DIN_REENTRY',H); dpH=per_task('EXACT_DYNAMIC_PROGRAMMING_CONTINUOUS_DESIGN',H); grH=per_task('GREEDY_CONTINUOUS_CLAIM_EIG',H); olH=per_task('OPEN_LOOP_BATCH_DESIGN',H)
        def diffs(a,b,key):return [a[k][key]-b[k][key] for k in a]
        comparisons[str(H)]={
          'tos_minus_no_din_entropy':float(np.mean(diffs(tosH,noH,'expected_entropy'))),
          'tos_minus_no_din_entropy_ci95':bootstrap_delta([(tosH[k]['expected_entropy'],noH[k]['expected_entropy']) for k in tosH],seed=100+H),
          'tos_minus_no_din_closure':float(np.mean(diffs(tosH,noH,'closure_prob'))),
          'tos_minus_no_din_closure_ci95':bootstrap_delta([(tosH[k]['closure_prob'],noH[k]['closure_prob']) for k in tosH],seed=110+H),
          'tos_minus_no_din_steps':float(np.mean(diffs(tosH,noH,'expected_steps'))),
          'tos_minus_no_din_steps_ci95':bootstrap_delta([(tosH[k]['expected_steps'],noH[k]['expected_steps']) for k in tosH],seed=120+H),
          'tos_minus_dp_entropy':float(np.mean(diffs(tosH,dpH,'expected_entropy'))),
          'tos_minus_dp_entropy_ci95':bootstrap_delta([(tosH[k]['expected_entropy'],dpH[k]['expected_entropy']) for k in tosH],seed=130+H),
          'tos_minus_dp_closure':float(np.mean(diffs(tosH,dpH,'closure_prob'))),
          'tos_minus_dp_closure_ci95':bootstrap_delta([(tosH[k]['closure_prob'],dpH[k]['closure_prob']) for k in tosH],seed=140+H),
          'tos_minus_dp_steps':float(np.mean(diffs(tosH,dpH,'expected_steps'))),
          'tos_minus_dp_steps_ci95':bootstrap_delta([(tosH[k]['expected_steps'],dpH[k]['expected_steps']) for k in tosH],seed=150+H),
          'tos_minus_greedy_steps':float(np.mean(diffs(tosH,grH,'expected_steps'))),
          'dp_minus_openloop_steps':float(np.mean(diffs(dpH,olH,'expected_steps'))),
        }
    # Exact admissible-intervention identifiability at H=4.
    unresolved=[]
    for t in tasks:
        if t['regime'] not in ('A','B'):continue
        bad=[]
        for i in range(len(t['S'])):
            rr=execute_policy(t,'EXACT_DYNAMIC_PROGRAMMING_CONTINUOUS_DESIGN',4,i)
            if not rr['closed']:bad.append(i)
        if bad:unresolved.append({'task_id':t['task_id'],'domain':t['domain'],'regime':t['regime'],'unresolved_truth_indices':bad,'count':len(bad)})
    adjud={
      'program_id':PROGRAM_ID,
      'material_gate':'PASS_LOCAL',
      'active_tasks':len(per_task('TOS_FULL_SEQUENTIAL_DIN_POLICY',4)),
      'horizons':list(HORIZONS),
      'horizon_curve':{h:{m:summary['by_horizon'][h][m] for m in ('TOS_FULL_SEQUENTIAL_DIN_POLICY','TOS_NO_DIN_REENTRY','EXACT_DYNAMIC_PROGRAMMING_CONTINUOUS_DESIGN','GREEDY_CONTINUOUS_CLAIM_EIG','OPEN_LOOP_BATCH_DESIGN')} for h in summary['by_horizon']},
      'comparisons':comparisons,
      'admissible_identifiability_audit':{'active_truth_branches':sum(len(t['S']) for t in tasks if t['regime'] in ('A','B')),'unresolved_truth_branches':sum(x['count'] for x in unresolved),'unresolved_tasks':unresolved},
      'null_tasks':sum(t['regime']=='N' for t in tasks),
      'null_tos_abstention':float(np.mean([r['abstention_rate'] for r in rows if r['regime']=='N' and r['method']=='TOS_FULL_SEQUENTIAL_DIN_POLICY' and r['horizon']==4])),
      'c_tasks':sum(t['regime']=='C' for t in tasks),
      'c_tos_abstention':float(np.mean([r['abstention_rate'] for r in rows if r['regime']=='C' and r['method']=='TOS_FULL_SEQUENTIAL_DIN_POLICY' and r['horizon']==4])),
      'benchmark_state':'+0_SEQUENTIAL_ACTIVE_CLOSURE_POLICY_BENCHMARK_PROTOFORM',
      'din_policy_state':'+0_REENTRY_POLICY_PROTOFORM_REDUCIBLE',
      'canonical_DIN':'NOT_PROMOTED',
      'authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED'
    }
    # Verdict from the entire horizon curve, not a single cherry-picked horizon.
    c4=adjud['comparisons']['4']; t4=adjud['horizon_curve']['4']['TOS_FULL_SEQUENTIAL_DIN_POLICY']; d4=adjud['horizon_curve']['4']['EXACT_DYNAMIC_PROGRAMMING_CONTINUOUS_DESIGN']
    if c4['tos_minus_no_din_entropy_ci95'][1] < 0 and c4['tos_minus_no_din_closure_ci95'][0] > 0:
        adjud['din_reentry_effect']='LOCAL_SUPPORT_REENTRY_IMPROVES_MATCHED_NO_REENTRY_BY_H4'
    else: adjud['din_reentry_effect']='INCONCLUSIVE_OR_SMALL_REENTRY_EFFECT'
    if abs(t4['expected_entropy']-d4['expected_entropy'])<1e-12 and abs(t4['closure_prob']-d4['closure_prob'])<1e-12 and c4['tos_minus_dp_steps_ci95'][0] > 0:
        adjud['nonreducibility']='NOT_SUPPORTED_TOS_REACHES_ATTAINABLE_CLOSURE_FRONTIER_BUT_IS_COST_INFERIOR_TO_EXACT_DP'
    elif t4['expected_entropy'] > d4['expected_entropy']+1e-12:
        adjud['nonreducibility']='NOT_SUPPORTED_TOS_INFERIOR_TO_EXACT_DYNAMIC_PROGRAMMING'
    else:adjud['nonreducibility']='NOT_SUPPORTED_OR_REQUIRES_AUDIT'
    write_jsonl(ev/'TRUTH_MANIFEST.jsonl',truth);write_jsonl(res/'POLICY_RESULTS.jsonl',rows);write_json(res/'SUMMARY.json',summary);write_json(res/'FINAL_ADJUDICATION.json',adjud)
    report=f'''# G3.7 sequential active closure / DIN policy

Tasks: {len(tasks)}; active: {adjud['active_tasks']}; horizons: {HORIZONS}.

At H=4, TOS and exact DP reach the same attainable closure frontier: closure={t4['closure_prob']:.9f}, residual entropy={t4['expected_entropy']:.9f} bits.
Matched no-DIN closure={adjud['horizon_curve']['4']['TOS_NO_DIN_REENTRY']['closure_prob']:.9f}, entropy={adjud['horizon_curve']['4']['TOS_NO_DIN_REENTRY']['expected_entropy']:.9f}.
TOS-minus-noDIN entropy={c4['tos_minus_no_din_entropy']:.9f}, CI={c4['tos_minus_no_din_entropy_ci95']}; closure={c4['tos_minus_no_din_closure']:.9f}, CI={c4['tos_minus_no_din_closure_ci95']}.
TOS expected steps={t4['expected_steps']:.9f}; exact DP expected steps={d4['expected_steps']:.9f}; delta={c4['tos_minus_dp_steps']:.9f}, CI={c4['tos_minus_dp_steps_ci95']}.

Re-entry effect: {adjud['din_reentry_effect']}.
Nonreducibility: {adjud['nonreducibility']}.
Admissible-intervention unresolved branches: {adjud['admissible_identifiability_audit']['unresolved_truth_branches']} / {adjud['admissible_identifiability_audit']['active_truth_branches']}.
'''
    (res/'REPORT.md').write_text(report)
    manifest={'program_id':PROGRAM_ID,'version':VERSION,'seed':SEED,'truth_sha256':hashlib.sha256((ev/'TRUTH_MANIFEST.jsonl').read_bytes()).hexdigest(),'results_sha256':hashlib.sha256((res/'POLICY_RESULTS.jsonl').read_bytes()).hexdigest(),'adjudication_sha256':hashlib.sha256((res/'FINAL_ADJUDICATION.json').read_bytes()).hexdigest()}
    write_json(res/'RUN_MANIFEST.json',manifest)
    print(json.dumps(adjud,indent=2,sort_keys=True))

if __name__=='__main__':main()
