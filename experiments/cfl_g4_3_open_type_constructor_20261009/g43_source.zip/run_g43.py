#!/usr/bin/env python3
from __future__ import annotations
import dataclasses, hashlib, itertools, json, math, os, random, statistics
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import numpy as np

PROGRAM_ID='CFL-UEP-G4.3-OPEN-TYPE-CONSTRUCTOR-AND-SIGNATURE-GRAMMAR-GENESIS'
VERSION='0.1.0'
SEED=430929
VALUES=range(4)
TAGS=range(2)
# Common black-box probes: (x, context/history bit, carrier-size bit, function-code bit)
QUERIES=tuple((x,c,s,f) for x in range(4) for c in range(2) for s in range(2) for f in range(2))
QINDEX={q:i for i,q in enumerate(QUERIES)}

GAMMA0_CONSTRUCTORS=(
 'T0_UNARY','T0_BINARY','T0_REL','T0_CLOSURE',
 'G42_PARTIAL','G42_SET','G42_PAIR','G42_QUOTIENT','G42_VARIADIC'
)
DEV_CONSTRUCTORS=('DEV_RECURSIVE_LIST','DEV_DYNAMIC_MULTISORT')
PRIVATE_CONSTRUCTORS=('DEPENDENT_CODOMAIN','HISTORY_TRANSDUCER','POLYMORPHIC_FAMILY','HIGHER_KIND_OPERATOR')

# ---------- canonical IO ----------
def canon(x):
    if dataclasses.is_dataclass(x): return canon(asdict(x))
    if isinstance(x,dict): return {str(k):canon(x[k]) for k in sorted(x,key=str)}
    if isinstance(x,(list,tuple)): return [canon(v) for v in x]
    if isinstance(x,set): return sorted(canon(v) for v in x)
    if isinstance(x,np.generic): return x.item()
    if isinstance(x,float): return None if not math.isfinite(x) else float(x)
    return x

def cjson(x): return json.dumps(canon(x),sort_keys=True,separators=(',',':'),ensure_ascii=False)
def h(x): return hashlib.sha256(cjson(x).encode()).hexdigest()
def write_json(p:Path,x): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(canon(x),indent=2,sort_keys=True)+'\n')
def write_jsonl(p:Path,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w') as f:
        for r in rows:f.write(cjson(r)+'\n')

@dataclass(frozen=True)
class Model:
    mid:str
    constructor:str
    signature:str
    params:tuple[int,...]
    table:tuple[tuple[int,int],...]
    operator_class:str
    scope:str

@dataclass
class Task:
    task_id:str
    split:str
    regime:str
    truth_mid:str|None
    demos:tuple[tuple[int,tuple[int,int]],...]
    query_pool:tuple[int,...]
    pre_ids:tuple[str,...]
    candidate_scope:tuple[str,...]

@dataclass
class Pred:
    method:str
    state:str
    constructor_state:str
    signature_state:str
    operator_state:str
    chosen_queries:tuple[int,...]
    post_ids:tuple[str,...]
    form:bool
    sealed_pass:bool

# ---------- model universe ----------
def resp_gamma0(kind:str, p:tuple[int,...], q:tuple[int,int,int,int])->tuple[int,int]:
    x,c,s,f=q; a,b=p[:2]
    # Critical Gamma0 invariant: fixed sort-tag 0; response ignores context, size and function-code.
    if kind in ('T0_UNARY','G42_PARTIAL','G42_SET','G42_PAIR','G42_QUOTIENT','G42_VARIADIC','T0_CLOSURE'):
        y=(a*x+b)%4
    elif kind=='T0_BINARY':
        y=(a*x+b*((x+1)%4))%4
    else: # relation
        y=int(((a*x+b)%4)%2==0)
    return (0,y)

def resp_new(kind:str, sigmode:int, p:tuple[int,...], q:tuple[int,int,int,int])->tuple[int,int]:
    x,c,s,f=q; a,b,k=p
    base=(a*x+b)%4
    if kind=='DEPENDENT_CODOMAIN':
        # New constructor: output sort itself depends on input value.
        tag=(x%2) if sigmode==0 else int(x>=2)
        return (tag,(base+k*tag)%4)
    if kind=='HISTORY_TRANSDUCER':
        # New constructor: same current x can map differently under different observational history/context.
        eff=c if sigmode==0 else (c ^ (x%2))
        return (0,(base+k*eff)%4)
    if kind=='POLYMORPHIC_FAMILY':
        # New constructor: one law is indexed by carrier-size regime.
        eff=s if sigmode==0 else (s*(1+x%2))
        return (0,(base+k*eff)%4)
    if kind=='HIGHER_KIND_OPERATOR':
        # New constructor: operator takes a function/probe-code as semantic input.
        eff=f if sigmode==0 else (f*(1+(x>=2)))
        return (0,(base+k*eff)%4)
    if kind=='DEV_RECURSIVE_LIST':
        # Development-only constructor: recursion-depth proxy from c+s.
        eff=(c+s)%2 if sigmode==0 else (c+2*s)%3
        return (0,(base+k*eff)%4)
    if kind=='DEV_DYNAMIC_MULTISORT':
        tag=(c^s) if sigmode==0 else (c^f)
        return (tag,(base+k*tag)%4)
    raise KeyError(kind)

def relabel_table(table, perm_val, perm_tag):
    return tuple((perm_tag[t],perm_val[v]) for t,v in table)

def canonical_output_table(table):
    reps=[]
    for pv in itertools.permutations(range(4)):
        for pt in itertools.permutations(range(2)):
            reps.append(tuple((pt[t],pv[v]) for t,v in table))
    return min(reps)

def build_universe():
    models={}
    # Gamma0 bounded grammar: many parameterizations, all obey the same meta-invariants.
    for kind in GAMMA0_CONSTRUCTORS:
        for a in (1,3):
            for b in range(4):
                p=(a,b)
                table=tuple(resp_gamma0(kind,p,q) for q in QUERIES)
                sig=f'{kind}:fixed-flat'
                op=h(('op',canonical_output_table(table)))[:16]
                mid=h((kind,sig,p,table))[:18]
                models[mid]=Model(mid,kind,sig,p,table,op,'GAMMA0')
    # Development + private constructors: 2 signature modes x 2 a x 4 b x 3 k = 48/family.
    for kind,scope in [(k,'DEV') for k in DEV_CONSTRUCTORS]+[(k,'PRIVATE') for k in PRIVATE_CONSTRUCTORS]:
        for sigmode in (0,1):
            for a in (1,3):
                for b in range(4):
                    for k in (1,2,3):
                        p=(a,b,k)
                        table=tuple(resp_new(kind,sigmode,p,q) for q in QUERIES)
                        sig=f'{kind}:schema{sigmode}'
                        # Operator equivalence under arbitrary relabeling of output atoms/tags.
                        op=h(('op',kind,sigmode,canonical_output_table(table)))[:16]
                        mid=h((kind,sig,p,table))[:18]
                        models[mid]=Model(mid,kind,sig,p,table,op,scope)
    return models

MODELS=build_universe()
IDS=tuple(sorted(MODELS))
GAMMA0_IDS=tuple(m for m in IDS if MODELS[m].scope=='GAMMA0')
DEV_IDS=tuple(m for m in IDS if MODELS[m].scope=='DEV')
PRIVATE_IDS=tuple(m for m in IDS if MODELS[m].scope=='PRIVATE')

# ---------- exact hard-boundary certificates ----------
def gamma0_invariants_hold(m:Model)->bool:
    # fixed tag 0; for fixed x, output independent of (c,s,f)
    for q,r in zip(QUERIES,m.table):
        if r[0]!=0:return False
    for x in range(4):
        vals={m.table[QINDEX[(x,c,s,f)]] for c in range(2) for s in range(2) for f in range(2)}
        if len(vals)!=1:return False
    return True

def outside_gamma0_witness(m:Model):
    # Returns a deterministic exact witness to a Gamma0 invariant violation.
    for q,r in zip(QUERIES,m.table):
        if r[0]!=0:return {'kind':'dependent-output-sort','query':q,'response':r}
    for x in range(4):
        base=m.table[QINDEX[(x,0,0,0)]]
        for c,s,f in itertools.product(range(2),repeat=3):
            q=(x,c,s,f); rr=m.table[QINDEX[q]]
            if rr!=base:
                axis='context' if c else ('carrier-size' if s else 'function-code')
                return {'kind':f'depends-on-{axis}','q0':(x,0,0,0),'q1':q,'r0':base,'r1':rr}
    return None

# ---------- task mechanics ----------
def response(mid,qid): return MODELS[mid].table[qid]
def compatible(ids,demos): return tuple(sorted(mid for mid in ids if all(response(mid,q)==r for q,r in demos)))
def ctor_set(ids): return {MODELS[i].constructor for i in ids}
def sig_set(ids): return {MODELS[i].signature for i in ids}
def op_set(ids): return {MODELS[i].operator_class for i in ids}
def partition(ids,q):
    d={}
    for mid in ids:d.setdefault(response(mid,q),[]).append(mid)
    return {k:tuple(sorted(v)) for k,v in d.items()}

def can_reduce(ids,qpool,claim='operator'):
    cur=op_set(ids) if claim=='operator' else (sig_set(ids) if claim=='signature' else ctor_set(ids))
    if len(cur)<=1:return False
    for q in qpool:
        for cell in partition(ids,q).values():
            vv=op_set(cell) if claim=='operator' else (sig_set(cell) if claim=='signature' else ctor_set(cell))
            if len(vv)<len(cur):return True
    return False

def claim_state(ids,qpool,claim):
    if not ids:return '-1'
    vals=op_set(ids) if claim=='operator' else (sig_set(ids) if claim=='signature' else ctor_set(ids))
    if len(vals)==1:return '1'
    return '+0' if can_reduce(ids,qpool,claim) else '0'

def query_score(ids,q,mode):
    cells=partition(ids,q)
    if mode=='TYPE_GRAMMAR_MUTATION':
        prof=[]
        for c in cells.values(): prof.append((len(ctor_set(c)),len(sig_set(c)),len(op_set(c)),len(c)))
        return (max(x[0] for x in prof),max(x[1] for x in prof),max(x[2] for x in prof),max(x[3] for x in prof),sum(len(c)**2 for c in cells.values()),q)
    if mode=='EXACT_OPERATOR_MINIMAX':return (max(len(op_set(c)) for c in cells.values()),max(len(c) for c in cells.values()),q)
    if mode=='EXACT_EIG_QUERY':
        n=len(ids); exp=sum((len(c)/n)*math.log(max(1,len(c))) for c in cells.values());return (exp,q)
    if mode=='MDL_SIGNATURE_INDUCTION':
        # Exact structural MDL proxy: prioritize constructor, then signature, then population.
        prof=[(len(ctor_set(c)),len(sig_set(c)),len(c)) for c in cells.values()]
        return (sum(x[0] for x in prof),sum(x[1] for x in prof),sum(x[2]**2 for x in prof),q)
    if mode=='TOS_FULL_TYPE_CONSTRUCTOR_GENESIS':
        # Non-probabilistic Phi/O3 score: minimize worst residual fiber in constructor -> signature -> operator hierarchy.
        prof=sorted((len(ctor_set(c)),len(sig_set(c)),len(op_set(c)),len(c)) for c in cells.values())
        return (max(x[0] for x in prof),max(x[1] for x in prof),max(x[2] for x in prof),tuple(sorted(prof,reverse=True)),q)
    raise KeyError(mode)

def choose_query(task,ids,qpool,method,step):
    if not qpool:return None
    if method=='RANDOM_QUERY':return qpool[int(task.task_id[:8],16+0)%len(qpool)]
    if method in ('T0_GRAMMAR_ENUMERATION','UNIVERSAL_TABLE_COMPLETION'):return None
    return min(qpool,key=lambda q:query_score(ids,q,method))

def sealed_certificate(truth:Model, inferred_ids):
    # Independent output relabeling; structural class must remain singleton and truth class retained.
    pv=(2,0,3,1);pt=(1,0)
    truth_can=canonical_output_table(relabel_table(truth.table,pv,pt))
    if truth_can!=canonical_output_table(truth.table):return False
    return len(ctor_set(inferred_ids))==1 and len(sig_set(inferred_ids))==1 and len(op_set(inferred_ids))==1 and truth.operator_class in op_set(inferred_ids)

METHODS=('T0_GRAMMAR_ENUMERATION','TYPE_GRAMMAR_MUTATION','EXACT_OPERATOR_MINIMAX','EXACT_EIG_QUERY','MDL_SIGNATURE_INDUCTION','TOS_FULL_TYPE_CONSTRUCTOR_GENESIS','RANDOM_QUERY','UNIVERSAL_TABLE_COMPLETION')

def evaluate(task,method,budget=3):
    if task.regime=='ANTI':
        ids=task.pre_ids
    elif method=='T0_GRAMMAR_ENUMERATION':
        ids=tuple(i for i in task.pre_ids if MODELS[i].scope=='GAMMA0')
    else:ids=task.pre_ids
    qpool=list(task.query_pool); chosen=[]
    for step in range(budget):
        if not ids or (len(ctor_set(ids))==1 and len(sig_set(ids))==1 and len(op_set(ids))==1):break
        q=choose_query(task,ids,qpool,method,step)
        if q is None:break
        chosen.append(q);qpool.remove(q)
        if task.truth_mid is None:
            # anti tasks are already contradiction-filtered; no oracle response.
            break
        rr=response(task.truth_mid,q);ids=tuple(sorted(i for i in ids if response(i,q)==rr))
    ctor=claim_state(ids,tuple(qpool),'constructor'); sig=claim_state(ids,tuple(qpool),'signature'); op=claim_state(ids,tuple(qpool),'operator')
    form=(ctor=='1' and sig=='1' and op=='1')
    sealed=False
    if form and task.truth_mid is not None:sealed=sealed_certificate(MODELS[task.truth_mid],ids)
    # universal table completion can predict a table but is categorically barred from type/operator Form.
    if method=='UNIVERSAL_TABLE_COMPLETION':form=False;ctor=sig=op='0';sealed=False
    return Pred(method,'1' if form and sealed else ('-1' if not ids else ('+0' if any(s=='+0' for s in (ctor,sig,op)) else '0')),ctor,sig,op,tuple(chosen),ids,bool(form and sealed),sealed)

# ---------- task generation ----------
def neutral_queries(kind):
    # Neutralizes the private constructor-specific metadimension as much as possible.
    if kind=='DEPENDENT_CODOMAIN':return [QINDEX[(0,c,s,f)] for c in range(2) for s in range(2) for f in range(2)]
    if kind=='HISTORY_TRANSDUCER':return [QINDEX[(x,0,s,f)] for x in range(4) for s in range(2) for f in range(2)]
    if kind=='POLYMORPHIC_FAMILY':return [QINDEX[(x,c,0,f)] for x in range(4) for c in range(2) for f in range(2)]
    if kind=='HIGHER_KIND_OPERATOR':return [QINDEX[(x,c,s,0)] for x in range(4) for c in range(2) for s in range(2)]
    return list(range(len(QUERIES)))

def generate_primary(kind,seed):
    rng=random.Random(seed); truths=[i for i in PRIVATE_IDS if MODELS[i].constructor==kind]
    for _ in range(3000):
        truth=rng.choice(truths); neutral=neutral_queries(kind); demos_q=tuple(sorted(rng.sample(neutral,3)))
        demos=tuple((q,response(truth,q)) for q in demos_q);pre=compatible(IDS,demos)
        if truth not in pre or len(ctor_set(pre))<2 or len(sig_set(pre))<2 or len(op_set(pre))<2:continue
        pool=tuple(q for q in range(len(QUERIES)) if q not in demos_q)
        # Require TOS and mutation can close within budget, ensuring an informative primary tribunal.
        t=Task(h((kind,seed,demos_q))[:20],'PRIVATE','PRIMARY',truth,demos,pool,pre,('ALL',))
        if evaluate(t,'TOS_FULL_TYPE_CONSTRUCTOR_GENESIS').form and evaluate(t,'TYPE_GRAMMAR_MUTATION').form:return t
    raise RuntimeError('primary generation failed '+kind)

def generate_already_form(kind,seed):
    rng=random.Random(seed);truths=[i for i in PRIVATE_IDS if MODELS[i].constructor==kind]
    for _ in range(1000):
        truth=rng.choice(truths);qs=tuple(sorted(rng.sample(range(len(QUERIES)),12)));demos=tuple((q,response(truth,q)) for q in qs);pre=compatible(IDS,demos)
        if len(ctor_set(pre))==len(sig_set(pre))==len(op_set(pre))==1:return Task(h((kind,'form',seed,qs))[:20],'PRIVATE','ALREADY_FORM',truth,demos,tuple(q for q in range(len(QUERIES)) if q not in qs),pre,('ALL',))
    raise RuntimeError('form generation failed')

def generate_dev(kind,seed):
    rng=random.Random(seed);truths=[i for i in DEV_IDS if MODELS[i].constructor==kind]
    truth=rng.choice(truths);qs=tuple(sorted(rng.sample(range(len(QUERIES)),5)));demos=tuple((q,response(truth,q)) for q in qs);pre=compatible(IDS,demos)
    return Task(h((kind,'dev',seed,qs))[:20],'DEV','DEV',truth,demos,tuple(q for q in range(len(QUERIES)) if q not in qs),pre,('ALL',))

def generate_negative(seed):
    # Create two observationally identical shadow semantics with different constructors: permanent type nonidentifiability.
    rng=random.Random(seed); base=rng.choice(list(PRIVATE_IDS)); m=MODELS[base]
    a=f'SHADOW_A_{seed}'; b=f'SHADOW_B_{seed}'
    # Temporarily represented via synthetic global-free task semantics by using two real models with identical full table if available.
    same=[i for i in IDS if MODELS[i].table==m.table and MODELS[i].constructor!=m.constructor]
    if same:
        ids=(base,same[0]);truth=base
    else:
        # fallback: operator-equivalent models of distinct private constructors on neutral table; search exhaustive.
        pair=None
        bytab={}
        for i in IDS:bytab.setdefault(MODELS[i].table,[]).append(i)
        for arr in bytab.values():
            if len({MODELS[i].constructor for i in arr})>1:pair=(arr[0],next(i for i in arr if MODELS[i].constructor!=MODELS[arr[0]].constructor));break
        if pair is None:
            # deterministic synthetic negative built from two IDs with a restricted query pool on which they are identical forever.
            truth=base; other=next(i for i in IDS if MODELS[i].constructor!=m.constructor)
            equal=[q for q in range(len(QUERIES)) if response(truth,q)==response(other,q)]
            if len(equal)<5:return generate_negative(seed+10007)
            demos_q=tuple(equal[:2]); demos=tuple((q,response(truth,q)) for q in demos_q); ids=(truth,other); pool=tuple(equal[2:])
            return Task(h(('neg',seed,truth,other))[:20],'PRIVATE','NEGATIVE_TYPE',truth,demos,pool,ids,('SHADOW',))
        ids=pair;truth=pair[0]
    demos_q=(0,);demos=((0,response(truth,0)),);return Task(h(('neg',seed,ids))[:20],'PRIVATE','NEGATIVE_TYPE',truth,demos,tuple(range(1,len(QUERIES))),tuple(ids),('SHADOW',))

def generate_anti(seed):
    rng=random.Random(seed); q=rng.randrange(len(QUERIES)); impossible=(9,9); demos=((q,impossible),); pre=compatible(IDS,demos)
    assert not pre
    return Task(h(('anti',seed,q))[:20],'PRIVATE','ANTI',None,demos,tuple(i for i in range(len(QUERIES)) if i!=q),pre,('ALL',))

def generate_tasks():
    tasks=[]
    for j,k in enumerate(DEV_CONSTRUCTORS):
        for i in range(5):tasks.append(generate_dev(k,SEED+j*1000+i))
    for j,k in enumerate(PRIVATE_CONSTRUCTORS):
        for i in range(4):tasks.append(generate_primary(k,SEED+10000+j*1000+i))
        for i in range(7):tasks.append(generate_already_form(k,SEED+20000+j*1000+i))
    for i in range(10):tasks.append(generate_negative(SEED+30000+i))
    for i in range(16):tasks.append(generate_anti(SEED+40000+i))
    return tasks

# ---------- statistics ----------
def paired_boot(rows,a,b,n=3000):
    aa={r['task_id']:int(r['form']) for r in rows if r['method']==a and r['regime']=='PRIMARY'};bb={r['task_id']:int(r['form']) for r in rows if r['method']==b and r['regime']=='PRIMARY'};ids=sorted(set(aa)&set(bb));d=np.array([aa[i]-bb[i] for i in ids],float);rng=np.random.default_rng(SEED);bs=[float(np.mean(rng.choice(d,size=len(d),replace=True))) for _ in range(n)];return {'delta':float(d.mean()),'ci':[float(np.quantile(bs,.025)),float(np.quantile(bs,.975))],'n':len(d)}

def main():
    out=Path(os.environ.get('G43_WORKDIR','/mnt/data/CFL_G4_3_TYPE_CONSTRUCTOR_RUN'));out.mkdir(parents=True,exist_ok=True)
    tasks=generate_tasks(); rows=[]
    for t in tasks:
        for method in METHODS:
            p=evaluate(t,method)
            rows.append({'task_id':t.task_id,'split':t.split,'regime':t.regime,'truth_constructor':None if t.truth_mid is None else MODELS[t.truth_mid].constructor,'method':method,'state':p.state,'constructor_state':p.constructor_state,'signature_state':p.signature_state,'operator_state':p.operator_state,'form':p.form,'sealed_pass':p.sealed_pass,'chosen_queries':p.chosen_queries,'pre_n':len(t.pre_ids),'post_n':len(p.post_ids)})
    write_jsonl(out/'results'/'PREDICTIONS.jsonl',rows)
    write_jsonl(out/'evidence'/'TASKS.jsonl',[{'task_id':t.task_id,'split':t.split,'regime':t.regime,'truth_constructor':None if t.truth_mid is None else MODELS[t.truth_mid].constructor,'truth_signature':None if t.truth_mid is None else MODELS[t.truth_mid].signature,'truth_operator':None if t.truth_mid is None else MODELS[t.truth_mid].operator_class,'demos':t.demos,'query_pool':t.query_pool,'pre_n':len(t.pre_ids),'pre_constructor_n':len(ctor_set(t.pre_ids)),'pre_signature_n':len(sig_set(t.pre_ids)),'pre_operator_n':len(op_set(t.pre_ids))} for t in tasks])
    summary={}
    for m in METHODS:
        z=[r for r in rows if r['method']==m]; pri=[r for r in z if r['regime']=='PRIMARY']; neg=[r for r in z if r['regime']=='NEGATIVE_TYPE']; anti=[r for r in z if r['regime']=='ANTI']; construct=[r for r in z if r['regime'] in ('PRIMARY','ALREADY_FORM')]
        summary[m]={'primary_forms':sum(r['form'] for r in pri),'primary_n':len(pri),'primary_form_rate':sum(r['form'] for r in pri)/len(pri) if pri else None,'construct_forms':sum(r['form'] for r in construct),'construct_n':len(construct),'negative_type_forms':sum(r['form'] for r in neg),'anti_minus_one':sum(r['state']=='-1' for r in anti)}
    write_json(out/'results'/'SUMMARY.json',summary)
    best=max((m for m in METHODS if m not in ('TOS_FULL_TYPE_CONSTRUCTOR_GENESIS','RANDOM_QUERY','T0_GRAMMAR_ENUMERATION','UNIVERSAL_TABLE_COMPLETION')),key=lambda m:summary[m]['primary_form_rate'])
    boot=paired_boot(rows,'TOS_FULL_TYPE_CONSTRUCTOR_GENESIS',best)
    # hard boundary audit
    priv_truths=[MODELS[t.truth_mid] for t in tasks if t.split=='PRIVATE' and t.truth_mid and t.regime in ('PRIMARY','ALREADY_FORM')]
    outside=[outside_gamma0_witness(m) for m in priv_truths]
    dev_types={MODELS[t.truth_mid].constructor for t in tasks if t.split=='DEV' and t.truth_mid};priv_types={m.constructor for m in priv_truths}
    audit={'universe_models':len(MODELS),'gamma0_models':len(GAMMA0_IDS),'dev_models':len(DEV_IDS),'private_models':len(PRIVATE_IDS),'private_construct_n':len(priv_truths),'all_private_outside_gamma0':all(w is not None for w in outside),'outside_gamma0_witnesses':outside,'dev_private_constructor_overlap':sorted(dev_types&priv_types),'primary_initially_constructor_signature_operator_ambiguous':all(len(ctor_set(t.pre_ids))>1 and len(sig_set(t.pre_ids))>1 and len(op_set(t.pre_ids))>1 for t in tasks if t.regime=='PRIMARY'),'negative_type_n':sum(t.regime=='NEGATIVE_TYPE' for t in tasks),'anti_n':sum(t.regime=='ANTI' for t in tasks)}
    write_json(out/'audit'/'EXACT_AUDIT.json',audit)
    tos=summary['TOS_FULL_TYPE_CONSTRUCTOR_GENESIS']; outcome='G4_3_LOCAL_SUPPORT' if boot['delta']>=.02 and boot['ci'][0]>0 else ('G4_3_BASELINE_EQUIVALENT' if boot['delta']==0 else 'G4_3_NO_SUPPORT_POINT_ESTIMATE_INFERIOR')
    adj={'program_id':PROGRAM_ID,'version':VERSION,'outcome':outcome,'constructor_genesis_relative_to_gamma0':audit['all_private_outside_gamma0'],'private_construct_n':len(priv_truths),'primary_tos_forms':tos['primary_forms'],'primary_n':tos['primary_n'],'strongest_valid_baseline':best,'baseline_primary_forms':summary[best]['primary_forms'],'paired_bootstrap':boot,'negative_type_forms_tos':summary['TOS_FULL_TYPE_CONSTRUCTOR_GENESIS']['negative_type_forms'],'anti_minus_one_tos':summary['TOS_FULL_TYPE_CONSTRUCTOR_GENESIS']['anti_minus_one'],'dev_private_constructor_overlap':audit['dev_private_constructor_overlap'],'form_semantics':'CATEGORICAL_NONPROBABILISTIC_ONLY','scope_limit':'Private constructors violate Gamma0 meta-invariants, but the experiment still supplies a bounded higher-level mutation vocabulary naming dependence on input, history, carrier-size and operator-code. Fully open meta-constructor invention is not established.','benchmark_state':'+0_TYPE_CONSTRUCTOR_GENESIS_BENCHMARK_PROTOFORM','authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED'}
    write_json(out/'results'/'FINAL_ADJUDICATION.json',adj)
    write_json(out/'results'/'RUN_MANIFEST.json',{'program_id':PROGRAM_ID,'version':VERSION,'models':len(MODELS),'tasks':len(tasks),'rows':len(rows),'task_hash':h([asdict(t) for t in tasks]),'adjudication':adj})
    print(json.dumps(adj,indent=2))

if __name__=='__main__':main()
