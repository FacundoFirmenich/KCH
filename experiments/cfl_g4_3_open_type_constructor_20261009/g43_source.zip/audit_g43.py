#!/usr/bin/env python3
import json, os, runpy, pathlib, hashlib, collections
RUNNER=os.environ.get('G43_RUNNER','/mnt/data/run_g43.py')
WORK=pathlib.Path(os.environ.get('G43_WORKDIR','/mnt/data/CFL_G4_3_TYPE_CONSTRUCTOR_RUN'))
m=runpy.run_path(RUNNER,run_name='g43lib')
tasks=m['generate_tasks'](); rows=[json.loads(x) for x in open(WORK/'results/PREDICTIONS.jsonl')]
priv_construct=[t for t in tasks if t.split=='PRIVATE' and t.truth_mid and t.regime in ('PRIMARY','ALREADY_FORM')]
private_models=[m['MODELS'][t.truth_mid] for t in priv_construct]
checks={}
checks['private_construct_44']=len(priv_construct)==44
checks['all_private_outside_gamma0']=all(m['outside_gamma0_witness'](x) is not None for x in private_models)
checks['dev_private_constructor_overlap_zero']=not ({m['MODELS'][t.truth_mid].constructor for t in tasks if t.split=='DEV' and t.truth_mid}&{x.constructor for x in private_models})
checks['primary_16']=sum(t.regime=='PRIMARY' for t in tasks)==16
checks['primary_initial_threefold_ambiguity']=all(len(m['ctor_set'](t.pre_ids))>1 and len(m['sig_set'](t.pre_ids))>1 and len(m['op_set'](t.pre_ids))>1 for t in tasks if t.regime=='PRIMARY')
checks['tos_primary_16_16']=sum(r['form'] for r in rows if r['method']=='TOS_FULL_TYPE_CONSTRUCTOR_GENESIS' and r['regime']=='PRIMARY')==16
checks['mutation_primary_16_16']=sum(r['form'] for r in rows if r['method']=='TYPE_GRAMMAR_MUTATION' and r['regime']=='PRIMARY')==16
checks['all_tos_construct_forms_sealed']=all(r['sealed_pass'] for r in rows if r['method']=='TOS_FULL_TYPE_CONSTRUCTOR_GENESIS' and r['regime'] in ('PRIMARY','ALREADY_FORM') and r['form'])
checks['negative_type_no_forms']=sum(r['form'] for r in rows if r['method']=='TOS_FULL_TYPE_CONSTRUCTOR_GENESIS' and r['regime']=='NEGATIVE_TYPE')==0
checks['negative_type_all_zero']=all(r['state']=='0' for r in rows if r['method']=='TOS_FULL_TYPE_CONSTRUCTOR_GENESIS' and r['regime']=='NEGATIVE_TYPE')
checks['anti_all_minus_one']=all(r['state']=='-1' for r in rows if r['method']=='TOS_FULL_TYPE_CONSTRUCTOR_GENESIS' and r['regime']=='ANTI')
checks['gamma0_control_zero_forms']=sum(r['form'] for r in rows if r['method']=='T0_GRAMMAR_ENUMERATION' and r['split']=='PRIVATE')==0
checks['table_control_zero_forms']=sum(r['form'] for r in rows if r['method']=='UNIVERSAL_TABLE_COMPLETION' and r['split']=='PRIVATE')==0
# representation-independent witness breakdown
witnesses=[m['outside_gamma0_witness'](x) for x in private_models]
wb=collections.Counter(w['kind'] for w in witnesses)
# family primary closure
fam={}
for f in m['PRIVATE_CONSTRUCTORS']:
 z=[r for r in rows if r['method']=='TOS_FULL_TYPE_CONSTRUCTOR_GENESIS' and r['regime']=='PRIMARY' and r['truth_constructor']==f]
 fam[f]={'forms':sum(r['form'] for r in z),'n':len(z),'rate':sum(r['form'] for r in z)/len(z)}
out={'status':'EXACT_AUDIT_PASS' if all(checks.values()) else 'EXACT_AUDIT_FAIL','checks':checks,'pass_count':sum(checks.values()),'total':len(checks),'all_pass':all(checks.values()),'universe_models':len(m['MODELS']),'gamma0_models':len(m['GAMMA0_IDS']),'dev_models':len(m['DEV_IDS']),'private_models':len(m['PRIVATE_IDS']),'outside_gamma0_witness_breakdown':dict(wb),'private_family_primary':fam,'negative_type_states':dict(collections.Counter(r['state'] for r in rows if r['method']=='TOS_FULL_TYPE_CONSTRUCTOR_GENESIS' and r['regime']=='NEGATIVE_TYPE')),'task_hash':m['h']([m['asdict'](t) for t in tasks])}
(WORK/'audit').mkdir(parents=True,exist_ok=True); (WORK/'audit'/'EXACT_AUDIT.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
