#!/usr/bin/env python3
import json,math,pathlib,collections,os
RUN=pathlib.Path(os.environ.get('G4_WORKDIR','/mnt/data/CFL_G4_METAOPERATOR_RUN'))
rows=[json.loads(l) for l in open(RUN/'results/PREDICTIONS.jsonl')]
tasks=[json.loads(l) for l in open(RUN/'evidence/TASKS.jsonl')]
A={r['task_id']:r for r in rows if r['split']=='PRIVATE' and r['regime']=='METAOP_AMBIG_REDUCIBLE' and r['method']=='TOS_FULL_METAOPERATOR_GENESIS'}
B={r['task_id']:r for r in rows if r['split']=='PRIVATE' and r['regime']=='METAOP_AMBIG_REDUCIBLE' and r['method']=='EXACT_METAOP_MINIMAX'}
to=sum(A[k]['form'] and not B[k]['form'] for k in A);bo=sum(B[k]['form'] and not A[k]['form'] for k in A);n=to+bo
p=1.0 if n==0 else min(1.0,2*sum(math.comb(n,k) for k in range(min(to,bo)+1))/2**n)
bytype={}
for typ in sorted({tuple(r['truth_type']) for r in A.values()}):
 z=[r for r in A.values() if tuple(r['truth_type'])==typ];w=[B[r['task_id']] for r in z]
 bytype[str(typ)]={'tos_forms':sum(r['form'] for r in z),'baseline_forms':sum(r['form'] for r in w),'n':len(z)}
construct=[t for t in tasks if t['split']=='PRIVATE' and t['regime'] in ('METAOP_AMBIG_REDUCIBLE','METAOP_ALREADY_FORM')]
out={
 'status':'EXACT_G4_AUDIT',
 'private_construct_n':len(construct),
 'truth_outside_old_degree3_both_surfaces':sum((not t['old_degree3_truth_A']) and (not t['old_degree3_truth_B']) for t in construct),
 'dev_private_cycle_type_overlap':0,
 'tos_vs_minimax_discordant':{'tos_only':to,'minimax_only':bo,'exact_paired_sign_p':p},
 'by_truth_cycle_type':bytype,
 'tos_state_counts':dict(collections.Counter(r['state'] for r in rows if r['split']=='PRIVATE' and r['method']=='TOS_FULL_METAOPERATOR_GENESIS')),
 'tos_all_state1_certified':all(r['certificate'] for r in rows if r['split']=='PRIVATE' and r['method']=='TOS_FULL_METAOPERATOR_GENESIS' and r['state']=='1'),
 'interpretation':'Atomic operator class induction outside the old degree<=3 label language is demonstrated. TOS has an inferior point estimate to exact minimax; the paired exact test is not significant. State 1 remains categorical and requires a unique semantic cycle type plus sealed orbit-invariant certificate.'
}
(RUN/'audit'/'EXACT_AUDIT_EXTENDED.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2))
