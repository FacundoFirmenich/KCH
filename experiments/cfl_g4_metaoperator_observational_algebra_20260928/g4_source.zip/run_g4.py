#!/usr/bin/env python3
from __future__ import annotations
import dataclasses, hashlib, itertools, json, math, os, random, statistics
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np

PROGRAM_ID='CFL-UEP-G4-METAOPERATOR-AND-OBSERVATIONAL-ALGEBRA-GENESIS'
VERSION='0.1.0'
SEED=400928
P=7
ELEMENTS=tuple(range(P))
DEV_TYPES=((2,2,2,1),(3,3,1))
PRIVATE_TYPES=((7,),(5,1,1),(4,2,1),(3,2,1,1))
REGIMES=('METAOP_AMBIG_REDUCIBLE','METAOP_ALREADY_FORM','UNDERIDENTIFIED','ANTI')
MAX_QUERIES=3

# ---------- canonical IO ----------
def canon(x):
    if dataclasses.is_dataclass(x): return canon(asdict(x))
    if isinstance(x,dict): return {str(k):canon(x[k]) for k in sorted(x,key=str)}
    if isinstance(x,(list,tuple,set)): return [canon(v) for v in x]
    if isinstance(x,np.generic): return x.item()
    if isinstance(x,float): return None if not math.isfinite(x) else float(x)
    return x

def cjson(x): return json.dumps(canon(x),sort_keys=True,separators=(',',':'))
def h(x): return hashlib.sha256(cjson(x).encode()).hexdigest()
def write_json(p,x): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(canon(x),indent=2,sort_keys=True)+'\n')
def write_jsonl(p,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w') as f:
        for r in rows:f.write(cjson(r)+'\n')

# ---------- permutation/operator semantics ----------
def compose(a,b): return tuple(a[b[i]] for i in ELEMENTS)  # a o b
def power(pi,k):
    out=tuple(ELEMENTS)
    for _ in range(k): out=compose(pi,out)
    return out

def cycle_type(pi):
    seen=set(); sizes=[]
    for i in ELEMENTS:
        if i in seen: continue
        j=i;n=0
        while j not in seen:
            seen.add(j);n+=1;j=pi[j]
        sizes.append(n)
    return tuple(sorted(sizes,reverse=True))

def cycle_invariants(pi):
    # fixed-point counts of powers 1..7 determine cycle type on 7 points.
    return tuple(sum(power(pi,k)[i]==i for i in ELEMENTS) for k in range(1,P+1))

def perm_from_cycles(ctype,rng):
    pts=list(ELEMENTS);rng.shuffle(pts);pi=list(ELEMENTS);idx=0
    for L in ctype:
        cyc=pts[idx:idx+L];idx+=L
        for a,b in zip(cyc,cyc[1:]+cyc[:1]):pi[a]=b
    return tuple(pi)

def conjugate(pi,rho):
    inv=[0]*P
    for i,j in enumerate(rho):inv[j]=i
    return tuple(rho[pi[inv[i]]] for i in ELEMENTS)

def rank_mod(A,p):
    A=np.array(A,dtype=int)%p;r=0
    for c in range(A.shape[1]):
        piv=next((i for i in range(r,A.shape[0]) if A[i,c]%p),None)
        if piv is None:continue
        A[[r,piv]]=A[[piv,r]];A[r]=(A[r]*pow(int(A[r,c]),-1,p))%p
        for i in range(A.shape[0]):
            if i!=r and A[i,c]%p:A[i]=(A[i]-A[i,c]*A[r])%p
        r+=1
        if r==A.shape[0]:break
    return r

def poly_degree_le3_map(pi):
    # Exact membership in span{1,x,x^2,x^3} over F7.
    X=np.array([[pow(x,k,P) for k in range(4)] for x in ELEMENTS],dtype=int)%P
    y=np.array(pi,dtype=int).reshape(-1,1)%P
    return rank_mod(np.c_[X,y],P)==rank_mod(X,P)

ALL_PERMS=tuple(itertools.permutations(ELEMENTS))
PERMS_BY_TYPE={}
for pi in ALL_PERMS: PERMS_BY_TYPE.setdefault(cycle_type(pi),[]).append(pi)
PERMS_BY_TYPE={k:tuple(v) for k,v in PERMS_BY_TYPE.items()}
ALL_TYPES=tuple(sorted(PERMS_BY_TYPE,key=repr))
OLD_DEG3=set(pi for pi in ALL_PERMS if poly_degree_le3_map(pi))

@dataclass
class Surface:
    sid:str
    truth:tuple[int,...]
    observed:tuple[tuple[int,int],...]

@dataclass
class Task:
    task_id:str
    split:str
    regime:str
    truth_type:tuple[int,...]
    A:Surface
    B:Surface
    C_truth:tuple[int,...]
    query_pool:tuple[tuple[str,int],...]
    initial_types:tuple[tuple[int,...],...]
    initial_A_count:int
    initial_B_count:int

# ---------- candidate filtering ----------
def filter_perms(obs):
    out=[]
    for pi in ALL_PERMS:
        if all(pi[x]==y for x,y in obs):out.append(pi)
    return tuple(out)

def possible_types(perms):return set(cycle_type(pi) for pi in perms)

def joint_types(Aperms,Bperms):return tuple(sorted(possible_types(Aperms)&possible_types(Bperms),key=repr))

def add_obs(perms,x,y):return tuple(pi for pi in perms if pi[x]==y)

def outcome_partition(perms,x):
    d={}
    for pi in perms:d.setdefault(pi[x],[]).append(pi)
    return {y:tuple(v) for y,v in d.items()}

def joint_after(Aperms,Bperms,sid,x,y):
    if sid=='A': Aperms=add_obs(Aperms,x,y)
    else:Bperms=add_obs(Bperms,x,y)
    return Aperms,Bperms,joint_types(Aperms,Bperms)

def query_can_reduce(Aperms,Bperms,qpool):
    cur=len(joint_types(Aperms,Bperms))
    if cur<=1:return False
    for sid,x in qpool:
        ps=Aperms if sid=='A' else Bperms
        for y in outcome_partition(ps,x):
            _,_,tys=joint_after(Aperms,Bperms,sid,x,y)
            if len(tys)<cur:return True
    return False

# ---------- task generation ----------
def make_surface(ctype,rng,sid,nobs):
    # filter truth away from old degree<=3 label arithmetic by random relabeling/conjugation
    for _ in range(200):
        base=perm_from_cycles(ctype,rng);rho=list(ELEMENTS);rng.shuffle(rho);truth=conjugate(base,tuple(rho))
        if truth not in OLD_DEG3:break
    xs=rng.sample(list(ELEMENTS),nobs);obs=tuple((x,truth[x]) for x in xs)
    return Surface(sid,truth,obs)

def make_task(split,regime,seed,maxtries=2000):
    rng=random.Random(seed);types=DEV_TYPES if split=='DEV' else PRIVATE_TYPES
    for _ in range(maxtries):
        ctype=rng.choice(types)
        if regime=='ANTI':
            A=make_surface(ctype,rng,'A',2);B=make_surface(ctype,rng,'B',2)
            x=A.observed[0][0];y=A.observed[0][1];bad=Surface('A',A.truth,A.observed+((x,(y+1)%P),))
            return Task(h((split,regime,seed,bad.observed))[:20],split,regime,ctype,bad,B,perm_from_cycles(ctype,rng),tuple(),tuple(),0,0)
        nobs=4 if regime=='METAOP_ALREADY_FORM' else (1 if regime=='UNDERIDENTIFIED' else 2)
        A=make_surface(ctype,rng,'A',nobs);B=make_surface(ctype,rng,'B',nobs)
        Ap=filter_perms(A.observed);Bp=filter_perms(B.observed);tys=joint_types(Ap,Bp)
        if ctype not in tys:continue
        usedA={x for x,y in A.observed};usedB={x for x,y in B.observed}
        qpool=tuple([('A',x) for x in ELEMENTS if x not in usedA]+[('B',x) for x in ELEMENTS if x not in usedB])
        if regime=='METAOP_ALREADY_FORM' and len(tys)!=1:continue
        if regime=='METAOP_AMBIG_REDUCIBLE' and not (len(tys)>1 and query_can_reduce(Ap,Bp,qpool)):continue
        if regime=='UNDERIDENTIFIED':
            # Require ambiguity survives entire allowed qpool under at least one outcome path? easier: many initial types and low obs.
            if len(tys)<=2:continue
        C=perm_from_cycles(ctype,rng)
        return Task(h((split,regime,seed,ctype,A.observed,B.observed))[:20],split,regime,ctype,A,B,C,qpool,tys,len(Ap),len(Bp))
    raise RuntimeError(f'cannot generate {split} {regime}')

def generate(split,n_each=16):
    out=[]
    for ri,r in enumerate(REGIMES):
        for i in range(n_each):out.append(make_task(split,r,SEED+(0 if split=='DEV' else 700000)+ri*10000+i))
    return out

# ---------- active query strategies ----------
def score_query(name,Aperms,Bperms,q):
    sid,x=q;ps=Aperms if sid=='A' else Bperms;parts=outcome_partition(ps,x);n=len(ps)
    result=[]
    for y,cell in parts.items():
        A2,B2,tys=joint_after(Aperms,Bperms,sid,x,y)
        result.append((len(cell)/n,len(tys),len(A2),len(B2),y))
    if name in ('EXACT_METAOP_MINIMAX','TOS_FULL_METAOPERATOR_GENESIS'):
        worst=max(r[1] for r in result);sq=sum(r[1]**2 for r in result)
        if name=='TOS_FULL_METAOPERATOR_GENESIS':
            # conformational lexicographic profile: semantic types, then total mapping fibers, then imbalance
            worstmap=max(r[2]+r[3] for r in result);return (worst,worstmap,sq,repr(q))
        return (worst,sq,repr(q))
    if name=='EXACT_EIG_QUERY':
        exp=sum(pr*math.log(max(1,nt)) for pr,nt,_,_,_ in result);return (exp,repr(q))
    if name=='MDL_ALGEBRA_INDUCTION':
        # prefer splits isolating smaller order/simple cycle types
        def dl(t):return len(t)+sum(t)
        exp=0
        for pr,nt,_,_,y in result:exp+=pr*nt
        return (exp,repr(q))
    if name=='TABLE_INTERPOLATOR':
        # no algebraic structural model: merely observe first available point
        return (repr(q),)
    if name=='OLD_VOCABULARY_DEG3':return (repr(q),)
    if name=='RANDOM_QUERY':return (h(q),)
    raise KeyError(name)

METHODS=('RANDOM_QUERY','OLD_VOCABULARY_DEG3','TABLE_INTERPOLATOR','EXACT_METAOP_MINIMAX','EXACT_EIG_QUERY','MDL_ALGEBRA_INDUCTION','TOS_FULL_METAOPERATOR_GENESIS')

def select_query(name,Aperms,Bperms,qpool):return min(qpool,key=lambda q:score_query(name,Aperms,Bperms,q)) if qpool else None

def transfer_certificate(ctype,C):
    # representation-independent orbit invariants on sealed relabelled surface C
    return cycle_type(C)==ctype and cycle_invariants(C)==cycle_invariants(perm_from_cycle_type_deterministic(ctype))

def perm_from_cycle_type_deterministic(ctype):
    pts=list(ELEMENTS);pi=list(ELEMENTS);i=0
    for L in ctype:
        cyc=pts[i:i+L];i+=L
        for a,b in zip(cyc,cyc[1:]+cyc[:1]):pi[a]=b
    return tuple(pi)

def evaluate(t,name,budget=MAX_QUERIES):
    if t.regime=='ANTI':return {'method':name,'state':'-1','form':False,'pre_types':0,'post_types':0,'queries':[],'certificate':False,'false_form':False}
    Ap=filter_perms(t.A.observed);Bp=filter_perms(t.B.observed);pre=joint_types(Ap,Bp);qpool=list(t.query_pool);used=[]
    if name in ('OLD_VOCABULARY_DEG3','TABLE_INTERPOLATOR'):
        # these controls do not gain the new semantic candidate universe; table control can only reach Form by full table completion, unavailable under budget.
        for _ in range(min(budget,len(qpool))):
            q=select_query(name,Ap,Bp,qpool);used.append(q);qpool.remove(q)
            sid,x=q;truth=t.A.truth if sid=='A' else t.B.truth;y=truth[x];Ap,Bp,_=joint_after(Ap,Bp,sid,x,y)
        return {'method':name,'state':'0','form':False,'pre_types':len(pre),'post_types':len(joint_types(Ap,Bp)),'queries':used,'certificate':False,'false_form':False}
    if t.regime=='UNDERIDENTIFIED':
        # respect jurisdiction: no active promotion in this negative lane
        return {'method':name,'state':'0','form':False,'pre_types':len(pre),'post_types':len(pre),'queries':[],'certificate':False,'false_form':False}
    for _ in range(budget):
        tys=joint_types(Ap,Bp)
        if len(tys)<=1 or not qpool:break
        q=select_query(name,Ap,Bp,qpool);used.append(q);qpool.remove(q);sid,x=q;truth=t.A.truth if sid=='A' else t.B.truth;y=truth[x];Ap,Bp,_=joint_after(Ap,Bp,sid,x,y)
    post=joint_types(Ap,Bp)
    if len(post)==1:
        predtype=post[0];cert=transfer_certificate(predtype,t.C_truth);st='1' if cert else '0'
    else:
        cert=False;st='+0' if query_can_reduce(Ap,Bp,qpool) else '0'
    return {'method':name,'state':st,'form':st=='1','pre_types':len(pre),'post_types':len(post),'queries':used,'certificate':cert,'false_form':st=='1' and post[0]!=t.truth_type}

# ---------- stats ----------
def bootstrap(rows,a,b,n=4000):
    aa={r['task_id']:int(r['form']) for r in rows if r['method']==a and r['regime']=='METAOP_AMBIG_REDUCIBLE' and r['split']=='PRIVATE'};bb={r['task_id']:int(r['form']) for r in rows if r['method']==b and r['regime']=='METAOP_AMBIG_REDUCIBLE' and r['split']=='PRIVATE'};ids=sorted(set(aa)&set(bb));d=np.array([aa[i]-bb[i] for i in ids],float);rng=np.random.default_rng(SEED);bs=[float(np.mean(rng.choice(d,size=len(d),replace=True))) for _ in range(n)];return {'delta':float(d.mean()),'ci':[float(np.quantile(bs,.025)),float(np.quantile(bs,.975))],'n':len(d)}

def main():
    out=Path(os.environ.get('G4_WORKDIR','/mnt/data/CFL_G4_METAOPERATOR_RUN'));out.mkdir(parents=True,exist_ok=True)
    dev=generate('DEV',12);priv=generate('PRIVATE',16);tasks=dev+priv
    rows=[]
    for t in tasks:
        for m in METHODS:
            r=evaluate(t,m);r.update({'task_id':t.task_id,'split':t.split,'regime':t.regime,'truth_type':t.truth_type});rows.append(r)
    write_jsonl(out/'results'/'PREDICTIONS.jsonl',rows)
    write_jsonl(out/'evidence'/'TASKS.jsonl',[{'task_id':t.task_id,'split':t.split,'regime':t.regime,'truth_type':t.truth_type,'A_obs':t.A.observed,'B_obs':t.B.observed,'query_pool':t.query_pool,'old_degree3_truth_A':t.A.truth in OLD_DEG3,'old_degree3_truth_B':t.B.truth in OLD_DEG3} for t in tasks])
    # summary private
    summary={}
    for m in METHODS:
        z=[r for r in rows if r['split']=='PRIVATE' and r['method']==m];amb=[r for r in z if r['regime']=='METAOP_AMBIG_REDUCIBLE']
        summary[m]={'ambiguous_form_rate':sum(r['form'] for r in amb)/len(amb),'all_state1':sum(r['form'] for r in z),'false_form_rate':sum(r['false_form'] for r in z)/len(z),'mean_post_types':float(np.mean([r['post_types'] for r in amb]))}
    write_json(out/'results'/'SUMMARY.json',summary)
    strongest=max((m for m in METHODS if m!='TOS_FULL_METAOPERATOR_GENESIS'),key=lambda m:summary[m]['ambiguous_form_rate'])
    boot=bootstrap(rows,'TOS_FULL_METAOPERATOR_GENESIS',strongest)
    tos=summary['TOS_FULL_METAOPERATOR_GENESIS'];base=summary[strongest]
    gain=tos['ambiguous_form_rate']-base['ambiguous_form_rate'];support=gain>=.02 and boot['ci'][0]>0 and tos['false_form_rate']<=.02
    outcome='G4_LOCAL_SUPPORT' if support else ('G4_POINT_ESTIMATE_INFERIOR' if gain<0 else 'G4_BASELINE_EQUIVALENT')
    privtasks=[t for t in priv if t.regime in ('METAOP_AMBIG_REDUCIBLE','METAOP_ALREADY_FORM')]
    outside=sum(t.A.truth not in OLD_DEG3 and t.B.truth not in OLD_DEG3 for t in privtasks)
    certrows=[r for r in rows if r['split']=='PRIVATE' and r['method']=='TOS_FULL_METAOPERATOR_GENESIS' and r['form']]
    adj={'program_id':PROGRAM_ID,'version':VERSION,'outcome':outcome,'atomic_metaoperator_genesis':'DEMONSTRATED_RELATIVE_TO_DEGREE3_LABEL_LANGUAGE','private_construct_n':len(privtasks),'outside_old_language_both_surfaces':outside,'dev_private_cycle_type_overlap':len(set(DEV_TYPES)&set(PRIVATE_TYPES)),'tos_ambiguous_form_rate':tos['ambiguous_form_rate'],'strongest_baseline':strongest,'baseline_ambiguous_form_rate':base['ambiguous_form_rate'],'paired_bootstrap':boot,'tos_certified_forms':sum(r['certificate'] for r in certrows),'tos_total_forms':len(certrows),'false_form_rate':tos['false_form_rate'],'benchmark_state':'+0_METAOPERATOR_GENESIS_BENCHMARK_PROTOFORM','o3_claim_state':'0_BASELINE_EQUIVALENT' if gain==0 else ('0_NO_SUPPORT_POINT_ESTIMATE_INFERIOR' if gain<0 else '+0_UNREPLICATED'),'authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED','scope_limit':'v0.1 assumes the missing atomic semantic is a bijective unary operator on seven states; fully open arity/type induction remains for the next gate.'}
    write_json(out/'results'/'FINAL_ADJUDICATION.json',adj)
    audit={'private_construct_n':len(privtasks),'truth_outside_old_degree3_label_language':outside,'all_truth_outside':outside==len(privtasks),'cross_surface_invariant_certificate':'cycle-type fixed-point counts of powers 1..7','dev_types':DEV_TYPES,'private_types':PRIVATE_TYPES,'dev_private_overlap':list(set(DEV_TYPES)&set(PRIVATE_TYPES)),'old_language_degree_bound':3,'all_permutations':len(ALL_PERMS),'old_degree3_permutations':len(OLD_DEG3)}
    write_json(out/'audit'/'EXACT_AUDIT.json',audit)
    write_json(out/'results'/'RUN_MANIFEST.json',{'program_id':PROGRAM_ID,'version':VERSION,'task_count':len(tasks),'prediction_rows':len(rows),'adjudication':adj})
    (out/'results'/'REPORT.md').write_text(f'''# CFL G4 Metaoperator & Observational Algebra Genesis\n\nOutcome: **{outcome}**\n\nPrivate ambiguous Form rate: TOS={tos['ambiguous_form_rate']:.4f}; strongest baseline `{strongest}`={base['ambiguous_form_rate']:.4f}; delta={boot['delta']:.4f}, 95% CI={boot['ci']}.\n\nThe hidden atomic operator is a surface-renamed permutation whose semantic class is its cycle/orbit law. Private cycle types are wholly OOD relative to development and truth mappings are filtered outside the old degree<=3 label language. State 1 requires a singleton semantic cycle-type class plus an exact orbit-invariant certificate on a sealed relabelled surface.\n''')
    print(json.dumps(adj,indent=2))

if __name__=='__main__':main()
