#!/usr/bin/env python3
from __future__ import annotations
import json, math, hashlib, random, itertools, time, os, csv
from dataclasses import dataclass, asdict, field
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np
from sklearn.neural_network import MLPClassifier

PROGRAM='CFL-UEP-G3.8-OPEN-BELIEF-STATE-AND-HYPOTHESIS-SPACE-GENESIS'
SEED=20261001
PRIVATE_SEED=20261002
DOMAINS=['graph','algebra','number','mechanics']
LANES=['HIDDEN_FINITE_SUPPORT','NOVEL_HYPOTHESIS_BIRTH','GRAMMAR_MISSPECIFICATION','GAUGE_NULL']
METHODS=['EXACT_ENUMERATED_FIBER_ORACLE_CEILING','ACTIVE_VERSION_SPACE_CONSTRUCTION','PARTICLE_SMC_BAYESIAN_ACTIVE_LEARNING','BAYESIAN_PROGRAM_SYNTHESIS','POMDP_LEARNED_BELIEF_STATE','MCTS_OVER_GENERATED_HYPOTHESES','AMORTIZED_NEURAL_BELIEF_BASELINE','TOS_NO_DIN_REENTRY','TOS_FULL_OPEN_BELIEF_DIN']
HORIZON=4
VERIFY_BUDGET_PER_STEP=36
INIT_SUPPORT=6
PARTICLES=24
BIRTHS_PER_STEP=12
AUTH_COVERAGE=0.65


def canon(o): return json.dumps(o,sort_keys=True,separators=(',',':'))
def sha(o): return hashlib.sha256(canon(o).encode()).hexdigest()
def entropy(vals):
    if not vals: return 0.0
    c=Counter(vals); n=len(vals)
    return -sum((v/n)*math.log2(v/n) for v in c.values())
def entropy_w(labels, weights):
    s=sum(weights)
    if s<=0:return 0.0
    acc=defaultdict(float)
    for l,w in zip(labels,weights):acc[l]+=w/s
    return -sum(p*math.log2(p) for p in acc.values() if p>0)

def brier(probs, truth):
    keys=set(probs)|{truth}; return sum((probs.get(k,0.0)-(1.0 if k==truth else 0.0))**2 for k in keys)

def bootstrap_mean(diff, B=4000, seed=77):
    a=np.array(diff,dtype=float)
    if len(a)==0:return [None,None]
    rng=np.random.default_rng(seed)
    means=np.mean(rng.choice(a,(B,len(a)),replace=True),axis=1)
    return [float(np.quantile(means,.025)),float(np.quantile(means,.975))]

# ----- Domain feature systems -------------------------------------------------
def query_universe(domain):
    if domain=='graph':
        return [tuple(x) for x in itertools.product([0,1], repeat=4)]
    if domain in ('algebra','mechanics'):
        return [(x,y) for x in range(-2,3) for y in range(-2,3)]
    if domain=='number':
        return [(n,) for n in range(18)]
    raise KeyError(domain)

def feat(domain,q,extra=False):
    if domain=='graph':
        a,b,c,d=q
        base=[1,a,b,c,d,a*b,b*c,c*d,a*c,b*d]
        if extra: base += [a*b*c, b*c*d]
        return np.array(base,dtype=int)
    if domain=='algebra':
        x,y=q
        base=[1,x,y,x*x,y*y,x*y,x*x*y,x*y*y]
        if extra: base += [x**3,y**3]
        return np.array(base,dtype=int)
    if domain=='number':
        n=q[0]
        base=[1,n%2,int(n%3==0),int(n%4 in (0,1)),int(n%5 in (0,1)),(n//2)%2,(n//4)%2,int(n in (2,3,5,7,11,13,17))]
        if extra: base += [int(n%7 in (0,1,2)),int(n in (1,4,9,16))]
        return np.array(base,dtype=int)
    if domain=='mechanics':
        x,v=q
        base=[1,x,v,x*x,v*v,x*v,abs(x),abs(v)]
        if extra: base += [x*x*v,x*v*v]
        return np.array(base,dtype=int)

@dataclass(frozen=True)
class Hyp:
    hid:str
    domain:str
    coeff:tuple[int,...]
    bias:int
    ontology:int
    complexity:int
    grammar:str='allowed'
    parent:str|None=None
    mutation:str|None=None

    def response(self,q):
        f=feat(self.domain,q,extra=(self.grammar=='external'))
        c=np.array(self.coeff,dtype=int)
        return int(int(np.dot(c,f))+self.bias>=0)


def hyp_id(domain,coeff,bias,ontology,grammar='allowed'):
    return hashlib.sha256(canon([domain,list(coeff),bias,ontology,grammar]).encode()).hexdigest()[:16]

def make_hyp(domain,coeff,bias,ontology=0,grammar='allowed',parent=None,mutation=None):
    comp=sum(abs(int(x)) for x in coeff)+abs(bias)
    return Hyp(hyp_id(domain,coeff,bias,ontology,grammar),domain,tuple(int(x) for x in coeff),int(bias),int(ontology),comp,grammar,parent,mutation)


def build_grammar(domain, external=False):
    k=len(feat(domain,query_universe(domain)[0],extra=external))
    hs={}
    # Sparse coefficient programs. Deterministic complete bounded grammar.
    vals=[-1,1] if not external else [-2,-1,1,2]
    max_terms=2 if not external else 3
    for r in range(1,max_terms+1):
        for idxs in itertools.combinations(range(k),r):
            for signs in itertools.product(vals,repeat=r):
                c=[0]*k
                for i,s in zip(idxs,signs): c[i]=s
                for b in (-1,0,1):
                    h=make_hyp(domain,c,b,0,'external' if external else 'allowed')
                    # dedupe by complete response signature + target potential but retain simplest
                    sig=tuple(h.response(q) for q in query_universe(domain))
                    key=(sig,h.ontology)
                    if key not in hs or h.complexity<hs[key].complexity: hs[key]=h
    # sort and cap to keep exact ceiling tractable, preserving response diversity
    arr=sorted(hs.values(),key=lambda h:(h.complexity,h.hid))
    return arr[:120 if not external else 180]

GRAMMARS={d:build_grammar(d,False) for d in DOMAINS}
EXTERNAL={d:build_grammar(d,True) for d in DOMAINS}

# Gauge twins share all physical responses but differ only in ontology tag.
def gauge_twin(h):
    return make_hyp(h.domain,h.coeff,h.bias,1-h.ontology,h.grammar,parent=h.hid,mutation='gauge_tag')

@dataclass
class Task:
    tid:str; domain:str; lane:str; truth:Hyp; allowed:list[Hyp]; initial_support:list[Hyp];
    obs_queries:list[tuple]; query_pool:list[tuple]; target_query:tuple; truth_claim:int; ontology_claim:int;
    external_truth:bool=False; gauge_twin_id:str|None=None


def choose_initial_obs(rng, truth, allowed, universe, n=2):
    # choose observations leaving ambiguity in full allowed grammar when possible
    candidates=list(universe)
    rng.shuffle(candidates)
    best=None
    for qs in itertools.combinations(candidates,min(n,len(candidates))):
        sig=[truth.response(q) for q in qs]
        comp=[h for h in allowed if [h.response(q) for q in qs]==sig]
        score=len(comp)
        if score>=4: return list(qs)
        if best is None or score>best[0]: best=(score,list(qs))
    return best[1]

def contradiction_witness(truth, allowed, universe, max_n=7):
    # Smallest observed subset that proves the allowed grammar inconsistent with the external truth.
    qs=list(universe)
    for n in range(2,min(max_n,len(qs))+1):
        for subset in itertools.combinations(qs,n):
            sig=[truth.response(q) for q in subset]
            if not any([h.response(q) for q in subset]==sig for h in allowed):
                return list(subset)
    return None

def one_mutation_parents(truth, allowed):
    out=[]
    tc=list(truth.coeff)
    for h in allowed:
        if h.hid==truth.hid or h.ontology!=truth.ontology: continue
        dc=sum(a!=b for a,b in zip(h.coeff,truth.coeff)) + (h.bias!=truth.bias)
        if dc==1: out.append(h)
    return sorted(out,key=lambda h:(h.complexity,h.hid))

def make_task(domain,lane,i,rng):
    allowed=list(GRAMMARS[domain])
    universe=query_universe(domain)
    external=False; twin=None; forced_parent=None; obs=None
    if lane=='GRAMMAR_MISSPECIFICATION':
        sig_allowed={tuple(h.response(q) for q in universe) for h in allowed}
        ext=[h for h in EXTERNAL[domain] if tuple(h.response(q) for q in universe) not in sig_allowed]
        rng.shuffle(ext)
        truth=None; obs=None
        for cand in ext:
            witness=contradiction_witness(cand,allowed,universe,7)
            if witness is not None:
                truth=cand; obs=witness; break
        if truth is None: raise RuntimeError(f'no misspec contradiction witness {domain}')
        external=True
    else:
        truth=rng.choice(allowed)
        if lane=='NOVEL_HYPOTHESIS_BIRTH':
            # Truth must be reachable by one authorized grammar mutation from a plausible seed.
            candidates=[h for h in allowed if one_mutation_parents(h,allowed)]
            truth=rng.choice(candidates)
            parents=one_mutation_parents(truth,allowed)
            rng.shuffle(parents)
            # choose observations on which a parent and truth agree, leaving both plausible.
            for par in parents:
                agree=[q for q in universe if par.response(q)==truth.response(q)]
                if len(agree)>=2:
                    obs=choose_initial_obs(rng,truth,[truth,par]+allowed,agree,2)
                    forced_parent=par; break
            if forced_parent is None: raise RuntimeError('no novelty parent')
        if lane=='GAUGE_NULL':
            truth=make_hyp(domain,truth.coeff,truth.bias,0,truth.grammar)
            twin=gauge_twin(truth)
            allowed=allowed+[truth,twin]
    if obs is None: obs=choose_initial_obs(rng,truth,allowed,universe,2)
    remaining=[q for q in universe if q not in obs]
    rng.shuffle(remaining)
    target=remaining[-1]; pool=remaining[:-1]
    truth_claim=truth.response(target)
    ontology_claim=truth.ontology
    obs_sig=[truth.response(q) for q in obs]
    consistent0=[h for h in allowed if [h.response(q) for q in obs]==obs_sig]
    consistent0=sorted(consistent0,key=lambda h:(h.complexity,h.hid))
    if lane=='HIDDEN_FINITE_SUPPORT':
        init=[truth] if truth in consistent0 else []
        init += [h for h in consistent0 if h.hid!=truth.hid][:INIT_SUPPORT-len(init)]
    elif lane=='NOVEL_HYPOTHESIS_BIRTH':
        init=[forced_parent]+[h for h in consistent0 if h.hid not in (truth.hid,forced_parent.hid)][:INIT_SUPPORT-1]
        if truth.hid in {h.hid for h in init}: raise AssertionError('novel truth leak')
    elif lane=='GRAMMAR_MISSPECIFICATION':
        # witness guarantees no allowed hypothesis survives the origin observations.
        init=[]
        assert not consistent0
    else:
        # Both gauge representatives are explicit: prediction can be known while ontology is not.
        init=[truth,twin]+[h for h in consistent0 if h.hid not in (truth.hid,twin.hid)][:max(0,INIT_SUPPORT-2)]
    tid=f'{domain[:2]}-{lane[:3]}-{i:03d}'
    return Task(tid,domain,lane,truth,allowed,init,obs,pool,target,truth_claim,ontology_claim,external,twin.hid if twin else None)

# ----- Belief method engine ---------------------------------------------------
@dataclass
class Receipt:
    step:int; action:str; hid:str; parent:str|None; reason:str

@dataclass
class Belief:
    live:dict[str,Hyp]
    weights:dict[str,float]
    dead:set[str]=field(default_factory=set)
    receipts:list[Receipt]=field(default_factory=list)
    verifier_calls:int=0
    unknown_mass:float=.25
    checked:set[str]=field(default_factory=set)

    def norm(self):
        s=sum(self.weights.get(h,0) for h in self.live)
        if s<=0 and self.live:
            u=1/len(self.live); self.weights={h:u for h in self.live}
        elif s>0: self.weights={h:self.weights.get(h,0)/s for h in self.live}
    def probs_claim(self, target, ontology=False):
        self.norm(); p=defaultdict(float)
        for hid,h in self.live.items():
            lab=h.ontology if ontology else h.response(target)
            p[int(lab)]+=self.weights.get(hid,0)
        return dict(p)


def update_unknown(belief,task):
    belief.unknown_mass=max(0.0,1.0-len(belief.checked)/max(1,len(task.allowed)))

def consistent(h, history): return all(h.response(q)==r for q,r in history)

def update_prune(belief,history,step):
    for hid,h in list(belief.live.items()):
        if not consistent(h,history):
            belief.dead.add(hid); belief.live.pop(hid,None); belief.weights.pop(hid,None)
            belief.receipts.append(Receipt(step,'DEATH',hid,h.parent,'inconsistent_with_observation'))
    belief.norm()

def birth(belief,h,step,reason):
    if h.hid in belief.dead: return False # no silent resurrection
    if h.hid not in belief.live:
        belief.live[h.hid]=h; belief.weights[h.hid]=1.0
        belief.receipts.append(Receipt(step,'BIRTH',h.hid,h.parent,reason)); return True
    return False

def enumerate_consistent(task,history,budget,exclude=None):
    out=[]; calls=0
    for h in sorted(task.allowed,key=lambda z:(z.complexity,z.hid)):
        if exclude and h.hid in exclude: continue
        calls+=1
        if consistent(h,history): out.append(h)
        if calls>=budget: break
    return out,calls

def near_mutations(task, seeds, maxn=80):
    # Generate one-coordinate coefficient/bias mutations from current seeds, but only if in allowed grammar.
    idx={ (h.coeff,h.bias,h.ontology,h.grammar):h for h in task.allowed }
    out=[]; seen=set()
    for s in seeds:
        c=list(s.coeff)
        for j in range(len(c)):
            for v in (-1,0,1):
                if v==c[j]:continue
                cc=c.copy();cc[j]=v
                key=(tuple(cc),s.bias,s.ontology,'allowed')
                if key in idx and idx[key].hid not in seen: out.append(idx[key]);seen.add(idx[key].hid)
        for bb in (-1,0,1):
            key=(s.coeff,bb,s.ontology,'allowed')
            if key in idx and idx[key].hid not in seen:out.append(idx[key]);seen.add(idx[key].hid)
    return sorted(out,key=lambda h:(h.complexity,h.hid))[:maxn]

def choose_query(belief, pool, target, ontology=False, rng=None, mode='claim'):
    if not pool:return None
    belief.norm(); hs=list(belief.live.values()); ws=[belief.weights[h.hid] for h in hs]
    if not hs:return pool[0]
    base_labels=[h.ontology if ontology else h.response(target) for h in hs]
    baseH=entropy_w(base_labels,ws)
    best=[]; bestv=-1e18
    for q in pool:
        if mode=='random':v=0
        else:
            # expected residual claim/model entropy after binary response
            groups={0:[],1:[]}
            for h,w in zip(hs,ws): groups[h.response(q)].append((h,w))
            val=0.0
            for r,items in groups.items():
                pr=sum(w for _,w in items)
                if pr<=0:continue
                if mode=='model':
                    labs=[h.hid for h,_ in items]
                else:
                    labs=[h.ontology if ontology else h.response(target) for h,_ in items]
                val += pr*entropy_w(labs,[w/pr for _,w in items])
            v=baseH-val if mode!='model' else entropy_w([h.hid for h in hs],ws)-val
        if v>bestv+1e-12:bestv=v;best=[q]
        elif abs(v-bestv)<=1e-12:best.append(q)
    if mode=='random': return (rng or random).choice(pool)
    return sorted(best)[0]

# ----- Actual amortized neural belief baseline (development-trained only) -----
NEURAL_MODELS={}
NEURAL_CLASSES={}

def encode_history(domain,history):
    uni=query_universe(domain); pos={q:i for i,q in enumerate(uni)}
    x=np.zeros(2*len(uni)+1,dtype=float)
    for q,r in history:
        if q in pos:
            i=pos[q]; x[2*i]=1.0; x[2*i+1]=1.0 if r else -1.0
    x[-1]=len(history)/max(1,len(uni))
    return x

def train_neural_models():
    global NEURAL_MODELS,NEURAL_CLASSES
    for di,domain in enumerate(DOMAINS):
        rng=random.Random(88421+di)
        grammar=GRAMMARS[domain]; uni=query_universe(domain)
        X=[]; y=[]
        # Development-only amortization corpus; never uses private tasks.
        for _ in range(1200):
            idx=rng.randrange(len(grammar)); h=grammar[idx]
            k=rng.randint(2,min(7,len(uni)))
            qs=rng.sample(uni,k)
            hist=[(q,h.response(q)) for q in qs]
            X.append(encode_history(domain,hist)); y.append(idx)
        clf=MLPClassifier(hidden_layer_sizes=(48,),activation='relu',solver='adam',alpha=1e-4,
                          batch_size=128,learning_rate_init=0.003,max_iter=120,shuffle=True,
                          random_state=4100+di,tol=1e-5,n_iter_no_change=12)
        clf.fit(np.asarray(X),np.asarray(y))
        NEURAL_MODELS[domain]=clf; NEURAL_CLASSES[domain]=list(grammar)

def neural_scores(task,history):
    clf=NEURAL_MODELS[task.domain]; grammar=NEURAL_CLASSES[task.domain]
    pr=clf.predict_proba(encode_history(task.domain,history).reshape(1,-1))[0]
    scores={h.hid:1e-12 for h in task.allowed}
    for cls,pv in zip(clf.classes_,pr):
        h=grammar[int(cls)]; scores[h.hid]=float(pv)+1e-12
    return scores

def init_belief(task,method):
    live={h.hid:h for h in task.initial_support}; w={h.hid:1.0 for h in task.initial_support}
    b=Belief(live,w,checked=set(live))
    for h in task.initial_support:b.receipts.append(Receipt(0,'INIT',h.hid,h.parent,'initial_support'))
    b.norm(); return b

def expand(task,belief,history,step,method,rng,frozen_births=None):
    budget=VERIFY_BUDGET_PER_STEP
    born=[]
    if method=='ACTIVE_VERSION_SPACE_CONSTRUCTION':
        ordered=[h for h in sorted(task.allowed,key=lambda z:(z.complexity,z.hid)) if h.hid not in belief.dead and h.hid not in belief.live][:budget]
        belief.checked.update(h.hid for h in ordered)
        c=[h for h in ordered if consistent(h,history)]; calls=len(ordered)
        belief.verifier_calls+=calls
        for h in c:
            if birth(belief,h,step,'systematic_version_space_enumeration'): born.append(h)
    elif method=='BAYESIAN_PROGRAM_SYNTHESIS':
        # complexity ordered enumeration with Bayesian Occam weights
        ordered=[h for h in sorted(task.allowed,key=lambda z:(z.complexity,z.hid)) if h.hid not in belief.dead and h.hid not in belief.live][:budget]
        belief.checked.update(h.hid for h in ordered)
        c=[h for h in ordered if consistent(h,history)]; calls=len(ordered); belief.verifier_calls+=calls
        for h in c[:BIRTHS_PER_STEP]:
            if birth(belief,h,step,'complexity_ordered_program_synthesis'):
                belief.weights[h.hid]=math.exp(-.35*h.complexity); born.append(h)
    elif method=='PARTICLE_SMC_BAYESIAN_ACTIVE_LEARNING':
        candidates=[h for h in task.allowed if h.hid not in belief.dead and h.hid not in belief.live]
        rng.shuffle(candidates)
        for h in candidates[:budget]:
            belief.checked.add(h.hid); belief.verifier_calls+=1
            if consistent(h,history) and len(belief.live)<PARTICLES:
                if birth(belief,h,step,'smc_mutation_rejuvenation'):born.append(h)
    elif method=='MCTS_OVER_GENERATED_HYPOTHESES':
        seeds=sorted(belief.live.values(),key=lambda h:(-belief.weights.get(h.hid,0),h.complexity))[:4]
        muts=near_mutations(task,seeds,80)
        # best-first using fit then complexity as MCTS surrogate tree score
        for h in muts[:budget]:
            belief.checked.add(h.hid); belief.verifier_calls+=1
            if consistent(h,history):
                if birth(belief,h,step,'mcts_mutation_expansion'):born.append(h)
                if len(born)>=BIRTHS_PER_STEP:break
    elif method=='AMORTIZED_NEURAL_BELIEF_BASELINE':
        scores=neural_scores(task,history)
        cands=sorted((h for h in task.allowed if h.hid not in belief.dead and h.hid not in belief.live),key=lambda h:(-scores[h.hid],h.complexity))
        for h in cands[:budget]:
            belief.checked.add(h.hid); belief.verifier_calls+=1
            if consistent(h,history):
                if birth(belief,h,step,'amortized_neural_proposal'):born.append(h)
                belief.weights[h.hid]=scores[h.hid]+1e-9
                if len(born)>=BIRTHS_PER_STEP:break
    elif method=='POMDP_LEARNED_BELIEF_STATE':
        # amortized likelihood proposal + model-IG policy; broad top-k support
        scores=neural_scores(task,history)
        cands=sorted((h for h in task.allowed if h.hid not in belief.dead and h.hid not in belief.live),key=lambda h:-scores[h.hid])
        for h in cands[:budget]:
            belief.checked.add(h.hid); belief.verifier_calls+=1
            if consistent(h,history):
                if birth(belief,h,step,'pomdp_belief_proposal'):born.append(h)
                belief.weights[h.hid]=scores[h.hid]+1e-9
                if len(belief.live)>=PARTICLES:break
    elif method in ('TOS_FULL_OPEN_BELIEF_DIN','TOS_NO_DIN_REENTRY'):
        if method=='TOS_NO_DIN_REENTRY' and step>1:
            return []
        seeds=sorted(belief.live.values(),key=lambda h:(-belief.weights.get(h.hid,0),h.complexity))[:6]
        muts=near_mutations(task,seeds,120)
        # residual-directed: candidates explaining all observations and maximizing response disagreement on remaining pool
        scored=[]
        for h in muts:
            belief.checked.add(h.hid); belief.verifier_calls+=1
            if consistent(h,history):
                diversity=sum(1 for q in task.query_pool if any(g.response(q)!=h.response(q) for g in belief.live.values()))
                scored.append((-diversity,h.complexity,h.hid,h))
            if belief.verifier_calls>=step*budget: break
        for *_,h in sorted(scored)[:BIRTHS_PER_STEP]:
            if birth(belief,h,step,'tos_residual_directed_birth'):born.append(h)
        # if support collapses, use a fail-closed systematic rescue within remaining budget
        if not belief.live:
            ordered=[h for h in sorted(task.allowed,key=lambda z:(z.complexity,z.hid)) if h.hid not in belief.dead][:budget]
            belief.checked.update(h.hid for h in ordered); c=[h for h in ordered if consistent(h,history)]; calls=len(ordered); belief.verifier_calls+=calls
            for h in c[:BIRTHS_PER_STEP]:
                if birth(belief,h,step,'tos_failclosed_rescue'):born.append(h)
    update_unknown(belief,task); belief.norm(); return born


def exact_full(task,history):
    return [h for h in task.allowed if consistent(h,history)]

def claim_status(task,belief):
    if task.lane=='GAUGE_NULL':
        p=belief.probs_claim(task.target_query,ontology=True)
    else:p=belief.probs_claim(task.target_query,ontology=False)
    if not p:return 'NO_SUPPORT',p
    unanimous=(len([x for x in p.values() if x>1e-12])==1)
    return ('CLOSED' if unanimous else 'OPEN'),p

def certify_claim(task,history,label,ontology=False):
    # Exact fail-closed counterexample search over the authorized grammar.
    calls=0; checked=[]
    support_exists=False
    for h in sorted(task.allowed,key=lambda z:(z.complexity,z.hid)):
        calls+=1; checked.append(h.hid)
        if not consistent(h,history): continue
        support_exists=True
        lab=h.ontology if ontology else h.response(task.target_query)
        if int(lab)!=int(label):
            return False,calls,checked
    return (support_exists),calls,checked

def run_method(task,method,seed):
    rng=random.Random(seed)
    history=[(q,task.truth.response(q)) for q in task.obs_queries]
    b=init_belief(task,method)
    update_prune(b,history,0)
    initial_ids=set(b.live)
    # Oracle gets full exact version space; excluded from evidence.
    if method=='EXACT_ENUMERATED_FIBER_ORACLE_CEILING':
        full=exact_full(task,history); b.live={h.hid:h for h in full}; b.weights={h.hid:1 for h in full}; b.checked={h.hid for h in task.allowed}; b.unknown_mass=0.0; b.norm();b.verifier_calls=len(task.allowed)
    else:
        expand(task,b,history,1,method,rng)
    pool=list(task.query_pool)
    used=[]; mismatch=False; certified=False; certified_label=None; cert_calls=0
    for step in range(1,HORIZON+1):
        update_prune(b,history,step)
        if method!='EXACT_ENUMERATED_FIBER_ORACLE_CEILING': expand(task,b,history,step,method,rng)
        # Misspecification: if no allowed support remains after observed contradictions, abstain/model mismatch.
        if task.lane=='GRAMMAR_MISSPECIFICATION' and not b.live:
            mismatch=True;break
        status,p=claim_status(task,b)
        if status=='CLOSED' and p:
            proposed=max(p,key=p.get)
            ok,calls,checked=certify_claim(task,history,proposed,ontology=(task.lane=='GAUGE_NULL'))
            b.verifier_calls+=calls; b.checked.update(checked); update_unknown(b,task); cert_calls+=calls
            if ok:
                certified=True; certified_label=int(proposed); break
        if not pool:break
        ontology=(task.lane=='GAUGE_NULL')
        mode='model' if method in ('POMDP_LEARNED_BELIEF_STATE','PARTICLE_SMC_BAYESIAN_ACTIVE_LEARNING') else 'claim'
        if method=='EXACT_ENUMERATED_FIBER_ORACLE_CEILING': mode='claim'
        if method=='RANDOM': mode='random'
        q=choose_query(b,pool,task.target_query,ontology=ontology,rng=rng,mode=mode)
        if q is None:break
        r=task.truth.response(q); history.append((q,r)); used.append(q); pool.remove(q)
    update_prune(b,history,HORIZON+1)
    if method!='EXACT_ENUMERATED_FIBER_ORACLE_CEILING' and not mismatch: expand(task,b,history,HORIZON+1,method,rng)
    status,p=claim_status(task,b)
    if (not certified) and status=='CLOSED' and p and task.lane!='GRAMMAR_MISSPECIFICATION':
        proposed=max(p,key=p.get)
        ok,calls,checked=certify_claim(task,history,proposed,ontology=(task.lane=='GAUGE_NULL'))
        b.verifier_calls+=calls; b.checked.update(checked); update_unknown(b,task); cert_calls+=calls
        if ok: certified=True; certified_label=int(proposed)
    truth_lab=task.ontology_claim if task.lane=='GAUGE_NULL' else task.truth_claim
    # truth recall: exact truth id, or gauge equivalence class for GAUGE lane.
    if task.lane=='GAUGE_NULL':
        truth_recall=any(all(h.response(q)==task.truth.response(q) for q in query_universe(task.domain)) for h in b.live.values())
    else: truth_recall=(task.truth.hid in b.live)
    # Scientific authority is judged against the COMPLETE grammar version-space compatible
    # with the observations this method actually acquired, not against the hidden truth alone.
    full_support=exact_full(task,history)
    if task.lane=='GRAMMAR_MISSPECIFICATION':
        authoritative='MODEL_MISMATCH' if len(full_support)==0 else 'OPEN'
        adjud='MODEL_MISMATCH' if mismatch or not b.live else ('CLOSED' if status=='CLOSED' else 'ABSTAIN')
        correct=(adjud==authoritative)
        false_promotion=(authoritative!='CLOSED' and adjud=='CLOSED')
        authorized_closure=False
    elif task.lane=='GAUGE_NULL':
        full_ont={h.ontology for h in full_support}
        authoritative='CLOSED' if len(full_ont)==1 else 'ABSTAIN'
        adjud='CLOSED' if certified else 'ABSTAIN'
        if adjud=='CLOSED':
            pred=certified_label
            correct=(authoritative=='CLOSED' and pred==task.ontology_claim)
        else: correct=(authoritative=='ABSTAIN')
        false_promotion=(authoritative=='ABSTAIN' and adjud=='CLOSED')
        authorized_closure=(authoritative=='CLOSED' and adjud=='CLOSED' and correct)
    else:
        full_labels={h.response(task.target_query) for h in full_support}
        authoritative='CLOSED' if len(full_labels)==1 else 'ABSTAIN'
        adjud='CLOSED' if certified else 'ABSTAIN'
        pred=certified_label if certified else None
        correct=(adjud==authoritative and (adjud!='CLOSED' or pred==task.truth_claim))
        false_promotion=(authoritative=='ABSTAIN' and adjud=='CLOSED')
        authorized_closure=(authoritative=='CLOSED' and adjud=='CLOSED' and pred==task.truth_claim)
    return {
        'task':task.tid,'domain':task.domain,'lane':task.lane,'method':method,'adjudication':adjud,'authoritative':authoritative,'correct':correct,
        'claim_closed':bool(certified),'certificate_calls':cert_calls,'authorized_closure':bool(authorized_closure),'false_promotion':bool(false_promotion),
        'truth_recall':bool(truth_recall),'truth_prob':float(p.get(truth_lab,0.0)),
        'brier':float(brier(p,truth_lab)) if p else 1.0,'queries':len(used),'verifier_calls':b.verifier_calls,
        'births':sum(r.action=='BIRTH' for r in b.receipts),'deaths':sum(r.action=='DEATH' for r in b.receipts),
        'live_support':len(b.live),'full_support_size':len(full_support),'unknown_mass':b.unknown_mass,'coverage':1.0-b.unknown_mass,'genealogy_hash':sha([asdict(r) for r in b.receipts]),
        'no_resurrection':all(r.hid not in {x.hid for x in b.receipts[:i] if x.action=='DEATH'} for i,r in enumerate(b.receipts) if r.action=='BIRTH')
    }


def make_suite(split='dev'):
    if split=='private':
        rng=random.Random(PRIVATE_SEED)
        counts={'HIDDEN_FINITE_SUPPORT':12,'NOVEL_HYPOTHESIS_BIRTH':12,'GRAMMAR_MISSPECIFICATION':8,'GAUGE_NULL':6}
    else:
        rng=random.Random(SEED)
        counts={'HIDDEN_FINITE_SUPPORT':8,'NOVEL_HYPOTHESIS_BIRTH':8,'GRAMMAR_MISSPECIFICATION':6,'GAUGE_NULL':4}
    tasks=[]
    for d in DOMAINS:
        for lane,n in counts.items():
            for i in range(n): tasks.append(make_task(d,lane,i,rng))
    return tasks

def aggregate(rows):
    out={}
    for m in METHODS:
        rr=[r for r in rows if r['method']==m]
        if not rr:continue
        normal=[r for r in rr if r['lane'] in ('HIDDEN_FINITE_SUPPORT','NOVEL_HYPOTHESIS_BIRTH')]
        novel=[r for r in rr if r['lane']=='NOVEL_HYPOTHESIS_BIRTH']
        gm=[r for r in rr if r['lane']=='GRAMMAR_MISSPECIFICATION']
        gauge=[r for r in rr if r['lane']=='GAUGE_NULL']
        eligible=[r for r in normal if r['authoritative']=='CLOSED']
        out[m]={
            'authority_adjudication_accuracy':float(np.mean([r['correct'] for r in rr])),
            'authorized_claim_closure_rate':float(np.mean([r['authorized_closure'] for r in eligible])) if eligible else 0.0,
            'false_promotion_rate':float(np.mean([r['false_promotion'] for r in rr])),
            'truth_recall_construct':float(np.mean([r['truth_recall'] for r in normal])),
            'novel_truth_recall':float(np.mean([r['truth_recall'] for r in novel])),
            'misspec_detection':float(np.mean([r['correct'] for r in gm])),
            'gauge_correct_abstention':float(np.mean([r['correct'] for r in gauge])),
            'mean_brier':float(np.mean([r['brier'] for r in rr])),
            'mean_queries':float(np.mean([r['queries'] for r in rr])),
            'mean_verifier_calls':float(np.mean([r['verifier_calls'] for r in rr])),
            'birth_efficiency':float(sum(r['truth_recall'] for r in novel)/(sum(r['verifier_calls'] for r in novel) or 1)),
            'no_resurrection_rate':float(np.mean([r['no_resurrection'] for r in rr])),
            'authoritatively_closable_normal_tasks':len(eligible)
        }
    return out

def adjudicate(summary,rows):
    deploy=[m for m in METHODS if m!='EXACT_ENUMERATED_FIBER_ORACLE_CEILING']
    # Safety/authority first, then authorized closure, then novel truth recall, then verifier cost.
    score=lambda m: (summary[m]['authority_adjudication_accuracy'], -summary[m]['false_promotion_rate'], summary[m]['authorized_claim_closure_rate'], summary[m]['novel_truth_recall'], -summary[m]['mean_verifier_calls'])
    best=max(deploy,key=score)
    tos='TOS_FULL_OPEN_BELIEF_DIN'
    idx={(r['task'],r['method']):r for r in rows}
    dif=[]; recall_dif=[]; closure_dif=[]
    for t in sorted({r['task'] for r in rows}):
        dif.append(float(idx[(t,tos)]['correct'])-float(idx[(t,best)]['correct']))
        if idx[(t,tos)]['lane']=='NOVEL_HYPOTHESIS_BIRTH':
            recall_dif.append(float(idx[(t,tos)]['truth_recall'])-float(idx[(t,best)]['truth_recall']))
        if idx[(t,tos)]['authoritative']=='CLOSED' and idx[(t,tos)]['lane'] in ('HIDDEN_FINITE_SUPPORT','NOVEL_HYPOTHESIS_BIRTH'):
            closure_dif.append(float(idx[(t,tos)]['authorized_closure'])-float(idx[(t,best)]['authorized_closure']))
    ci=bootstrap_mean(dif); gain=float(np.mean(dif))
    recall_gain=float(np.mean(recall_dif)) if recall_dif else 0.0; recall_ci=bootstrap_mean(recall_dif)
    closure_gain=float(np.mean(closure_dif)) if closure_dif else 0.0; closure_ci=bootstrap_mean(closure_dif)
    nodin='TOS_NO_DIN_REENTRY'
    recall_re=[]; authority_re=[]
    for t in sorted({r['task'] for r in rows}):
        if idx[(t,tos)]['lane']=='NOVEL_HYPOTHESIS_BIRTH':
            recall_re.append(float(idx[(t,tos)]['truth_recall'])-float(idx[(t,nodin)]['truth_recall']))
        authority_re.append(float(idx[(t,tos)]['correct'])-float(idx[(t,nodin)]['correct']))
    re_gain=float(np.mean(recall_re)); re_ci=bootstrap_mean(recall_re)
    re_auth=float(np.mean(authority_re)); re_auth_ci=bootstrap_mean(authority_re)
    support=(gain>=.02 and ci[0]>0 and recall_gain>=0 and summary[tos]['false_promotion_rate']<=.02)
    return {
        'program_id':PROGRAM,'material_gate':'PASS_LOCAL','best_deployable':best,
        'tos_minus_best_authority_accuracy':gain,'authority_bootstrap_95_ci':ci,
        'tos_minus_best_novel_truth_recall':recall_gain,'novel_recall_bootstrap_95_ci':recall_ci,
        'tos_minus_best_authorized_closure':closure_gain,'closure_bootstrap_95_ci':closure_ci,
        'tos_false_promotion_rate':summary[tos]['false_promotion_rate'],
        'din_reentry_novel_truth_recall_gain_vs_no_reentry':re_gain,'din_reentry_novel_recall_ci95':re_ci,
        'din_reentry_authority_accuracy_gain_vs_no_reentry':re_auth,'din_reentry_authority_ci95':re_auth_ci,
        'support':support,'outcome':'OPEN_BELIEF_LOCAL_SUPPORT' if support else ('BASELINE_EQUIVALENT' if abs(gain)<1e-12 else ('TOS_INFERIOR' if gain<0 else 'INSUFFICIENT_MARGIN')),
        'benchmark_state':'+0_OPEN_BELIEF_BENCHMARK_PROTOFORM','authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED'
    }

def main():
    wd=Path(os.environ.get('G38_WORKDIR','/mnt/data/g38_work')); (wd/'results').mkdir(parents=True,exist_ok=True);(wd/'evidence').mkdir(exist_ok=True)
    t0=time.time(); split=os.environ.get('G38_SPLIT','private'); train_neural_models(); tasks=make_suite(split)
    truth=[]
    for t in tasks:
        truth.append({'task':t.tid,'domain':t.domain,'lane':t.lane,'truth_hid':t.truth.hid,'truth_claim':t.truth_claim,'ontology_claim':t.ontology_claim,'initial_support':[h.hid for h in t.initial_support],'obs':[(q,t.truth.response(q)) for q in t.obs_queries],'target':t.target_query,'external_truth':t.external_truth})
    (wd/'evidence'/'TRUTH_MANIFEST.jsonl').write_text('\n'.join(canon(x) for x in truth)+'\n')
    rows=[]
    for ti,t in enumerate(tasks):
        for mi,m in enumerate(METHODS): rows.append(run_method(t,m,SEED+ti*101+mi*1009))
    (wd/'results'/'METHOD_RESULTS.jsonl').write_text('\n'.join(canon(x) for x in rows)+'\n')
    summary=aggregate(rows); adjud=adjudicate(summary,rows)
    out={'program_id':PROGRAM,'split':split,'tasks':len(tasks),'methods':summary,'elapsed_s':time.time()-t0,'truth_manifest_sha256':hashlib.sha256((wd/'evidence'/'TRUTH_MANIFEST.jsonl').read_bytes()).hexdigest()}
    (wd/'results'/'SUMMARY.json').write_text(json.dumps(out,indent=2,sort_keys=True))
    (wd/'results'/'FINAL_ADJUDICATION.json').write_text(json.dumps(adjud,indent=2,sort_keys=True))
    # audits
    audit={'split':split,'neural_training':'development-only synthetic grammar corpus',
      'novel_truth_initial_leaks':sum(t.truth.hid in {h.hid for h in t.initial_support} for t in tasks if t.lane=='NOVEL_HYPOTHESIS_BIRTH'),
      'misspec_truth_in_allowed_grammar':sum(t.truth.hid in {h.hid for h in t.allowed} for t in tasks if t.lane=='GRAMMAR_MISSPECIFICATION'),
      'all_no_resurrection':all(r['no_resurrection'] for r in rows),
      'domain_grammar_sizes':{d:len(GRAMMARS[d]) for d in DOMAINS}
    }
    (wd/'results'/'AUDIT.json').write_text(json.dumps(audit,indent=2,sort_keys=True))
    print(json.dumps(adjud,indent=2,sort_keys=True));print(json.dumps(summary,indent=2,sort_keys=True))
if __name__=='__main__':main()
