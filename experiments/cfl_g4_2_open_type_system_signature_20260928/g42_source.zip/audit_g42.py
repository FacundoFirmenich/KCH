#!/usr/bin/env python3
import os,runpy,json,hashlib,pathlib,collections
RUNNER=os.environ.get('G42_RUNNER','/mnt/data/run_g42.py')
WORK=pathlib.Path(os.environ.get('G42_WORKDIR','/mnt/data/CFL_G4_2_TYPE_SYSTEM_GENESIS_RUN'))
m=runpy.run_path(RUNNER,run_name='g42lib')
dev=m['generate_dev'](2);priv=m['generate_private'](4);tasks=dev+priv
rows=[json.loads(x) for x in open(WORK/'results/PREDICTIONS.jsonl')]
primary=[t for t in priv if t.lane=='PRIVATE_OOD_SIGNATURE' and t.regime=='TYPE_SYSTEM_AMBIG']
construct=[t for t in priv if t.lane=='PRIVATE_OOD_SIGNATURE' and t.regime not in ('ANTI',)]
anti=[t for t in priv if t.lane=='PRIVATE_OOD_SIGNATURE' and t.regime=='ANTI']
neg=[t for t in priv if t.lane=='PRIVATE_TYPE_NONIDENT']
# T0 behavioral equivalence: exact whole-query table match.
t0_tables={m['MODELS'][mid].table for mid in m['T0_MIDS']}
beh_out=[t for t in construct if m['MODELS'][t.truth_mid].table not in t0_tables]
# primary generator checks
primary_amb=all(len(m['typeset'](t.pre_fiber))>1 and len(m['sigset'](t.pre_fiber))>1 for t in primary)
# output methods
T='TOS_FULL_TYPE_SYSTEM_GENESIS';B='TYPE_GRAMMAR_MUTATION'
def rz(method,subset):return [r for r in rows if r['method']==method and r['task_id'] in {t.task_id for t in subset}]
tosprim=rz(T,primary);baseprim=rz(B,primary);tosconstruct=rz(T,construct);tosanti=rz(T,anti);tosneg=rz(T,neg)
sealed_forms=[r for r in tosconstruct if r['operator_form']]
summary={
 'status':'EXACT_AUDIT_PASS',
 'task_counts':{'dev':len(dev),'private':len(priv),'primary_ambiguous':len(primary),'construct_nonanti':len(construct),'anti':len(anti),'negative_type':len(neg)},
 'universe_models':len(m['MIDS']),
 'private_type_classes_not_in_T0':sum(t.truth_type not in m['T0_TYPES'] for t in construct),
 'private_construct_count':len(construct),
 'private_truth_tables_behaviorally_outside_T0':len(beh_out),
 'dev_private_new_type_overlap':len(set(m['DEV_NEW_TYPES'])&set(m['PRIVATE_NEW_TYPES'])),
 'primary_initial_type_and_operator_ambiguous':primary_amb,
 'tos_primary_type_forms':sum(r['type_state']=='1' for r in tosprim),
 'tos_primary_operator_forms':sum(r['operator_form'] for r in tosprim),
 'baseline_primary_operator_forms':sum(r['operator_form'] for r in baseprim),
 'primary_n':len(primary),
 'tos_sealed_certified_forms':sum(r['sealed_certificate'] for r in sealed_forms),
 'tos_total_forms_construct':len(sealed_forms),
 'negative_type_forms':sum(r['type_state']=='1' for r in tosneg),
 'negative_type_states':dict(collections.Counter(r['type_state'] for r in tosneg)),
 'anti_minus_one':sum(r['type_state']=='-1' and r['operator_state']=='-1' for r in tosanti),
 't0_control_forms':sum(r['operator_form'] for r in rows if r['method']=='T0_TYPED_ENUMERATION' and r['lane'].startswith('PRIVATE')),
 'relation_completion_forms':sum(r['operator_form'] for r in rows if r['method']=='UNIVERSAL_RELATION_COMPLETION' and r['lane'].startswith('PRIVATE')),
 'form_semantics':'CATEGORICAL_NONPROBABILISTIC_ONLY',
 'signature_ast':{
   'NEW_PARTIAL_MULTI':'Partial(Unary(X), Set(X))',
   'NEW_VARIADIC_X':'Variadic({1,2}; X -> X)',
   'NEW_PAIR_CI':'Unary(P(X), Pair(P(X),P(X)))',
   'NEW_QUOTIENT_MORPH':'Unary(X, QuotientBlock(X,~))'
 }
}
checks={
 'all_construct_types_outside_T0':summary['private_type_classes_not_in_T0']==len(construct),
 'all_construct_behaviors_outside_T0':summary['private_truth_tables_behaviorally_outside_T0']==len(construct),
 'dev_private_overlap_zero':summary['dev_private_new_type_overlap']==0,
 'primary_ambiguous':primary_amb,
 'tos_primary_16_16':summary['tos_primary_operator_forms']==len(primary)==16,
 'baseline_primary_16_16':summary['baseline_primary_operator_forms']==len(primary)==16,
 'all_tos_forms_sealed':summary['tos_sealed_certified_forms']==summary['tos_total_forms_construct'],
 'negative_zero_forms':summary['negative_type_forms']==0,
 'anti_all_minus_one':summary['anti_minus_one']==len(anti),
 't0_control_zero_forms':summary['t0_control_forms']==0,
 'relation_completion_zero_forms':summary['relation_completion_forms']==0
}
summary['checks']=checks;summary['all_pass']=all(checks.values())
out=WORK/'audit';out.mkdir(parents=True,exist_ok=True)
(out/'EXACT_AUDIT.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
if not summary['all_pass']:raise SystemExit(1)
