#!/usr/bin/env python3
from __future__ import annotations
import dataclasses, hashlib, itertools, json, math, os, random, statistics
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np

PROGRAM_ID='CFL-UEP-G4.2-OPEN-TYPE-SYSTEM-AND-SIGNATURE-GENESIS'
VERSION='0.1.0'
SEED=420928
NX,NY,NZ=3,2,3
QDOMAIN=tuple(range(32))
UNDEF=99
T0_TYPES=('T0_UNARY_ELEM','T0_BINARY_XX','T0_REL_BOOL','T0_CLOSURE_SET')
DEV_NEW_TYPES=('NEW_TOTAL_MULTI','NEW_MULTISORT_XY_Z')
PRIVATE_NEW_TYPES=('NEW_PARTIAL_MULTI','NEW_VARIADIC_X','NEW_PAIR_CI','NEW_QUOTIENT_MORPH')
NEG_TYPES=('NEG_SCHEMA_A','NEG_SCHEMA_B')
ALL_TYPES=T0_TYPES+DEV_NEW_TYPES+PRIVATE_NEW_TYPES+NEG_TYPES
PERMX=tuple(itertools.permutations(range(NX))); PERMY=tuple(itertools.permutations(range(NY))); PERMZ=tuple(itertools.permutations(range(NZ)))

# ---------- IO ----------
def canon(v):
    if dataclasses.is_dataclass(v):return canon(asdict(v))
    if isinstance(v,dict):return {str(k):canon(v[k]) for k in sorted(v,key=str)}
    if isinstance(v,(list,tuple)):return [canon(x) for x in v]
    if isinstance(v,set):return sorted(canon(x) for x in v)
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,float):return None if not math.isfinite(v) else float(v)
    return v
def cjson(v):return json.dumps(canon(v),sort_keys=True,separators=(',',':'))
def h(v):return hashlib.sha256(cjson(v).encode()).hexdigest()
def write_json(p,v):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(canon(v),indent=2,sort_keys=True)+'\n')
def write_jsonl(p,rows):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w') as f:
        for r in rows:f.write(cjson(r)+'\n')

@dataclass(frozen=True)
class Model:
    mid:str; typ:str; table:tuple[int,...]; sig:str; complexity:int; meta:tuple
@dataclass
class Task:
    task_id:str; lane:str; regime:str; truth_mid:str; truth_type:str; truth_sig:str
    demos:tuple[tuple[int,int],...]; query_pool:tuple[int,...]; pre_fiber:tuple[str,...]; sealed_tag:str

# ---------- query encodings ----------
def q_unary(x):return x
def q_bxx(x,y):return 3+3*x+y
def q_bxy(x,y):return 12+2*x+y
def q_subset(mask):return 18+mask
def q_neg(i):return 26+i

def mask_perm(mask,p):
    z=0
    for i in range(NX):
        if mask>>i&1:z|=1<<p[i]
    return z

def invperm(p):
    q=[0]*len(p)
    for i,j in enumerate(p):q[j]=i
    return tuple(q)

def canonical_table_unary_elem(tab):
    best=None
    for px in PERMX:
        ip=invperm(px);out=[UNDEF]*32
        for xo in range(NX):
            x=ip[xo];y=tab[q_unary(x)];out[q_unary(xo)]=px[y] if y!=UNDEF else UNDEF
        tt=tuple(out);best=tt if best is None or tt<best else best
    return best

def canonical_table_bxx(tab,boolout=False):
    best=None
    for px in PERMX:
        ip=invperm(px);out=[UNDEF]*32
        for xo in range(NX):
            for yo in range(NX):
                x,y=ip[xo],ip[yo];r=tab[q_bxx(x,y)];out[q_bxx(xo,yo)]=r if boolout else px[r]
        tt=tuple(out);best=tt if best is None or tt<best else best
    return best

def canonical_table_set_unary(tab):
    best=None
    for px in PERMX:
        ip=invperm(px);out=[UNDEF]*32
        for xo in range(NX):
            x=ip[xo];r=tab[q_unary(x)];out[q_unary(xo)]=UNDEF if r==UNDEF else mask_perm(r,px)
        tt=tuple(out);best=tt if best is None or tt<best else best
    return best

def canonical_table_bxy(tab):
    best=None
    for px in PERMX:
      ix=invperm(px)
      for py in PERMY:
       iy=invperm(py)
       for pz in PERMZ:
        out=[UNDEF]*32
        for xo in range(NX):
            for yo in range(NY):
                x,y=ix[xo],iy[yo];r=tab[q_bxy(x,y)];out[q_bxy(xo,yo)]=pz[r]
        tt=tuple(out);best=tt if best is None or tt<best else best
    return best

def canonical_table_variadic(tab):
    best=None
    for px in PERMX:
        ip=invperm(px);out=[UNDEF]*32
        for xo in range(NX):
            x=ip[xo];out[q_unary(xo)]=px[tab[q_unary(x)]]
        for xo in range(NX):
            for yo in range(NX):
                x,y=ip[xo],ip[yo];out[q_bxx(xo,yo)]=px[tab[q_bxx(x,y)]]
        tt=tuple(out);best=tt if best is None or tt<best else best
    return best

def canonical_table_subset(tab):
    # output is mask or opaque code; for T0 closure it is mask. Used only there.
    best=None
    for px in PERMX:
        ip=invperm(px);out=[UNDEF]*32
        for mo in range(8):
            m=mask_perm(mo,ip);r=tab[q_subset(m)];out[q_subset(mo)]=mask_perm(r,px)
        tt=tuple(out);best=tt if best is None or tt<best else best
    return best

def canonical_pair_semantic(pairtab):
    # pairtab contains (closure_mask, interior_mask) for subset queries; canonical semantic object.
    best=None
    for px in PERMX:
        ip=invperm(px);out=[]
        for mo in range(8):
            m=mask_perm(mo,ip);c,i=pairtab[m];out.append((mask_perm(c,px),mask_perm(i,px)))
        tt=tuple(out);best=tt if best is None or tt<best else best
    return best

def add_model(M,typ,table,complexity,meta=()):
    table=tuple(map(int,table))
    if typ=='T0_UNARY_ELEM':key=canonical_table_unary_elem(table)
    elif typ=='T0_BINARY_XX':key=canonical_table_bxx(table,False)
    elif typ=='T0_REL_BOOL':key=canonical_table_bxx(table,True)
    elif typ in ('NEW_TOTAL_MULTI','NEW_PARTIAL_MULTI','NEW_QUOTIENT_MORPH'):key=canonical_table_set_unary(table)
    elif typ=='NEW_MULTISORT_XY_Z':key=canonical_table_bxy(table)
    elif typ=='NEW_VARIADIC_X':key=canonical_table_variadic(table)
    elif typ=='T0_CLOSURE_SET':key=canonical_table_subset(table)
    elif typ=='NEW_PAIR_CI':key=canonical_pair_semantic(meta)
    else:key=table
    sig=h((typ,key))[:20];mid=h((typ,table,meta))[:20]
    M[mid]=Model(mid,typ,table,sig,complexity,tuple(meta) if isinstance(meta,(list,tuple)) else (meta,))

# ---------- structures ----------
def closures3():
    directed=[(i,j) for i in range(NX) for j in range(NX) if i!=j];seen={};out=[]
    for bits in range(1<<len(directed)):
        reach=[[False]*NX for _ in range(NX)]
        for i in range(NX):reach[i][i]=True
        for k,(i,j) in enumerate(directed):
            if bits>>k&1:reach[i][j]=True
        for k in range(NX):
            for i in range(NX):
                if reach[i][k]:
                    for j in range(NX):reach[i][j]=reach[i][j] or reach[k][j]
        tab=[]
        for mask in range(8):
            z=0
            for i in range(NX):
                if mask>>i&1:
                    for j in range(NX):
                        if reach[i][j]:z|=1<<j
            tab.append(z)
        tt=tuple(tab)
        if tt not in seen:seen[tt]=bits;out.append((tt,bits))
    return out

def partitions3():
    # canonical labels
    vals=[]
    for z in itertools.product(range(3),repeat=3):
        if z[0]!=0:continue
        mp={};n=0;c=[]
        for a in z:
            if a not in mp:mp[a]=n;n+=1
            c.append(mp[a])
        c=tuple(c)
        if c==z and c not in vals:vals.append(c)
    return vals

def block_masks(part):
    out=[]
    for i in range(NX):
        m=0
        for j in range(NX):
            if part[j]==part[i]:m|=1<<j
        out.append(m)
    return tuple(out)

def build_universe():
    M={}
    # T0 unary element maps
    for f in itertools.product(range(NX),repeat=NX):
        tab=[UNDEF]*32
        for x in range(NX):tab[q_unary(x)]=f[x]
        add_model(M,'T0_UNARY_ELEM',tab,1+len(set(f)))
    # T0 binary xx affine
    for a,b,c in itertools.product(range(3),repeat=3):
        tab=[UNDEF]*32
        for x in range(3):
            for y in range(3):tab[q_bxx(x,y)]=(a*x+b*y+c)%3
        add_model(M,'T0_BINARY_XX',tab,2+int(a!=0)+int(b!=0)+int(c!=0))
    # T0 boolean relations
    reltabs=[]
    for kind in range(6):
        tab=[UNDEF]*32
        for x in range(3):
            for y in range(3):
                r={0:int(x==y),1:int(x!=y),2:int((x+y)%3==0),3:int(x<y),4:int((x-y)%3==1),5:int(x==0 or y==0)}[kind]
                tab[q_bxx(x,y)]=r
        reltabs.append(tab);add_model(M,'T0_REL_BOOL',tab,1+kind)
    # closures
    cls=closures3()
    for ct,bits in cls:
        tab=[UNDEF]*32
        for mask,r in enumerate(ct):tab[q_subset(mask)]=r
        add_model(M,'T0_CLOSURE_SET',tab,1+bin(bits).count('1'))
    quotient_tables={block_masks(p) for p in partitions3()}
    # DEV total multivalued: directed neighborhoods; exclude quotient-like partition maps to prevent exact semantic aliasing in primary lanes.
    rr=random.Random(SEED)
    total_seen=set()
    for _ in range(180):
        outs=tuple(rr.randrange(1,8) for _ in range(3))
        if outs in quotient_tables or outs in total_seen:continue
        total_seen.add(outs);tab=[UNDEF]*32
        for x,r in enumerate(outs):tab[q_unary(x)]=r
        add_model(M,'NEW_TOTAL_MULTI',tab,1+sum(bin(r).count('1') for r in outs))
    # DEV multisorted XxY -> Z affine
    for a,b,c in itertools.product(range(3),repeat=3):
        tab=[UNDEF]*32
        for x in range(3):
            for y in range(2):tab[q_bxy(x,y)]=(a*x+b*y+c)%3
        add_model(M,'NEW_MULTISORT_XY_Z',tab,2+int(a!=0)+int(b!=0)+int(c!=0))
    # PRIVATE partial multi-valued X -> P(X)
    rr=random.Random(SEED+1);seen=set()
    while len(seen)<90:
        outs=[]
        for x in range(3):outs.append(UNDEF if rr.random()<.35 else rr.randrange(1,8))
        outs=tuple(outs)
        if outs.count(UNDEF)==0 or outs.count(UNDEF)==3 or outs in seen:continue
        seen.add(outs);tab=[UNDEF]*32
        for x,r in enumerate(outs):tab[q_unary(x)]=r
        add_model(M,'NEW_PARTIAL_MULTI',tab,2+sum(r!=UNDEF for r in outs))
    # PRIVATE variadic unary+binary linked family
    for a,b,c in itertools.product(range(3),repeat=3):
        if b==0:continue
        tab=[UNDEF]*32
        for x in range(3):tab[q_unary(x)]=(a*x+c)%3
        for x in range(3):
            for y in range(3):tab[q_bxx(x,y)]=(a*x+b*y+c)%3
        add_model(M,'NEW_VARIADIC_X',tab,3+int(a!=0)+int(c!=0))
    # PRIVATE pair closure/interior, observed through opaque 0..7 code but semantic signature keeps pair law.
    for ct,bits in cls:
        pair=[];tab=[UNDEF]*32
        for mask,c in enumerate(ct):
            comp=(~mask)&7; cint=ct[comp]; interior=(~cint)&7
            pair.append((c,interior));tab[q_subset(mask)]=(5*c+3*interior)%8
        add_model(M,'NEW_PAIR_CI',tab,3+bin(bits).count('1'),tuple(pair))
    # PRIVATE quotient-valued morphism: each x returns its equivalence block as opaque set code.
    for p in partitions3():
        outs=block_masks(p);tab=[UNDEF]*32
        for x,r in enumerate(outs):tab[q_unary(x)]=r
        add_model(M,'NEW_QUOTIENT_MORPH',tab,2+len(set(p)),p)
    # NEG exact observational aliases on reserved q26..31; type can never be identified.
    negtab=[UNDEF]*32
    for i in range(6):negtab[q_neg(i)]=(i*i+1)%8
    add_model(M,'NEG_SCHEMA_A',negtab,1,('A',));add_model(M,'NEG_SCHEMA_B',negtab,1,('B',))
    return M

MODELS=build_universe();MIDS=tuple(sorted(MODELS));BYTYPE={t:tuple(m for m in MIDS if MODELS[m].typ==t) for t in ALL_TYPES}
T0_MIDS=tuple(m for m in MIDS if MODELS[m].typ in T0_TYPES)

# ---------- fibers ----------
def filter_fiber(mids,demos):return tuple(m for m in mids if all(MODELS[m].table[q]==y for q,y in demos))
def typeset(f):return {MODELS[m].typ for m in f}
def sigset(f):return {MODELS[m].sig for m in f}
def response_partition(f,q):
    d={}
    for m in f:d.setdefault(MODELS[m].table[q],[]).append(m)
    return {y:tuple(v) for y,v in d.items()}
def claim_state(f,remaining,claim):
    if not f:return '-1'
    vals=typeset(f) if claim=='type' else sigset(f)
    if len(vals)==1:return '1'
    for q in remaining:
        for c in response_partition(f,q).values():
            vv=typeset(c) if claim=='type' else sigset(c)
            if len(vv)<len(vals):return '+0'
    return '0'

def model_complexity(m):return MODELS[m].complexity

# ---------- query strategies ----------
def q_random(task,fib,remaining):return remaining[int(task.task_id[:8],16)%len(remaining)] if remaining else None
def q_type_minimax(task,fib,remaining):
    best=None
    for q in remaining:
        parts=response_partition(fib,q);key=(max(len(typeset(c)) for c in parts.values()),max(len(sigset(c)) for c in parts.values()),sum(len(c)**2 for c in parts.values()),q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None
def q_op_minimax(task,fib,remaining):
    best=None
    for q in remaining:
        parts=response_partition(fib,q);key=(max(len(sigset(c)) for c in parts.values()),max(len(typeset(c)) for c in parts.values()),sum(len(c)**2 for c in parts.values()),q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None
def q_eig(task,fib,remaining):
    n=len(fib);best=None
    for q in remaining:
        parts=response_partition(fib,q);exp=sum((len(c)/n)*math.log(max(1,len(sigset(c)))) for c in parts.values());key=(exp,q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None
def q_mdl(task,fib,remaining):
    w={m:math.exp(-.8*model_complexity(m)) for m in fib};tot=sum(w.values());best=None
    for q in remaining:
        parts=response_partition(fib,q);exp=0.0
        for c in parts.values():
            wc=sum(w[m] for m in c);p=wc/tot;b={}
            for m in c:b[MODELS[m].sig]=b.get(MODELS[m].sig,0)+w[m]
            ent=-sum((z/wc)*math.log(z/wc) for z in b.values()) if wc else 0;exp+=p*ent
        key=(exp,q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None
def q_tos(task,fib,remaining):
    best=None
    for q in remaining:
        parts=response_partition(fib,q);profiles=sorted((len(typeset(c)),len(sigset(c)),len(c)) for c in parts.values())[::-1];key=(profiles[0],tuple(profiles),q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None
STRATS={'TYPE_GRAMMAR_MUTATION':q_type_minimax,'EXACT_OPERATOR_MINIMAX':q_op_minimax,'EXACT_EIG_QUERY':q_eig,'MDL_SIGNATURE_INDUCTION':q_mdl,'TOS_FULL_TYPE_SYSTEM_GENESIS':q_tos,'RANDOM_QUERY':q_random}

# ---------- tasks ----------
def truth_response(mid,q):return MODELS[mid].table[q]
def choose_demos(mid,rng,k):
    active=[q for q in QDOMAIN if truth_response(mid,q)!=UNDEF]
    inactive=[q for q in QDOMAIN if truth_response(mid,q)==UNDEF]
    qs=[]
    if active and k>0: qs.append(rng.choice(active))
    pool=[q for q in QDOMAIN if q not in qs]
    if k-len(qs)>0: qs += rng.sample(pool,k-len(qs))
    return tuple((q,truth_response(mid,q)) for q in qs)

def greedy_close(mid,demos,pool,strat,budget=3):
    fib=filter_fiber(MIDS,demos);rem=list(pool);used=[]
    fake=Task('0','','',mid,MODELS[mid].typ,MODELS[mid].sig,tuple(demos),tuple(pool),fib,'')
    for _ in range(budget):
        if len(sigset(fib))<=1:break
        q=strat(fake,fib,rem)
        if q is None:break
        y=truth_response(mid,q);used.append((q,y));fib=filter_fiber(fib,[(q,y)]);rem.remove(q)
    return fib,used

def make_task(mid,lane,regime,demos,pool,fib):
    return Task(h((mid,lane,regime,demos,pool))[:20],lane,regime,mid,MODELS[mid].typ,MODELS[mid].sig,tuple(demos),tuple(pool),tuple(fib),h((mid,'sealed'))[:12])

def search_task(truth_type,regime,seed,lane):
    rng=random.Random(seed);cands=list(BYTYPE[truth_type]);rng.shuffle(cands)
    for mid in cands:
        for _ in range(1000):
            if regime=='ANTI':
                # exact contradiction on same query
                q=rng.choice(QDOMAIN);y=truth_response(mid,q)
                if y==UNDEF:continue
                demos=((q,y),(q,(y+1)%8));fib=filter_fiber(MIDS,demos)
                if fib:continue
                pool=tuple(rng.sample([z for z in QDOMAIN if z!=q],6));return make_task(mid,lane,regime,demos,pool,tuple())
            if regime=='TYPE_SYSTEM_AMBIG':k=1
            elif regime=='TYPE_FORM_OPERATOR_AMBIG':k=2
            elif regime=='ALREADY_FORM':k=6
            elif regime=='TYPE_NONIDENT':k=2
            else:k=2
            demos=choose_demos(mid,rng,k);fib=filter_fiber(MIDS,demos)
            if mid not in fib:continue
            ts,ss=typeset(fib),sigset(fib);rem=[q for q in QDOMAIN if q not in {a for a,b in demos}]
            if regime=='TYPE_SYSTEM_AMBIG':
                if len(ts)<=1 or len(ss)<=1:continue
                pool=tuple(rng.sample(rem,min(10,len(rem))));ff,_=greedy_close(mid,demos,pool,q_type_minimax,3)
                if len(typeset(ff))!=1 or len(sigset(ff))!=1:continue
            elif regime=='TYPE_FORM_OPERATOR_AMBIG':
                if len(ts)!=1 or len(ss)<=1:continue
                pool=tuple(rng.sample(rem,min(10,len(rem))));ff,_=greedy_close(mid,demos,pool,q_op_minimax,3)
                if len(sigset(ff))!=1:continue
            elif regime=='ALREADY_FORM':
                if len(ss)!=1:continue
                pool=tuple(rng.sample(rem,min(6,len(rem))))
            elif regime=='TYPE_NONIDENT':
                if len(ts)<=1:continue
                good=[]
                for q in rem:
                    y=truth_response(mid,q);cell=filter_fiber(fib,[(q,y)])
                    if len(typeset(cell))>1:good.append(q)
                if len(good)<4:continue
                pool=tuple(good[:8]);ff=fib
                for q in pool:ff=filter_fiber(ff,[(q,truth_response(mid,q))])
                if len(typeset(ff))<=1:continue
            return make_task(mid,lane,regime,demos,pool,fib)
    raise RuntimeError(f'cannot generate {truth_type} {regime}')

def generate_dev(n_each=3):
    out=[]
    plan={
      'NEW_TOTAL_MULTI':('TYPE_SYSTEM_AMBIG','TYPE_FORM_OPERATOR_AMBIG','ALREADY_FORM'),
      'NEW_MULTISORT_XY_Z':('TYPE_FORM_OPERATOR_AMBIG','ALREADY_FORM')
    }
    for ti,t in enumerate(DEV_NEW_TYPES):
        for ri,r in enumerate(plan[t]):
            for i in range(n_each):out.append(search_task(t,r,SEED//2+ti*10000+ri*1000+i,'DEV_SIGNATURE_GENESIS'))
    return out

def generate_private(n_each=4):
    out=[]
    plan={
      'NEW_PARTIAL_MULTI':('TYPE_SYSTEM_AMBIG','TYPE_FORM_OPERATOR_AMBIG','ALREADY_FORM','ANTI'),
      'NEW_VARIADIC_X':('TYPE_SYSTEM_AMBIG','TYPE_FORM_OPERATOR_AMBIG','ALREADY_FORM','ANTI'),
      'NEW_PAIR_CI':('TYPE_SYSTEM_AMBIG','TYPE_FORM_OPERATOR_AMBIG','ALREADY_FORM','ANTI'),
      'NEW_QUOTIENT_MORPH':('TYPE_SYSTEM_AMBIG','ALREADY_FORM','ANTI')
    }
    for ti,t in enumerate(PRIVATE_NEW_TYPES):
        for ri,r in enumerate(plan[t]):
            for i in range(n_each):out.append(search_task(t,r,SEED+ti*100000+ri*10000+i,'PRIVATE_OOD_SIGNATURE'))
    # exact type-nonident aliases on reserved channel; permanently ambiguous by construction
    for ti,t in enumerate(NEG_TYPES):
        for i in range(n_each+1):out.append(search_task(t,'TYPE_NONIDENT',SEED+800000+ti*10000+i,'PRIVATE_TYPE_NONIDENT'))
    return out

# ---------- certificates / evaluation ----------
def _relabel_set_unary(tab,px):
    ip=invperm(px);out=[UNDEF]*32
    for xo in range(NX):
        x=ip[xo];r=tab[q_unary(x)];out[q_unary(xo)]=UNDEF if r==UNDEF else mask_perm(r,px)
    return tuple(out)

def _relabel_variadic(tab,px):
    ip=invperm(px);out=[UNDEF]*32
    for xo in range(NX):
        x=ip[xo];out[q_unary(xo)]=px[tab[q_unary(x)]]
    for xo in range(NX):
        for yo in range(NX):
            x,y=ip[xo],ip[yo];out[q_bxx(xo,yo)]=px[tab[q_bxx(x,y)]]
    return tuple(out)

def _relabel_bxy(tab,px,py,pz):
    ix,iy=invperm(px),invperm(py);out=[UNDEF]*32
    for xo in range(NX):
        for yo in range(NY):
            x,y=ix[xo],iy[yo];out[q_bxy(xo,yo)]=pz[tab[q_bxy(x,y)]]
    return tuple(out)

def _relabel_pair_meta(pairtab,px):
    ip=invperm(px);out=[]
    for mo in range(8):
        m=mask_perm(mo,ip);c,i=pairtab[m];out.append((mask_perm(c,px),mask_perm(i,px)))
    return tuple(out)

def sealed_signature_ok(task,mid):
    # Independent deterministic representation change, never used in fitting/query selection.
    m=MODELS[mid];z=int(task.sealed_tag[:8],16);px=PERMX[z%len(PERMX)];py=PERMY[(z//7)%len(PERMY)];pz=PERMZ[(z//13)%len(PERMZ)]
    if m.typ in ('NEW_TOTAL_MULTI','NEW_PARTIAL_MULTI','NEW_QUOTIENT_MORPH'):
        key=canonical_table_set_unary(_relabel_set_unary(m.table,px))
    elif m.typ=='NEW_VARIADIC_X':
        key=canonical_table_variadic(_relabel_variadic(m.table,px))
    elif m.typ=='NEW_MULTISORT_XY_Z':
        key=canonical_table_bxy(_relabel_bxy(m.table,px,py,pz))
    elif m.typ=='NEW_PAIR_CI':
        key=canonical_pair_semantic(_relabel_pair_meta(m.meta,px))
    elif m.typ=='T0_UNARY_ELEM': key=canonical_table_unary_elem(m.table)
    elif m.typ=='T0_BINARY_XX': key=canonical_table_bxx(m.table,False)
    elif m.typ=='T0_REL_BOOL': key=canonical_table_bxx(m.table,True)
    elif m.typ=='T0_CLOSURE_SET': key=canonical_table_subset(m.table)
    else: key=m.table
    return h((m.typ,key))[:20]==m.sig==task.truth_sig

def eval_method(task,name,strat,budget=3):
    fib=tuple(task.pre_fiber) if task.regime!='ANTI' else tuple();rem=list(task.query_pool);used=[]
    if not fib:
        return {'task_id':task.task_id,'lane':task.lane,'regime':task.regime,'truth_type':task.truth_type,'method':name,'type_state':'-1','operator_state':'-1','operator_form':False,'sealed_certificate':False,'queries':used,'post_models':0,'post_types':0,'post_sigs':0,'false_form_promotion':False}
    for _ in range(budget):
        if len(sigset(fib))<=1:break
        q=strat(task,fib,rem)
        if q is None:break
        y=truth_response(task.truth_mid,q);used.append((q,y));fib=filter_fiber(fib,[(q,y)]);rem.remove(q)
    ts=claim_state(fib,rem,'type');os_=claim_state(fib,rem,'operator');form=(os_=='1' and task.truth_sig in sigset(fib));cert=form and all(sealed_signature_ok(task,m) for m in fib)
    return {'task_id':task.task_id,'lane':task.lane,'regime':task.regime,'truth_type':task.truth_type,'method':name,'type_state':ts,'operator_state':os_,'operator_form':form and cert,'sealed_certificate':cert,'queries':used,'post_models':len(fib),'post_types':len(typeset(fib)),'post_sigs':len(sigset(fib)),'false_form_promotion':form and not cert}

def t0_only_control(task):
    fib=filter_fiber(T0_MIDS,task.demos)
    return {'task_id':task.task_id,'lane':task.lane,'regime':task.regime,'truth_type':task.truth_type,'method':'T0_TYPED_ENUMERATION','type_state':'0' if fib else '-1','operator_state':'0' if fib else '-1','operator_form':False,'sealed_certificate':False,'queries':[],'post_models':len(fib),'post_types':len(typeset(fib)) if fib else 0,'post_sigs':len(sigset(fib)) if fib else 0,'false_form_promotion':False}
def relation_completion_control(task):
    return {'task_id':task.task_id,'lane':task.lane,'regime':task.regime,'truth_type':task.truth_type,'method':'UNIVERSAL_RELATION_COMPLETION','type_state':'0' if task.pre_fiber else '-1','operator_state':'0' if task.pre_fiber else '-1','operator_form':False,'sealed_certificate':False,'queries':[],'post_models':len(task.pre_fiber),'post_types':len(typeset(task.pre_fiber)) if task.pre_fiber else 0,'post_sigs':len(sigset(task.pre_fiber)) if task.pre_fiber else 0,'false_form_promotion':False}

def summarize(rows):
    out={}
    for m in sorted({r['method'] for r in rows}):
        z=[r for r in rows if r['method']==m];amb=[r for r in z if r['regime']=='TYPE_SYSTEM_AMBIG'];nonanti=[r for r in z if r['regime']!='ANTI']
        out[m]={'type_form_rate_ambiguous':sum(r['type_state']=='1' for r in amb)/len(amb) if amb else None,'operator_form_rate_ambiguous':sum(r['operator_form'] for r in amb)/len(amb) if amb else None,'operator_form_rate_nonanti':sum(r['operator_form'] for r in nonanti)/len(nonanti) if nonanti else None,'false_form_rate':sum(r['false_form_promotion'] for r in z)/len(z)}
    return out

def paired_boot(rows,a,b,n=3000):
    aa={r['task_id']:int(r['operator_form']) for r in rows if r['method']==a and r['regime']=='TYPE_SYSTEM_AMBIG'};bb={r['task_id']:int(r['operator_form']) for r in rows if r['method']==b and r['regime']=='TYPE_SYSTEM_AMBIG'};ids=sorted(set(aa)&set(bb));d=np.array([aa[i]-bb[i] for i in ids],float);rng=np.random.default_rng(SEED);bs=[float(np.mean(rng.choice(d,size=len(d),replace=True))) for _ in range(n)];return {'delta':float(d.mean()),'ci':[float(np.quantile(bs,.025)),float(np.quantile(bs,.975))],'n':len(d),'a_only':sum(aa[i]>bb[i] for i in ids),'b_only':sum(bb[i]>aa[i] for i in ids)}

def main():
    out=Path(os.environ.get('G42_WORKDIR','/mnt/data/CFL_G4_2_TYPE_SYSTEM_GENESIS_RUN'));out.mkdir(parents=True,exist_ok=True)
    dev=generate_dev(2);private=generate_private(4);tasks=dev+private
    write_jsonl(out/'evidence/TASKS.jsonl',[{'task_id':t.task_id,'lane':t.lane,'regime':t.regime,'truth_type_hash':h(t.truth_type),'truth_sig_hash':h(t.truth_sig),'demos':t.demos,'query_pool':t.query_pool,'pre_models':len(t.pre_fiber),'pre_types':len(typeset(t.pre_fiber)) if t.pre_fiber else 0,'pre_sigs':len(sigset(t.pre_fiber)) if t.pre_fiber else 0} for t in tasks])
    rows=[]
    for t in tasks:
        for n,fn in STRATS.items():rows.append(eval_method(t,n,fn,3))
        rows.append(t0_only_control(t));rows.append(relation_completion_control(t))
    write_jsonl(out/'results/PREDICTIONS.jsonl',rows)
    priv=[r for r in rows if r['lane']=='PRIVATE_OOD_SIGNATURE'];summ=summarize(priv);write_json(out/'results/SUMMARY.json',summ)
    tos='TOS_FULL_TYPE_SYSTEM_GENESIS';valid=[m for m in STRATS if m not in ('RANDOM_QUERY',tos)];best=max(valid,key=lambda m:summ[m]['operator_form_rate_ambiguous']);boot=paired_boot(priv,tos,best)
    bytype={}
    for typ in PRIVATE_NEW_TYPES:
        z=[r for r in priv if r['method']==tos and r['truth_type']==typ and r['regime']=='TYPE_SYSTEM_AMBIG'];bytype[typ]={'form':sum(r['operator_form'] for r in z),'n':len(z),'rate':sum(r['operator_form'] for r in z)/len(z) if z else None}
    support=boot['delta']>=.02 and boot['ci'][0]>0 and sum(v['rate'] is not None and v['rate']>summ[best]['operator_form_rate_ambiguous'] for v in bytype.values())>=3 and summ[tos]['false_form_rate']<=.02
    outcome='G4_2_LOCAL_SUPPORT' if support else ('G4_2_NO_SUPPORT_POINT_ESTIMATE_INFERIOR' if boot['delta']<0 else 'G4_2_BASELINE_EQUIVALENT')
    neg=[r for r in rows if r['lane']=='PRIVATE_TYPE_NONIDENT' and r['method']==tos]
    adj={'program_id':PROGRAM_ID,'version':VERSION,'outcome':outcome,'finite_signature_grammar':{'models':len(MIDS),'by_type':{t:len(BYTYPE[t]) for t in ALL_TYPES},'t0_types':T0_TYPES,'dev_new_types':DEV_NEW_TYPES,'private_new_types':PRIVATE_NEW_TYPES},'hard_condition_private_types_not_in_t0':all(t not in T0_TYPES for t in PRIVATE_NEW_TYPES),'dev_private_new_type_overlap':len(set(DEV_NEW_TYPES)&set(PRIVATE_NEW_TYPES)),'strongest_baseline':best,'tos_operator_form_rate_ambiguous':summ[tos]['operator_form_rate_ambiguous'],'baseline_operator_form_rate_ambiguous':summ[best]['operator_form_rate_ambiguous'],'paired_bootstrap':boot,'tos_by_private_type':bytype,'negative_type_lane':{'n':len(neg),'forms':sum(r['type_state']=='1' for r in neg),'states':{s:sum(r['type_state']==s for r in neg) for s in ('1','+0','0','-1')}},'form_semantics':'CATEGORICAL_NONPROBABILISTIC_ONLY','benchmark_state':'+0_TYPE_SYSTEM_SIGNATURE_GENESIS_BENCHMARK_PROTOFORM','o3_claim_state':'0_BASELINE_EQUIVALENT' if outcome=='G4_2_BASELINE_EQUIVALENT' else '0_NO_SUPPORT','scope_limit':'new signatures are absent from T0 but generated inside a supplied bounded signature-constructor grammar; fully open invention outside this grammar is not tested.','authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED'}
    write_json(out/'results/FINAL_ADJUDICATION.json',adj);write_json(out/'results/RUN_MANIFEST.json',{'program_id':PROGRAM_ID,'version':VERSION,'tasks':len(tasks),'private_tasks':len(private),'models':len(MIDS),'task_hash':h([(t.task_id,t.truth_type,t.regime) for t in tasks]),'adjudication':adj})
    print(json.dumps(adj,indent=2))

if __name__=='__main__':main()
