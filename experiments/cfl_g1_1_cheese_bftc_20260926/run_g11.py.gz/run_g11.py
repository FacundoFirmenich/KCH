#!/usr/bin/env python3
"""CFL-UEP G1.1 object-level material gate on measured carved-cheese CT data.

The experiment is frozen before execution. It uses an independent measured
physical object, mandatory strong adaptive baselines, a sealed angular test set,
and a closure-specific O3 candidate based on bidirectional transport between
O1/O2 inverse fibers. The candidate may abstain. It is not canonical TOS\\.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import platform
import sys
import time
import urllib.request
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy
import scipy.io
import scipy.sparse as sp
import h5py
import scipy.sparse.linalg as spla

PROGRAM_ID = "CFL-UEP-G1.1-CHEESE-BFTC-20260926"
DATA_URL = "https://zenodo.org/records/1254210/files/DataFull_128x45.mat?download=1"
UPSTREAM_DOI = "10.5281/zenodo.1254210"
EXPECTED_MD5 = "ab615bdafdf93d0c14df89c0e0dd5257"
N = 128
N_ANGLES = 45
SEED = 11033
ALPHAS = [0.1, 1.0, 10.0]
BETAS = [1.0, 10.0]
MUS = [1.0, 10.0, 100.0]
LAMBDAS = [0.1, 1.0, 10.0]
CG_RTOL = 1e-4
CG_MAXITER = 220
CV_FOLDS = 3
TEST_ANGLES = np.arange(4, N_ANGLES, 5, dtype=int)  # nine angles; sealed until final evaluation
SUPPORT_MARGIN = 0.02
FALSE_CLOSURE_MARGIN = 0.05
MAX_COST_RATIO = 2.0
CROSS_GAIN_MIN = 0.05
PRESERVATION_DELTA_MAX = 0.015
HOLONOMY_MAX = 0.35
VALIDATION_ENVELOPE_MAX_RATIO = 1.05


@dataclass
class SolveResult:
    image: np.ndarray
    info: int
    seconds: float
    iterations: int


def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def hash_file(path: Path, algorithm: str = "sha256") -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def download_exact(path: Path) -> None:
    if path.exists() and hash_file(path, "md5") == EXPECTED_MD5:
        return
    tmp = path.with_suffix(path.suffix + ".part")
    tmp.unlink(missing_ok=True)
    req = urllib.request.Request(DATA_URL, headers={"User-Agent": "CFL-UEP-G1.1/1.0"})
    with urllib.request.urlopen(req, timeout=600) as response, tmp.open("wb") as out:
        while True:
            block = response.read(1 << 20)
            if not block:
                break
            out.write(block)
    if hash_file(tmp, "md5") != EXPECTED_MD5:
        raise RuntimeError("Downloaded cheese dataset does not match published Zenodo MD5")
    tmp.replace(path)




def load_fips_mat(path: Path) -> tuple[sp.csr_matrix, np.ndarray, list[str], str]:
    """Load both classic MAT and MATLAB v7.3/HDF5 sparse tomography files.

    Returns A in CSR, m in detector-by-angle orientation, visible keys, and
    a loader label. MATLAB v7.3 stores sparse CSC arrays as data/ir/jc and
    reverses dense array dimensions when read directly with h5py.
    """
    try:
        raw = scipy.io.loadmat(path)
        keys = sorted(k for k in raw if not k.startswith("__"))
        if "A" not in raw or "m" not in raw:
            raise RuntimeError(f"A/m missing; keys={keys}")
        A = raw["A"]
        if not sp.issparse(A):
            raise RuntimeError("A is not sparse")
        raw_m = np.asarray(raw["m"], dtype=np.float64)
        loader = "scipy.io.loadmat"
    except NotImplementedError:
        with h5py.File(path, "r") as f:
            keys = sorted(f.keys())
            if "A" not in f or "m" not in f:
                raise RuntimeError(f"A/m missing in HDF5 MAT; keys={keys}")
            g = f["A"]
            data = np.asarray(g["data"], dtype=np.float64).ravel()
            ir = np.asarray(g["ir"], dtype=np.int64).ravel()
            jc = np.asarray(g["jc"], dtype=np.int64).ravel()
            n_rows = int(g.attrs.get("MATLAB_sparse", int(ir.max()) + 1))
            n_cols = int(jc.size - 1)
            A = sp.csc_matrix((data, ir, jc), shape=(n_rows, n_cols))
            raw_m = np.asarray(f["m"], dtype=np.float64)
            loader = "h5py_matlab_v7.3"
    A = A.tocsr().astype(np.float64)
    if raw_m.ndim != 2:
        raise RuntimeError(f"Expected 2D sinogram, found {raw_m.shape}")
    # Identify the angle axis from the frozen angle count. Direct h5py access
    # exposes MATLAB dense dimensions in reversed order for this file.
    if raw_m.shape[1] == N_ANGLES:
        m = raw_m
    elif raw_m.shape[0] == N_ANGLES:
        m = raw_m.T
    else:
        raise RuntimeError(f"Cannot identify 45-angle axis in sinogram {raw_m.shape}")
    if A.shape[0] != m.shape[0] * m.shape[1]:
        raise RuntimeError(f"A rows {A.shape[0]} != sinogram size {m.size}")
    if A.shape[1] != N * N:
        raise RuntimeError(f"A columns {A.shape[1]} != expected image size {N*N}")
    return A, np.asarray(m, dtype=np.float64), keys, loader

def normalize_measurements(raw_m: np.ndarray, detector_count: int, angle_count: int) -> np.ndarray:
    m = np.asarray(raw_m, dtype=np.float64)
    if m.shape == (detector_count, angle_count):
        return m
    if m.shape == (angle_count, detector_count):
        return m.T
    if m.size == detector_count * angle_count:
        # FIPS matrices use MATLAB angle-major row blocks. This reshape preserves
        # that convention after conversion to detector x angle form.
        return m.reshape((angle_count, detector_count), order="C").T
    raise RuntimeError(f"Cannot normalize sinogram shape {m.shape}")


def rows_for_angles(angles: Iterable[int], detector_count: int) -> np.ndarray:
    return np.concatenate([
        np.arange(int(a) * detector_count, (int(a) + 1) * detector_count, dtype=np.int64)
        for a in angles
    ])


def subset(A: sp.csr_matrix, m: np.ndarray, angles: np.ndarray) -> tuple[sp.csr_matrix, np.ndarray]:
    rows = rows_for_angles(angles, m.shape[0])
    return A[rows, :].tocsr(), np.asarray(m[:, angles], dtype=np.float64).reshape(-1, order="F")


def nrmse(pred: np.ndarray, target: np.ndarray) -> float:
    return float(np.linalg.norm(np.asarray(pred) - np.asarray(target)) / max(np.linalg.norm(target), 1e-12))


def correlation(pred: np.ndarray, target: np.ndarray) -> float:
    x, y = np.asarray(pred).ravel(), np.asarray(target).ravel()
    if np.std(x) < 1e-15 or np.std(y) < 1e-15:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def robust_scale(x: np.ndarray) -> float:
    z = np.asarray(x, dtype=np.float64).ravel()
    z = z[z > 0]
    return float(np.median(z) + 1e-12) if z.size else 1.0


def build_laplacian(n: int, weights_h: np.ndarray | None = None, weights_v: np.ndarray | None = None) -> sp.csr_matrix:
    if weights_h is None:
        weights_h = np.ones((n, n - 1), dtype=np.float64)
    if weights_v is None:
        weights_v = np.ones((n - 1, n), dtype=np.float64)
    rows: list[int] = []
    cols: list[int] = []
    vals: list[float] = []
    diag = np.zeros(n * n, dtype=np.float64)

    def idx(r: int, c: int) -> int:
        return r + c * n

    for r in range(n):
        for c in range(n - 1):
            i, j = idx(r, c), idx(r, c + 1)
            w = float(weights_h[r, c])
            diag[i] += w
            diag[j] += w
            rows.extend((i, j)); cols.extend((j, i)); vals.extend((-w, -w))
    for r in range(n - 1):
        for c in range(n):
            i, j = idx(r, c), idx(r + 1, c)
            w = float(weights_v[r, c])
            diag[i] += w
            diag[j] += w
            rows.extend((i, j)); cols.extend((j, i)); vals.extend((-w, -w))
    rows.extend(range(n * n)); cols.extend(range(n * n)); vals.extend(diag.tolist())
    return sp.coo_matrix((vals, (rows, cols)), shape=(n * n, n * n)).tocsr()


def edge_laplacian(x: np.ndarray, n: int) -> sp.csr_matrix:
    img = x.reshape((n, n), order="F")
    h = np.abs(np.diff(img, axis=1))
    v = np.abs(np.diff(img, axis=0))
    wh = np.clip(np.exp(-h / robust_scale(h)), 0.03, 8.0)
    wv = np.clip(np.exp(-v / robust_scale(v)), 0.03, 8.0)
    return build_laplacian(n, wh, wv)


def phi12_laplacian(x1: np.ndarray, x2: np.ndarray, n: int) -> tuple[sp.csr_matrix, dict[str, float]]:
    i1, i2 = x1.reshape((n, n), order="F"), x2.reshape((n, n), order="F")
    h1, h2 = np.diff(i1, axis=1), np.diff(i2, axis=1)
    v1, v2 = np.diff(i1, axis=0), np.diff(i2, axis=0)
    eh, ev = 0.5 * (np.abs(h1) + np.abs(h2)), 0.5 * (np.abs(v1) + np.abs(v2))
    dh, dv = np.abs(h1 - h2), np.abs(v1 - v2)
    wh = np.clip(np.exp(-eh / robust_scale(eh)) * (1.0 + dh / robust_scale(dh)), 0.03, 8.0)
    wv = np.clip(np.exp(-ev / robust_scale(ev)) * (1.0 + dv / robust_scale(dv)), 0.03, 8.0)
    return build_laplacian(n, wh, wv), {
        "edge_h_median": float(np.median(eh)), "edge_v_median": float(np.median(ev)),
        "disagreement_h_median": float(np.median(dh)), "disagreement_v_median": float(np.median(dv)),
    }


def solve_quadratic(A: sp.csr_matrix, b: np.ndarray, alpha: float, beta: float = 0.0,
                    L: sp.csr_matrix | None = None, x0: np.ndarray | None = None) -> SolveResult:
    n = A.shape[1]
    rhs = np.asarray(A.T @ b).ravel()
    iterations = 0

    def mv(x: np.ndarray) -> np.ndarray:
        out = np.asarray(A.T @ (A @ x)).ravel() + alpha * x
        if beta > 0 and L is not None:
            out += beta * np.asarray(L @ x).ravel()
        return out

    def callback(_: np.ndarray) -> None:
        nonlocal iterations
        iterations += 1

    diag = np.asarray(A.power(2).sum(axis=0)).ravel() + alpha
    if beta > 0 and L is not None:
        diag += beta * L.diagonal()
    op = spla.LinearOperator((n, n), matvec=mv, dtype=np.float64)
    pre = spla.LinearOperator((n, n), matvec=lambda x: x / np.maximum(diag, 1e-12), dtype=np.float64)
    start = time.perf_counter()
    x, info = spla.cg(op, rhs, x0=x0, rtol=CG_RTOL, atol=0.0, maxiter=CG_MAXITER, M=pre, callback=callback)
    return SolveResult(np.asarray(x), int(info), float(time.perf_counter() - start), int(iterations))


def solve_transport(A_target: sp.csr_matrix, residual_target: np.ndarray,
                    A_preserve: sp.csr_matrix, mu: float, lam: float) -> SolveResult:
    n = A_target.shape[1]
    rhs = np.asarray(A_target.T @ residual_target).ravel()
    iterations = 0

    def mv(d: np.ndarray) -> np.ndarray:
        return (np.asarray(A_target.T @ (A_target @ d)).ravel()
                + mu * np.asarray(A_preserve.T @ (A_preserve @ d)).ravel()
                + lam * d)

    def callback(_: np.ndarray) -> None:
        nonlocal iterations
        iterations += 1

    diag = (np.asarray(A_target.power(2).sum(axis=0)).ravel()
            + mu * np.asarray(A_preserve.power(2).sum(axis=0)).ravel() + lam)
    op = spla.LinearOperator((n, n), matvec=mv, dtype=np.float64)
    pre = spla.LinearOperator((n, n), matvec=lambda x: x / np.maximum(diag, 1e-12), dtype=np.float64)
    start = time.perf_counter()
    d, info = spla.cg(op, rhs, rtol=CG_RTOL, atol=0.0, maxiter=CG_MAXITER, M=pre, callback=callback)
    return SolveResult(np.asarray(d), int(info), float(time.perf_counter() - start), int(iterations))


def cv_partitions() -> list[dict[str, np.ndarray]]:
    all_angles = np.arange(N_ANGLES, dtype=int)
    non_test = np.array([a for a in all_angles if a not in set(TEST_ANGLES.tolist())], dtype=int)
    folds = []
    for fold in range(CV_FOLDS):
        val = non_test[np.arange(non_test.size) % CV_FOLDS == fold]
        train = np.array([a for a in non_test if a not in set(val.tolist())], dtype=int)
        o1, o2 = train[::2], train[1::2]
        folds.append({"fold": np.array([fold]), "train": train, "val": val, "o1": o1, "o2": o2})
    return folds


def candidate_record(method: str, config: dict[str, float], fold: int, val: float, train: float,
                     seconds: float, iterations: int, info: int, extra: dict[str, Any] | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {
        "method": method, "config": config, "fold": fold,
        "val_nrmse": float(val), "train_nrmse": float(train),
        "solve_seconds": float(seconds), "cg_iterations": int(iterations), "cg_info": int(info),
    }
    if extra:
        out.update(extra)
    return out


def config_key(config: dict[str, float]) -> str:
    return json.dumps(config, sort_keys=True, separators=(",", ":"))


def select_config(records: list[dict[str, Any]], method: str, closure: bool = False) -> dict[str, Any]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in records:
        if r["method"] == method:
            groups[config_key(r["config"])].append(r)
    ranked = []
    for key, rs in groups.items():
        vals = np.array([r["val_nrmse"] for r in rs], dtype=float)
        score = float(np.median(vals) + 0.25 * (np.percentile(vals, 75) - np.percentile(vals, 25)))
        pass_count = sum(bool(r.get("closure_gate_pass", False)) for r in rs)
        if closure:
            score += 0.05 * (CV_FOLDS - pass_count)
            score += 0.05 * float(np.median([r.get("holonomy", 1.0) for r in rs]))
        ranked.append({
            "config": json.loads(key), "score": score, "median_val_nrmse": float(np.median(vals)),
            "iqr_val_nrmse": float(np.percentile(vals, 75) - np.percentile(vals, 25)),
            "closure_pass_count": pass_count, "records": rs,
        })
    if not ranked:
        raise RuntimeError(f"No records for method {method}")
    return min(ranked, key=lambda z: (z["score"], config_key(z["config"])))


def tune_partial_alpha(A1, b1, A2, b2, Aval, bval) -> tuple[float, np.ndarray, np.ndarray, list[dict[str, Any]]]:
    rows = []
    best = None
    best_pair = None
    for alpha in ALPHAS:
        s1 = solve_quadratic(A1, b1, alpha)
        s2 = solve_quadratic(A2, b2, alpha)
        v1, v2 = nrmse(Aval @ s1.image, bval), nrmse(Aval @ s2.image, bval)
        score = 0.5 * (v1 + v2)
        rec = {"partial_alpha": alpha, "O1_val_nrmse": v1, "O2_val_nrmse": v2,
               "mean_val_nrmse": score, "seconds": s1.seconds + s2.seconds,
               "iterations": s1.iterations + s2.iterations}
        rows.append(rec)
        if best is None or (score, alpha) < best:
            best = (score, alpha)
            best_pair = (s1.image, s2.image)
    assert best is not None and best_pair is not None
    return float(best[1]), best_pair[0], best_pair[1], rows


def bftc_candidate(A1, b1, A2, b2, Aval, bval, x1, x2, mu: float, lam: float) -> tuple[np.ndarray, dict[str, Any]]:
    r2 = b2 - A2 @ x1
    r1 = b1 - A1 @ x2
    d12 = solve_transport(A2, r2, A1, mu, lam)
    d21 = solve_transport(A1, r1, A2, mu, lam)
    x12, x21 = x1 + d12.image, x2 + d21.image
    fused = 0.5 * (x12 + x21)
    start12, after12 = nrmse(A2 @ x1, b2), nrmse(A2 @ x12, b2)
    start21, after21 = nrmse(A1 @ x2, b1), nrmse(A1 @ x21, b1)
    own1_before, own1_after = nrmse(A1 @ x1, b1), nrmse(A1 @ x12, b1)
    own2_before, own2_after = nrmse(A2 @ x2, b2), nrmse(A2 @ x21, b2)
    gain12 = (start12 - after12) / max(start12, 1e-12)
    gain21 = (start21 - after21) / max(start21, 1e-12)
    holonomy = float(np.linalg.norm(x12 - x21) / max(np.linalg.norm(fused), 1e-12))
    val12, val21 = nrmse(Aval @ x12, bval), nrmse(Aval @ x21, bval)
    val = nrmse(Aval @ fused, bval)
    metrics = {
        "cross_gain_12": float(gain12), "cross_gain_21": float(gain21),
        "preservation_delta_1": float(own1_after - own1_before),
        "preservation_delta_2": float(own2_after - own2_before),
        "holonomy": holonomy, "order12_val_nrmse": val12, "order21_val_nrmse": val21,
        "order_validation_gap": float(abs(val12 - val21)), "fused_val_nrmse": val,
        "transport_seconds": d12.seconds + d21.seconds,
        "transport_iterations": d12.iterations + d21.iterations,
        "transport_info": max(d12.info, d21.info),
        "x12": x12, "x21": x21,
    }
    return fused, metrics


def rowspace_novelty(A_ref: sp.csr_matrix, A_new: sp.csr_matrix, seed: int, probes: int = 6) -> dict[str, Any]:
    rng = np.random.default_rng(seed)
    scores = []
    iterations = []
    for _ in range(probes):
        coeff = rng.normal(size=A_new.shape[0])
        v = np.asarray(A_new.T @ coeff).ravel()
        denom = max(np.linalg.norm(v), 1e-12)
        sol = spla.lsqr(A_ref.T, v, atol=1e-5, btol=1e-5, iter_lim=150)
        residual = np.linalg.norm(A_ref.T @ sol[0] - v) / denom
        scores.append(float(residual)); iterations.append(int(sol[2]))
    return {
        "mean_relative_novelty": float(np.mean(scores)),
        "median_relative_novelty": float(np.median(scores)),
        "min_relative_novelty": float(np.min(scores)),
        "max_relative_novelty": float(np.max(scores)),
        "lsqr_iterations": iterations,
        "probes": probes,
    }


def method_cv(root_records: list[dict[str, Any]], A, m, n: int) -> tuple[dict[str, Any], dict[str, Any]]:
    fold_summaries = []
    partial_alphas = []
    L_fixed = build_laplacian(n)
    for fold_info in cv_partitions():
        fold = int(fold_info["fold"][0])
        A1, b1 = subset(A, m, fold_info["o1"])
        A2, b2 = subset(A, m, fold_info["o2"])
        Atr, btr = subset(A, m, fold_info["train"])
        Aval, bval = subset(A, m, fold_info["val"])
        partial_alpha, x1, x2, partial_trace = tune_partial_alpha(A1, b1, A2, b2, Aval, bval)
        partial_alphas.append(partial_alpha)
        for p in partial_trace:
            p.update({"method": "PARTIAL_ALPHA_SELECTION", "fold": fold})
            root_records.append(p)

        # Joint Tikhonov.
        prelim_by_alpha: dict[float, SolveResult] = {}
        for alpha in ALPHAS:
            s0 = solve_quadratic(Atr, btr, alpha)
            prelim_by_alpha[alpha] = s0
            root_records.append(candidate_record(
                "JOINT_TIKHONOV", {"alpha": alpha}, fold,
                nrmse(Aval @ s0.image, bval), nrmse(Atr @ s0.image, btr),
                s0.seconds, s0.iterations, s0.info,
            ))

        # Fixed-Laplacian baseline retained to bridge G1.
        for alpha in ALPHAS:
            for beta in BETAS:
                s = solve_quadratic(Atr, btr, alpha, beta, L_fixed)
                root_records.append(candidate_record(
                    "FIXED_LAPLACIAN", {"alpha": alpha, "beta": beta}, fold,
                    nrmse(Aval @ s.image, bval), nrmse(Atr @ s.image, btr),
                    s.seconds, s.iterations, s.info,
                ))

        # Mandatory strong self-adaptive and IRLS2 baselines.
        for alpha in ALPHAS:
            pre = prelim_by_alpha[alpha]
            L0 = edge_laplacian(pre.image, n)
            for beta in BETAS:
                s1 = solve_quadratic(Atr, btr, alpha, beta, L0, x0=pre.image)
                root_records.append(candidate_record(
                    "SELF_ADAPTIVE_ONCE", {"alpha": alpha, "beta": beta}, fold,
                    nrmse(Aval @ s1.image, bval), nrmse(Atr @ s1.image, btr),
                    pre.seconds + s1.seconds, pre.iterations + s1.iterations, max(pre.info, s1.info),
                ))
                L1 = edge_laplacian(s1.image, n)
                s2 = solve_quadratic(Atr, btr, alpha, beta, L1, x0=s1.image)
                root_records.append(candidate_record(
                    "IRLS2", {"alpha": alpha, "beta": beta}, fold,
                    nrmse(Aval @ s2.image, bval), nrmse(Atr @ s2.image, btr),
                    pre.seconds + s1.seconds + s2.seconds,
                    pre.iterations + s1.iterations + s2.iterations,
                    max(pre.info, s1.info, s2.info),
                ))

        # Failed G1 surrogate, replicated on the independent object.
        L_phi, phi_stats = phi12_laplacian(x1, x2, n)
        for alpha in ALPHAS:
            for beta in BETAS:
                s = solve_quadratic(Atr, btr, alpha, beta, L_phi)
                root_records.append(candidate_record(
                    "OLD_PHI12_LAPLACIAN", {"alpha": alpha, "beta": beta}, fold,
                    nrmse(Aval @ s.image, bval), nrmse(Atr @ s.image, btr),
                    s.seconds, s.iterations, s.info, {"partial_alpha": partial_alpha, **phi_stats},
                ))

        # New closure-specific O3 and no-preservation ablation.
        provisional_baseline = min(
            [r["val_nrmse"] for r in root_records if r.get("fold") == fold and r["method"] in {
                "JOINT_TIKHONOV", "FIXED_LAPLACIAN", "SELF_ADAPTIVE_ONCE", "IRLS2"
            }]
        )
        for mu in MUS:
            for lam in LAMBDAS:
                fused, met = bftc_candidate(A1, b1, A2, b2, Aval, bval, x1, x2, mu, lam)
                gate = bool(
                    met["cross_gain_12"] >= CROSS_GAIN_MIN
                    and met["cross_gain_21"] >= CROSS_GAIN_MIN
                    and met["preservation_delta_1"] <= PRESERVATION_DELTA_MAX
                    and met["preservation_delta_2"] <= PRESERVATION_DELTA_MAX
                    and met["holonomy"] <= HOLONOMY_MAX
                    and met["fused_val_nrmse"] <= provisional_baseline * VALIDATION_ENVELOPE_MAX_RATIO
                )
                extra = {k: v for k, v in met.items() if k not in {"x12", "x21"}}
                extra.update({"closure_gate_pass": gate, "partial_alpha": partial_alpha,
                              "validation_baseline_envelope": provisional_baseline})
                root_records.append(candidate_record(
                    "BFTC_PRESERVING", {"mu": mu, "lambda": lam}, fold,
                    met["fused_val_nrmse"], nrmse(Atr @ fused, btr),
                    met["transport_seconds"], met["transport_iterations"], met["transport_info"], extra,
                ))
        for lam in LAMBDAS:
            fused, met = bftc_candidate(A1, b1, A2, b2, Aval, bval, x1, x2, 0.0, lam)
            extra = {k: v for k, v in met.items() if k not in {"x12", "x21"}}
            root_records.append(candidate_record(
                "BFTC_NO_PRESERVATION", {"mu": 0.0, "lambda": lam}, fold,
                met["fused_val_nrmse"], nrmse(Atr @ fused, btr),
                met["transport_seconds"], met["transport_iterations"], met["transport_info"], extra,
            ))

        fold_summaries.append({
            "fold": fold,
            "angles": {k: [int(x) for x in v] for k, v in fold_info.items() if k != "fold"},
            "partial_alpha": partial_alpha,
        })

    selected = {}
    methods = ["JOINT_TIKHONOV", "FIXED_LAPLACIAN", "SELF_ADAPTIVE_ONCE", "IRLS2",
               "OLD_PHI12_LAPLACIAN", "BFTC_NO_PRESERVATION", "BFTC_PRESERVING"]
    for method in methods:
        selected[method] = select_config(root_records, method, closure=(method == "BFTC_PRESERVING"))
    # Mode with deterministic tie-break for the view-local regularization.
    counts = {a: partial_alphas.count(a) for a in ALPHAS}
    final_partial_alpha = min(ALPHAS, key=lambda a: (-counts[a], a))
    return {"selected": selected, "partial_alpha": final_partial_alpha}, {"folds": fold_summaries}


def fit_final_method(method: str, config: dict[str, float], A, m, non_test: np.ndarray,
                     o1_angles: np.ndarray, o2_angles: np.ndarray, partial_alpha: float, n: int) -> tuple[np.ndarray, dict[str, Any]]:
    Atr, btr = subset(A, m, non_test)
    A1, b1 = subset(A, m, o1_angles)
    A2, b2 = subset(A, m, o2_angles)
    L_fixed = build_laplacian(n)
    if method == "JOINT_TIKHONOV":
        s = solve_quadratic(Atr, btr, config["alpha"])
        return s.image, {"seconds": s.seconds, "iterations": s.iterations, "cg_info": s.info}
    if method == "FIXED_LAPLACIAN":
        s = solve_quadratic(Atr, btr, config["alpha"], config["beta"], L_fixed)
        return s.image, {"seconds": s.seconds, "iterations": s.iterations, "cg_info": s.info}
    if method in {"SELF_ADAPTIVE_ONCE", "IRLS2"}:
        pre = solve_quadratic(Atr, btr, config["alpha"])
        L0 = edge_laplacian(pre.image, n)
        s1 = solve_quadratic(Atr, btr, config["alpha"], config["beta"], L0, x0=pre.image)
        if method == "SELF_ADAPTIVE_ONCE":
            return s1.image, {"seconds": pre.seconds + s1.seconds,
                              "iterations": pre.iterations + s1.iterations,
                              "cg_info": max(pre.info, s1.info)}
        L1 = edge_laplacian(s1.image, n)
        s2 = solve_quadratic(Atr, btr, config["alpha"], config["beta"], L1, x0=s1.image)
        return s2.image, {"seconds": pre.seconds + s1.seconds + s2.seconds,
                          "iterations": pre.iterations + s1.iterations + s2.iterations,
                          "cg_info": max(pre.info, s1.info, s2.info)}
    p1 = solve_quadratic(A1, b1, partial_alpha)
    p2 = solve_quadratic(A2, b2, partial_alpha)
    x1, x2 = p1.image, p2.image
    partial_seconds = p1.seconds + p2.seconds
    partial_iterations = p1.iterations + p2.iterations
    partial_info = max(p1.info, p2.info)
    if method == "OLD_PHI12_LAPLACIAN":
        L, stats = phi12_laplacian(x1, x2, n)
        s = solve_quadratic(Atr, btr, config["alpha"], config["beta"], L)
        return s.image, {"seconds": partial_seconds + s.seconds,
                         "iterations": partial_iterations + s.iterations,
                         "cg_info": max(partial_info, s.info), **stats}
    if method in {"BFTC_PRESERVING", "BFTC_NO_PRESERVATION"}:
        # Final transport uses no validation data. Metrics here are computed only on the
        # non-test O1/O2 fibers; sealed test evaluation occurs afterwards.
        dummy_A, dummy_b = A1[:1], b1[:1]
        fused, met = bftc_candidate(A1, b1, A2, b2, dummy_A, dummy_b, x1, x2,
                                    config["mu"], config["lambda"])
        met = {k: v for k, v in met.items() if k not in {"x12", "x21", "fused_val_nrmse",
                                                          "order12_val_nrmse", "order21_val_nrmse",
                                                          "order_validation_gap"}}
        met["seconds"] = partial_seconds + met.pop("transport_seconds")
        met["iterations"] = partial_iterations + met.pop("transport_iterations")
        met["cg_info"] = max(partial_info, int(met.pop("transport_info")))
        return fused, met
    raise ValueError(method)


def save_montage(path: Path, images: dict[str, np.ndarray], n: int) -> None:
    names = list(images)
    cols = 3
    rows = math.ceil(len(names) / cols)
    finite = np.concatenate([x[np.isfinite(x)] for x in images.values()])
    vmin, vmax = np.percentile(finite, [1, 99])
    fig, axes = plt.subplots(rows, cols, figsize=(12, 4 * rows))
    axes_arr = np.atleast_1d(axes).ravel()
    for ax, name in zip(axes_arr, names):
        ax.imshow(images[name].reshape((n, n), order="F"), cmap="gray", vmin=vmin, vmax=vmax)
        ax.set_title(name); ax.axis("off")
    for ax in axes_arr[len(names):]:
        ax.axis("off")
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def main() -> int:
    np.random.seed(SEED)
    root = Path(os.environ.get("G11_WORKDIR", "g11_work")).resolve()
    data_dir, results_dir = root / "data", root / "results"
    data_dir.mkdir(parents=True, exist_ok=True); results_dir.mkdir(parents=True, exist_ok=True)
    data_path = data_dir / "DataFull_128x45.mat"
    download_exact(data_path)
    if hash_file(data_path, "md5") != EXPECTED_MD5:
        raise RuntimeError("Checksum gate failed")

    A, m, keys, loader = load_fips_mat(data_path)
    if not np.isfinite(A.data).all() or not np.isfinite(m).all():
        raise RuntimeError("Non-finite values found; imputation is forbidden")

    audit = {
        "program_id": PROGRAM_ID, "upstream_doi": UPSTREAM_DOI, "download_url": DATA_URL,
        "file": {"size_bytes": data_path.stat().st_size, "md5": hash_file(data_path, "md5"),
                 "sha256": hash_file(data_path, "sha256"), "published_md5_match": True},
        "payload": {"keys": keys, "A_shape": list(A.shape), "A_nnz": int(A.nnz),
                    "A_density": float(A.nnz / (A.shape[0] * A.shape[1])),
                    "m_shape_normalized": list(m.shape), "detector_count": int(m.shape[0]),
                    "angle_count": int(m.shape[1]), "loader": loader,
                    "missingness": 0, "imputation": False},
    }
    write_json(results_dir / "DATA_AUDIT.json", audit)

    records: list[dict[str, Any]] = []
    selection, cv_meta = method_cv(records, A, m, N)
    selected = selection["selected"]
    partial_alpha = selection["partial_alpha"]

    non_test = np.array([a for a in range(N_ANGLES) if a not in set(TEST_ANGLES.tolist())], dtype=int)
    final_o1, final_o2 = non_test[::2], non_test[1::2]
    Atest, btest = subset(A, m, TEST_ANGLES)
    Atr, btr = subset(A, m, non_test)

    final_images: dict[str, np.ndarray] = {}
    final_metrics: dict[str, dict[str, Any]] = {}
    # No test access occurred before this loop. All methods/configs are frozen above.
    for method, sel in selected.items():
        image, meta = fit_final_method(method, sel["config"], A, m, non_test, final_o1, final_o2,
                                       partial_alpha, N)
        final_images[method] = image
        final_metrics[method] = {
            "selected_config": sel["config"], "cv_score": sel["score"],
            "cv_median_val_nrmse": sel["median_val_nrmse"],
            "cv_iqr_val_nrmse": sel["iqr_val_nrmse"],
            "closure_pass_count": sel["closure_pass_count"],
            "train_nrmse": nrmse(Atr @ image, btr),
            "test_nrmse": nrmse(Atest @ image, btest),
            "test_correlation": correlation(Atest @ image, btest),
            **meta,
        }

    baseline_methods = ["JOINT_TIKHONOV", "FIXED_LAPLACIAN", "SELF_ADAPTIVE_ONCE", "IRLS2",
                        "BFTC_NO_PRESERVATION"]
    preselected_baseline = min(baseline_methods, key=lambda mth: selected[mth]["score"])
    test_envelope = min(baseline_methods, key=lambda mth: final_metrics[mth]["test_nrmse"])
    bftc = final_metrics["BFTC_PRESERVING"]
    bftc_cv_eligible = selected["BFTC_PRESERVING"]["closure_pass_count"] >= 2
    gain_vs_preselected = ((final_metrics[preselected_baseline]["test_nrmse"] - bftc["test_nrmse"])
                           / final_metrics[preselected_baseline]["test_nrmse"])
    gain_vs_envelope = ((final_metrics[test_envelope]["test_nrmse"] - bftc["test_nrmse"])
                        / final_metrics[test_envelope]["test_nrmse"])
    cost_ratio = bftc.get("seconds", 0.0) / max(final_metrics[test_envelope].get("seconds", 1e-12), 1e-12)
    false_closure = bool(bftc_cv_eligible and gain_vs_envelope <= -FALSE_CLOSURE_MARGIN)

    if not bftc_cv_eligible:
        h1 = "ABSTAIN_CLOSURE_GATE_NOT_MET"
        state = "0_NO_CLOSURE"
    elif gain_vs_envelope >= SUPPORT_MARGIN and cost_ratio <= MAX_COST_RATIO and not false_closure:
        h1 = "LOCAL_SUPPORT_IN_INDEPENDENT_OBJECT"
        state = "+0_PROTOFORM"
    elif gain_vs_envelope <= -SUPPORT_MARGIN:
        h1 = "REFUTED_IN_INDEPENDENT_OBJECT"
        state = "PSEUDOFORM_FALSE_OR_INFERIOR_CLOSURE" if false_closure else "0_NO_CLOSURE"
    else:
        h1 = "BASELINE_EQUIVALENT"
        state = "+0_PROTOFORM_UNRESOLVED" if bftc_cv_eligible else "0_NO_CLOSURE"

    A1_final, _ = subset(A, m, final_o1)
    A2_final, _ = subset(A, m, final_o2)
    fisher = {
        "object_dimension": int(A.shape[1]),
        "O1_rows": int(A1_final.shape[0]), "O2_rows": int(A2_final.shape[0]),
        "joint_rows": int(Atr.shape[0]),
        "nullity_lower_bound_O1": int(max(0, A.shape[1] - A1_final.shape[0])),
        "nullity_lower_bound_O2": int(max(0, A.shape[1] - A2_final.shape[0])),
        "nullity_lower_bound_joint": int(max(0, A.shape[1] - Atr.shape[0])),
        "O2_outside_O1_rowspace": rowspace_novelty(A1_final, A2_final, SEED + 1),
        "O1_outside_O2_rowspace": rowspace_novelty(A2_final, A1_final, SEED + 2),
        "interpretation": "Randomized full-space row-space novelty and structural nullity bounds; no saturated low-dimensional DCT basis.",
    }
    h4 = "LOCAL_COMPLEMENTARITY_SUPPORT" if (
        fisher["O2_outside_O1_rowspace"]["median_relative_novelty"] > 0.05
        and fisher["O1_outside_O2_rowspace"]["median_relative_novelty"] > 0.05
        and final_metrics[preselected_baseline]["test_nrmse"] < min(
            nrmse(Atest @ solve_quadratic(A1_final, subset(A, m, final_o1)[1], partial_alpha).image, btest),
            nrmse(Atest @ solve_quadratic(A2_final, subset(A, m, final_o2)[1], partial_alpha).image, btest),
        )
    ) else "NOT_IDENTIFIABLE_OR_NOT_SUPPORTED"

    old_gain_vs_self = ((final_metrics["SELF_ADAPTIVE_ONCE"]["test_nrmse"]
                         - final_metrics["OLD_PHI12_LAPLACIAN"]["test_nrmse"])
                        / final_metrics["SELF_ADAPTIVE_ONCE"]["test_nrmse"])
    old_surrogate_status = "REPLICATES_G1_FAILURE" if old_gain_vs_self <= -SUPPORT_MARGIN else (
        "OLD_SURROGATE_EQUIVALENT" if abs(old_gain_vs_self) < SUPPORT_MARGIN else "OLD_SURROGATE_RECOVERS_LOCALLY"
    )

    results = {
        "program_id": PROGRAM_ID,
        "status": "MATERIAL_G1_1_EXECUTED_SINGLE_SEALED_TEST",
        "dataset_sha256": audit["file"]["sha256"],
        "split": {"test_angles": TEST_ANGLES.tolist(), "non_test_angles": non_test.tolist(),
                  "final_O1_angles": final_o1.tolist(), "final_O2_angles": final_o2.tolist(),
                  "test_touched_only_after_configuration_freeze": True},
        "cv": {**cv_meta, "selected": {k: {kk: vv for kk, vv in v.items() if kk != "records"}
                                        for k, v in selected.items()},
               "selected_partial_alpha": partial_alpha},
        "final_metrics": final_metrics,
        "comparisons": {
            "preselected_strong_baseline": preselected_baseline,
            "strongest_preregistered_test_envelope": test_envelope,
            "BFTC_gain_vs_preselected": float(gain_vs_preselected),
            "BFTC_gain_vs_test_envelope": float(gain_vs_envelope),
            "BFTC_cost_ratio_vs_test_envelope": float(cost_ratio),
            "false_closure": false_closure,
            "old_G1_surrogate_gain_vs_self_adaptive": float(old_gain_vs_self),
            "old_G1_surrogate_status": old_surrogate_status,
        },
        "fisher_complementarity": fisher,
        "adjudication": {
            "H1_TRUE_CLOSURE_SPECIFIC_O3": h1,
            "state_quaternary": state,
            "H4_FISHER_COMPLEMENTARITY": h4,
            "H6_EUCLIDEANIZATION_CONTAMINATION": "NOT_TESTED_SINGLE_EUCLIDEANIZED_FORWARD_OPERATOR",
            "OLD_G1_SURROGATE": old_surrogate_status,
            "CANONICAL_TOS": "NOT_TESTED",
            "CFL_GENERAL": "NOT_ADJUDICATED",
            "authority": "NONE", "promotion": "BLOCKED", "canonicalization": "BLOCKED",
        },
        "limitations": [
            "The BFTC operator is a preregistered closure-specific protoform, not canonical TOS\\.",
            "One independent physical object and one sealed angular test do not establish a domain-general effect.",
            "The strongest test envelope is conservative and non-deployable because it is identified after test evaluation; the preselected baseline is the deployable comparison.",
            "Row-space novelty is randomized and diagnostic, not an exact Fisher spectrum.",
            "No intrinsic non-Euclidean geometry is identified from this Euclideanized system matrix.",
        ],
    }
    write_json(results_dir / "RESULTS.json", results)
    write_json(results_dir / "FISHER_COMPLEMENTARITY.json", fisher)

    with (results_dir / "CV_TUNING_TRACES.csv").open("w", newline="", encoding="utf-8") as fh:
        fields = sorted({key for r in records for key in r.keys() if key != "config"}) + ["config_json"]
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for r in records:
            row = {k: v for k, v in r.items() if k != "config"}
            row["config_json"] = json.dumps(r.get("config", {}), sort_keys=True)
            writer.writerow({k: row.get(k) for k in fields})

    montage_methods = ["JOINT_TIKHONOV", "SELF_ADAPTIVE_ONCE", "IRLS2",
                       "OLD_PHI12_LAPLACIAN", "BFTC_NO_PRESERVATION", "BFTC_PRESERVING"]
    save_montage(results_dir / "RECONSTRUCTION_MONTAGE.png",
                 {mth: final_images[mth] for mth in montage_methods}, N)

    manifest = {
        "program_id": PROGRAM_ID, "seed": SEED, "dataset_sha256": audit["file"]["sha256"],
        "protocol": {"alphas": ALPHAS, "betas": BETAS, "mus": MUS, "lambdas": LAMBDAS,
                     "cg_rtol": CG_RTOL, "cg_maxiter": CG_MAXITER,
                     "support_margin": SUPPORT_MARGIN, "false_closure_margin": FALSE_CLOSURE_MARGIN,
                     "cross_gain_min": CROSS_GAIN_MIN, "preservation_delta_max": PRESERVATION_DELTA_MAX,
                     "holonomy_max": HOLONOMY_MAX, "validation_envelope_max_ratio": VALIDATION_ENVELOPE_MAX_RATIO},
        "environment": {"python": sys.version, "platform": platform.platform(), "numpy": np.__version__,
                        "scipy": scipy.__version__, "matplotlib": matplotlib.__version__,
                        "github_sha": os.environ.get("GITHUB_SHA"), "github_run_id": os.environ.get("GITHUB_RUN_ID")},
    }
    manifest["manifest_sha256"] = hashlib.sha256(canonical_json(manifest)).hexdigest()
    write_json(results_dir / "RUN_MANIFEST.json", manifest)

    report = f"""# CFL–UEP G1.1 carved-cheese material gate

- Program: `{PROGRAM_ID}`
- Dataset SHA-256: `{audit['file']['sha256']}`
- Published Zenodo MD5 matched: `true`
- Sealed test angles: `{TEST_ANGLES.tolist()}`
- Preselected strong baseline: `{preselected_baseline}`
- Strongest preregistered test envelope: `{test_envelope}`
- BFTC gain vs preselected baseline: `{gain_vs_preselected:.6f}`
- BFTC gain vs test envelope: `{gain_vs_envelope:.6f}`
- H1: `{h1}`
- Quaternary state: `{state}`
- H4: `{h4}`
- Old G1 surrogate: `{old_surrogate_status}`

The BFTC arm is a closure-specific protoform. This execution cannot canonize TOS\\ or CFL.
"""
    (results_dir / "REPORT.md").write_text(report, encoding="utf-8")

    checksum_lines = []
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.name != "SHA256SUMS.txt":
            checksum_lines.append(f"{hash_file(p)}  {p.relative_to(root).as_posix()}")
    (results_dir / "SHA256SUMS.txt").write_text("\n".join(checksum_lines) + "\n", encoding="utf-8")

    print(json.dumps({
        "program_id": PROGRAM_ID, "dataset_sha256": audit["file"]["sha256"],
        "preselected_baseline": preselected_baseline, "test_envelope": test_envelope,
        "BFTC_gain_vs_envelope": gain_vs_envelope, "H1": h1, "state": state,
        "H4": h4, "old_surrogate": old_surrogate_status,
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
