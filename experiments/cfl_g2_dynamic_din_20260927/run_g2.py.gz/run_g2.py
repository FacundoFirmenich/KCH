#!/usr/bin/env python3
"""CFL-UEP G2: dynamic DIN material gate on measured cross-phantom CT data.

This is a preregistered discovery/confirmation bridge, not a canonical
implementation of CFL/TOS\\/DIN. It tests whether a closure computed from two
partial observations at frame k can re-enter a non-adjacent future observation
lens and improve physically withheld future projections beyond matched strong
baselines. The experiment is fail-closed and preserves adverse results.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import platform
import sys
import time
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import h5py
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy
import scipy.io
import scipy.sparse as sp
import scipy.sparse.linalg as spla

PROGRAM_ID = "CFL-UEP-G2-DYNAMIC-DIN-CROSS-PHANTOM-20260927"
DATA_URL = "https://zenodo.org/records/1446516/files/DataDynamic_128x15.mat?download=1"
UPSTREAM_DOI = "10.5281/zenodo.1446516"
EXPECTED_MD5 = "54c83983e1dfa73bb0da7734aea9f649"
N_FINE = 128
N = 64
T = 16
P = 15
D = 140
NPIX_FINE = N_FINE * N_FINE
NPIX = N * N
ROWS_PER_FRAME = D * P
TEST_POS = np.array([2, 7, 12], dtype=int)
OBS_POS = np.array([i for i in range(P) if i not in set(TEST_POS.tolist())], dtype=int)
O1_POS = OBS_POS[:6]
O2_POS = OBS_POS[6:]
TRAIN_FRAMES = list(range(0, 8))
TRANSITION_FRAMES = list(range(8, 12))
TEST_FRAMES = list(range(12, 16))
SEED = 270927

ALPHAS = [1e-3, 1e-2, 1e-1]
BETAS = [1e-2, 1e-1]
LAMBDAS = [1e-2, 1e-1, 1.0]
TRANSPORT_LAMBDA = 0.1
CG_RTOL = 1e-5
CG_MAXITER = 500
NORMAL_RESIDUAL_MAX = 2e-4
POWER_ITERS = 12
SUPPORT_MARGIN = 0.02
ABLATION_MARGIN = 0.01
MAX_COST_RATIO = 3.0
FISHER_DIM = 64

METHODS = [
    "FRAMEWISE_TIKHONOV",
    "FIXED_SPATIAL",
    "RECURRENT_NO_DIN",
    "STATE_SPACE_CV",
    "CROSS_ATTENTION_NO_DIN",
    "LOW_RANK_SPARSE_PREDICTOR",
    "SPATIOTEMPORAL_IRLS",
    "DIN_DIAGONAL_REENTRY",
    "DIN_ORDER_REVERSED",
    "DIN_LINEAGE_SHUFFLED",
]


@dataclass
class System:
    A: sp.csr_matrix
    b: np.ndarray
    sigma: float
    name: str

    @property
    def An(self) -> sp.csr_matrix:
        return self.A / self.sigma

    @property
    def bn(self) -> np.ndarray:
        return self.b / self.sigma

    def predict(self, x: np.ndarray) -> np.ndarray:
        return np.asarray(self.A @ x).ravel()


@dataclass
class SolveResult:
    x: np.ndarray
    info: int
    iterations: int
    seconds: float
    normal_residual: float
    valid: bool


@dataclass
class ClosureState:
    frame: int
    x1: np.ndarray
    x2: np.ndarray
    h12: np.ndarray
    h21: np.ndarray
    fused: np.ndarray
    reliability: np.ndarray
    holonomy: float
    valid: bool
    lineage_hash: str


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def hash_file(path: Path, algorithm: str = "sha256") -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def download_exact(path: Path) -> None:
    if path.exists() and hash_file(path, "md5") == EXPECTED_MD5:
        return
    tmp = path.with_suffix(path.suffix + ".part")
    tmp.unlink(missing_ok=True)
    req = urllib.request.Request(DATA_URL, headers={"User-Agent": "CFL-UEP-G2/1.0"})
    with urllib.request.urlopen(req, timeout=1200) as response, tmp.open("wb") as out:
        while True:
            block = response.read(1 << 20)
            if not block:
                break
            out.write(block)
    observed = hash_file(tmp, "md5")
    if observed != EXPECTED_MD5:
        raise RuntimeError(f"dataset checksum mismatch: {observed}")
    tmp.replace(path)


def _h5_sparse(group: h5py.Group) -> sp.csr_matrix:
    data = np.asarray(group["data"], dtype=np.float64).ravel()
    ir = np.asarray(group["ir"], dtype=np.int64).ravel()
    jc = np.asarray(group["jc"], dtype=np.int64).ravel()
    n_rows = int(group.attrs.get("MATLAB_sparse", int(ir.max()) + 1))
    n_cols = int(jc.size - 1)
    return sp.csc_matrix((data, ir, jc), shape=(n_rows, n_cols)).tocsr()


def load_mat(path: Path) -> tuple[sp.csr_matrix, np.ndarray, dict[str, Any], str]:
    metadata: dict[str, Any] = {}
    try:
        raw = scipy.io.loadmat(path)
        keys = sorted(k for k in raw if not k.startswith("__"))
        if "A" not in raw:
            raise RuntimeError(f"A missing; keys={keys}")
        A = raw["A"]
        if not sp.issparse(A):
            A = sp.csr_matrix(A)
        key = "m" if "m" in raw else "sinogram" if "sinogram" in raw else None
        if key is None:
            raise RuntimeError(f"m/sinogram missing; keys={keys}")
        m = np.asarray(raw[key], dtype=np.float64)
        loader = "scipy.io.loadmat"
    except (NotImplementedError, ValueError, OSError):
        with h5py.File(path, "r") as f:
            keys = sorted(f.keys())
            if "A" not in f:
                raise RuntimeError(f"A missing in HDF5; keys={keys}")
            Aobj = f["A"]
            if isinstance(Aobj, h5py.Group) and all(k in Aobj for k in ("data", "ir", "jc")):
                A = _h5_sparse(Aobj)
            else:
                A = sp.csr_matrix(np.asarray(Aobj, dtype=np.float64).T)
            key = "m" if "m" in f else "sinogram" if "sinogram" in f else None
            if key is None:
                raise RuntimeError(f"m/sinogram missing in HDF5; keys={keys}")
            m = np.asarray(f[key], dtype=np.float64)
            loader = "h5py_matlab_v7.3"
    A = A.tocsr().astype(np.float64)
    if m.shape == (T * P, D):
        m = m.T
    if m.shape != (D, T * P):
        raise RuntimeError(f"unexpected sinogram shape {m.shape}, expected {(D, T*P)}")
    if A.shape[0] != m.size:
        raise RuntimeError(f"A rows {A.shape[0]} != m.size {m.size}")
    if A.shape[1] != T * NPIX_FINE:
        raise RuntimeError(f"A columns {A.shape[1]} != {T*NPIX_FINE}")
    metadata.update({"keys": keys, "sinogram_key": key})
    return A, m, metadata, loader


def make_prolongation() -> sp.csr_matrix:
    rows: list[int] = []
    cols: list[int] = []
    vals: list[float] = []
    for jc in range(N):
        for ic in range(N):
            c = ic + jc * N
            for dj in (0, 1):
                for di in (0, 1):
                    i = 2 * ic + di
                    j = 2 * jc + dj
                    r = i + j * N_FINE
                    rows.append(r)
                    cols.append(c)
                    vals.append(1.0)
    return sp.coo_matrix((vals, (rows, cols)), shape=(NPIX_FINE, NPIX)).tocsr()


def split_frames(A: sp.csr_matrix, m: np.ndarray) -> tuple[list[sp.csr_matrix], list[np.ndarray], dict[str, Any]]:
    Pmat = make_prolongation()
    blocks: list[sp.csr_matrix] = []
    sinos: list[np.ndarray] = []
    off_frame_nnz = 0
    block_nnz = []
    for t in range(T):
        rs = slice(t * ROWS_PER_FRAME, (t + 1) * ROWS_PER_FRAME)
        cs = slice(t * NPIX_FINE, (t + 1) * NPIX_FINE)
        rowblock = A[rs, :].tocsr()
        left = rowblock[:, : t * NPIX_FINE].nnz if t > 0 else 0
        right = rowblock[:, (t + 1) * NPIX_FINE :].nnz if t < T - 1 else 0
        off_frame_nnz += left + right
        At = (rowblock[:, cs] @ Pmat).tocsr()
        blocks.append(At)
        sinos.append(np.asarray(m[:, t * P:(t + 1) * P], dtype=np.float64))
        block_nnz.append(int(At.nnz))
    return blocks, sinos, {
        "off_frame_nnz": int(off_frame_nnz),
        "coarse_block_shape": list(blocks[0].shape),
        "coarse_block_nnz_min": int(min(block_nnz)),
        "coarse_block_nnz_max": int(max(block_nnz)),
        "coarse_resolution": [N, N],
        "prolongation_nnz": int(Pmat.nnz),
    }


def rows_for_positions(pos: Sequence[int]) -> np.ndarray:
    return np.concatenate([np.arange(int(j) * D, (int(j) + 1) * D, dtype=np.int64) for j in pos])


def subset_frame(A: sp.csr_matrix, sino: np.ndarray, pos: Sequence[int]) -> tuple[sp.csr_matrix, np.ndarray]:
    p = np.asarray(pos, dtype=int)
    rows = rows_for_positions(p)
    return A[rows, :].tocsr(), np.asarray(sino[:, p], dtype=np.float64).reshape(-1, order="F")


def nrmse(pred: np.ndarray, target: np.ndarray) -> float:
    p = np.asarray(pred).ravel()
    y = np.asarray(target).ravel()
    return float(np.linalg.norm(p - y) / max(np.linalg.norm(y), 1e-15))


def corr(pred: np.ndarray, target: np.ndarray) -> float:
    p = np.asarray(pred).ravel()
    y = np.asarray(target).ravel()
    if np.std(p) < 1e-15 or np.std(y) < 1e-15:
        return float("nan")
    return float(np.corrcoef(p, y)[0, 1])


def power_norm(A: sp.csr_matrix, seed: int) -> float:
    rng = np.random.default_rng(seed)
    x = rng.normal(size=A.shape[1])
    x /= max(np.linalg.norm(x), 1e-15)
    sigma = 1.0
    for _ in range(POWER_ITERS):
        y = np.asarray(A @ x).ravel()
        sigma = float(np.linalg.norm(y))
        z = np.asarray(A.T @ y).ravel()
        nz = np.linalg.norm(z)
        if nz <= 1e-15:
            return max(sigma, 1.0)
        x = z / nz
    return max(sigma, 1e-12)


def build_laplacian(weights_h: np.ndarray | None = None, weights_v: np.ndarray | None = None) -> sp.csr_matrix:
    if weights_h is None:
        weights_h = np.ones((N, N - 1), dtype=np.float64)
    if weights_v is None:
        weights_v = np.ones((N - 1, N), dtype=np.float64)
    rows: list[int] = []
    cols: list[int] = []
    vals: list[float] = []
    diag = np.zeros(NPIX, dtype=np.float64)
    for j in range(N):
        for i in range(N):
            u = i + j * N
            if j + 1 < N:
                v = i + (j + 1) * N
                w = float(weights_h[i, j])
                rows += [u, v]
                cols += [v, u]
                vals += [-w, -w]
                diag[u] += w
                diag[v] += w
            if i + 1 < N:
                v = (i + 1) + j * N
                w = float(weights_v[i, j])
                rows += [u, v]
                cols += [v, u]
                vals += [-w, -w]
                diag[u] += w
                diag[v] += w
    rows.extend(range(NPIX)); cols.extend(range(NPIX)); vals.extend(diag.tolist())
    L = sp.coo_matrix((vals, (rows, cols)), shape=(NPIX, NPIX)).tocsr()
    scale = max(float(diag.max()), 1.0) * 2.0
    return L / scale


L_FIXED = build_laplacian()


def adaptive_laplacian(x: np.ndarray) -> sp.csr_matrix:
    img = np.asarray(x).reshape((N, N), order="F")
    gh = np.abs(np.diff(img, axis=1))
    gv = np.abs(np.diff(img, axis=0))
    sh = float(np.median(gh[gh > 0])) if np.any(gh > 0) else 1.0
    sv = float(np.median(gv[gv > 0])) if np.any(gv > 0) else 1.0
    wh = np.clip(np.exp(-gh / max(sh, 1e-12)), 0.03, 1.0)
    wv = np.clip(np.exp(-gv / max(sv, 1e-12)), 0.03, 1.0)
    return build_laplacian(wh, wv)


def make_system(A: sp.csr_matrix, b: np.ndarray, name: str, seed: int) -> System:
    return System(A=A, b=np.asarray(b, dtype=np.float64), sigma=power_norm(A, seed), name=name)


def solve_quadratic(
    sysm: System,
    alpha: float,
    beta: float = 0.0,
    L: sp.csr_matrix | None = None,
    prior: np.ndarray | None = None,
    lam: float = 0.0,
    weight: np.ndarray | None = None,
    x0: np.ndarray | None = None,
) -> SolveResult:
    A = sysm.An
    b = sysm.bn
    Atb = np.asarray(A.T @ b).ravel()
    if prior is None:
        prior = np.zeros(NPIX, dtype=np.float64)
    if weight is None:
        weight = np.ones(NPIX, dtype=np.float64)
    w = np.asarray(weight, dtype=np.float64).ravel()
    p = np.asarray(prior, dtype=np.float64).ravel()
    Luse = L if L is not None else L_FIXED

    def matvec(x: np.ndarray) -> np.ndarray:
        out = np.asarray(A.T @ (A @ x)).ravel() + alpha * x
        if beta:
            out += beta * np.asarray(Luse @ x).ravel()
        if lam:
            out += lam * w * x
        return out

    rhs = Atb + (lam * w * p if lam else 0.0)
    op = spla.LinearOperator((NPIX, NPIX), matvec=matvec, dtype=np.float64)
    iterations = 0
    def cb(_: np.ndarray) -> None:
        nonlocal iterations
        iterations += 1
    start = time.perf_counter()
    x, info = spla.cg(op, rhs, x0=x0, rtol=CG_RTOL, atol=0.0, maxiter=CG_MAXITER, callback=cb)
    seconds = time.perf_counter() - start
    residual = float(np.linalg.norm(matvec(x) - rhs) / max(np.linalg.norm(rhs), 1e-15))
    valid = bool(info == 0 and residual <= NORMAL_RESIDUAL_MAX and np.all(np.isfinite(x)))
    return SolveResult(np.asarray(x), int(info), int(iterations), float(seconds), residual, valid)


def gaussian_log_score(residual: np.ndarray, sigma: float) -> float:
    r = np.asarray(residual).ravel()
    s = max(float(sigma), 1e-12)
    return float(np.mean(-0.5 * ((r / s) ** 2 + math.log(2.0 * math.pi * s * s))))


def soft_threshold(x: np.ndarray, tau: float) -> np.ndarray:
    return np.sign(x) * np.maximum(np.abs(x) - tau, 0.0)


def lineage_hash(payload: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def make_frame_systems(blocks: list[sp.csr_matrix], sinos: list[np.ndarray]) -> dict[str, list[System]]:
    systems: dict[str, list[System]] = {"obs": [], "test": [], "o1": [], "o2": [], "all": []}
    for t, (A, m) in enumerate(zip(blocks, sinos)):
        for key, pos in (("obs", OBS_POS), ("test", TEST_POS), ("o1", O1_POS), ("o2", O2_POS), ("all", np.arange(P))):
            As, bs = subset_frame(A, m, pos)
            systems[key].append(make_system(As, bs, f"{key}_t{t}", SEED + 101 * t + len(pos)))
    return systems


def closure_for_frame(t: int, systems: dict[str, list[System]], alpha: float = 1e-2) -> ClosureState:
    s1, s2 = systems["o1"][t], systems["o2"][t]
    x1r = solve_quadratic(s1, alpha)
    x2r = solve_quadratic(s2, alpha)
    # Directed transport: late-view data enters the early-view state, and vice versa.
    h12r = solve_quadratic(s2, alpha, prior=x1r.x, lam=TRANSPORT_LAMBDA, x0=x1r.x)
    h21r = solve_quadratic(s1, alpha, prior=x2r.x, lam=TRANSPORT_LAMBDA, x0=x2r.x)
    h12, h21 = h12r.x, h21r.x
    fused = 0.5 * (h12 + h21)
    d_order = np.abs(h12 - h21)
    d_partial = np.abs(x1r.x - x2r.x)
    s_order = np.median(d_order[d_order > 0]) if np.any(d_order > 0) else 1.0
    s_partial = np.median(d_partial[d_partial > 0]) if np.any(d_partial > 0) else 1.0
    reliability = np.clip(
        np.exp(-d_order / max(s_order, 1e-12)) * np.exp(-d_partial / max(s_partial, 1e-12)),
        0.03,
        1.0,
    )
    hol = float(np.linalg.norm(h12 - h21) / max(0.5 * (np.linalg.norm(h12) + np.linalg.norm(h21)), 1e-15))
    payload = {
        "frame": t,
        "o1_positions": O1_POS.tolist(),
        "o2_positions": O2_POS.tolist(),
        "alpha": alpha,
        "transport_lambda": TRANSPORT_LAMBDA,
        "holonomy": hol,
    }
    valid = all(r.valid for r in (x1r, x2r, h12r, h21r))
    return ClosureState(t, x1r.x, x2r.x, h12, h21, fused, reliability, hol, valid, lineage_hash(payload))


def evaluate_projection(sysm: System, x: np.ndarray) -> dict[str, float]:
    pred = sysm.predict(x)
    return {"nrmse": nrmse(pred, sysm.b), "correlation": corr(pred, sysm.b)}


def select_framewise_alpha(systems: dict[str, list[System]]) -> tuple[float, list[dict[str, Any]]]:
    traces = []
    for alpha in ALPHAS:
        vals = []
        valid = True
        for t in TRAIN_FRAMES[4:]:
            r = solve_quadratic(systems["obs"][t], alpha)
            vals.append(evaluate_projection(systems["test"][t], r.x)["nrmse"])
            valid &= r.valid
        traces.append({"alpha": alpha, "mean_train_withheld_nrmse": float(np.mean(vals)), "valid": valid})
    best = min((r for r in traces if r["valid"]), key=lambda r: (r["mean_train_withheld_nrmse"], r["alpha"]))
    return float(best["alpha"]), traces


def select_fixed_beta(systems: dict[str, list[System]], alpha: float) -> tuple[float, list[dict[str, Any]]]:
    traces = []
    for beta in BETAS:
        vals = []
        valid = True
        for t in TRAIN_FRAMES[4:]:
            r = solve_quadratic(systems["obs"][t], alpha, beta=beta, L=L_FIXED)
            vals.append(evaluate_projection(systems["test"][t], r.x)["nrmse"])
            valid &= r.valid
        traces.append({"beta": beta, "mean_train_withheld_nrmse": float(np.mean(vals)), "valid": valid})
    best = min((r for r in traces if r["valid"]), key=lambda r: (r["mean_train_withheld_nrmse"], r["beta"]))
    return float(best["beta"]), traces


def attention_prior(t: int, current_sys: System, history: list[np.ndarray]) -> tuple[np.ndarray, list[float]]:
    if not history:
        return np.zeros(NPIX), []
    candidates = history[max(0, len(history) - 6):]
    errors = np.array([nrmse(current_sys.predict(x), current_sys.b) for x in candidates])
    z = -(errors - errors.min()) / max(np.std(errors), 1e-6)
    z -= z.max()
    weights = np.exp(z)
    weights /= weights.sum()
    prior = sum(float(w) * x for w, x in zip(weights, candidates))
    return np.asarray(prior), weights.tolist()


def low_rank_sparse_prior(framewise: np.ndarray, history: list[np.ndarray]) -> np.ndarray:
    if len(history) < 2:
        return history[-1] if history else np.zeros_like(framewise)
    H = np.column_stack(history[max(0, len(history) - 6):])
    U, s, _ = np.linalg.svd(H, full_matrices=False)
    rank = min(2, U.shape[1])
    low = U[:, :rank] @ (U[:, :rank].T @ framewise)
    residual = framewise - low
    tau = 0.5 * (np.median(np.abs(residual)) + 1e-12)
    return low + soft_threshold(residual, tau)


def wrong_lineage_source(t: int) -> int:
    candidates = list(range(0, max(t - 1, 1)))  # <= t-2
    correct = t - 2
    alternatives = [k for k in candidates if k != correct]
    if not alternatives:
        return 0
    return alternatives[(7 * t + 3) % len(alternatives)]


def run_sequence(
    method: str,
    systems: dict[str, list[System]],
    closures: list[ClosureState],
    alpha: float,
    beta: float,
    lam: float,
    upto: int,
) -> tuple[list[np.ndarray], list[dict[str, Any]], float]:
    xs: list[np.ndarray] = []
    meta: list[dict[str, Any]] = []
    total_time = 0.0
    for t in range(upto + 1):
        sysm = systems["obs"][t]
        base = solve_quadratic(sysm, alpha)
        if method == "FRAMEWISE_TIKHONOV":
            r = base
            extra = {}
        elif method == "FIXED_SPATIAL":
            r = solve_quadratic(sysm, alpha, beta=beta, L=L_FIXED, x0=base.x)
            extra = {}
        elif method == "RECURRENT_NO_DIN":
            prior = xs[-1] if xs else base.x
            r = solve_quadratic(sysm, alpha, prior=prior, lam=lam, x0=base.x)
            extra = {"prior_frame": t - 1 if xs else None}
        elif method == "STATE_SPACE_CV":
            if len(xs) >= 2:
                prior = 2.0 * xs[-1] - xs[-2]
            elif xs:
                prior = xs[-1]
            else:
                prior = base.x
            r = solve_quadratic(sysm, alpha, prior=prior, lam=lam, x0=base.x)
            extra = {"prior_order": 2 if len(xs) >= 2 else 1}
        elif method == "CROSS_ATTENTION_NO_DIN":
            prior, weights = attention_prior(t, sysm, xs)
            if not xs:
                prior = base.x
            r = solve_quadratic(sysm, alpha, prior=prior, lam=lam, x0=base.x)
            extra = {"attention_weights": weights}
        elif method == "LOW_RANK_SPARSE_PREDICTOR":
            prior = low_rank_sparse_prior(base.x, xs)
            if not xs:
                prior = base.x
            r = solve_quadratic(sysm, alpha, prior=prior, lam=lam, x0=base.x)
            extra = {"history_length": len(xs)}
        elif method == "SPATIOTEMPORAL_IRLS":
            prior = xs[-1] if xs else base.x
            r1 = solve_quadratic(sysm, alpha, prior=prior, lam=lam, beta=beta, L=adaptive_laplacian(base.x), x0=base.x)
            r = solve_quadratic(sysm, alpha, prior=prior, lam=lam, beta=beta, L=adaptive_laplacian(r1.x), x0=r1.x)
            r = SolveResult(r.x, max(r1.info, r.info), r1.iterations + r.iterations, r1.seconds + r.seconds,
                            max(r1.normal_residual, r.normal_residual), r1.valid and r.valid)
            extra = {"irls_steps": 2}
        elif method in ("DIN_DIAGONAL_REENTRY", "DIN_ORDER_REVERSED", "DIN_LINEAGE_SHUFFLED"):
            if t < 2:
                prior = xs[-1] if xs else base.x
                weight = np.ones(NPIX)
                source = None
                lin_hash = None
                hol = None
            else:
                source = t - 2 if method != "DIN_LINEAGE_SHUFFLED" else wrong_lineage_source(t)
                c = closures[source]
                state = c.h12 if method != "DIN_ORDER_REVERSED" else c.h21
                if source >= 2:
                    cprev = closures[source - 2]
                    prev_state = cprev.h12 if method != "DIN_ORDER_REVERSED" else cprev.h21
                    prior = state + (state - prev_state)
                else:
                    prior = state
                weight = c.reliability
                lin_hash = c.lineage_hash
                hol = c.holonomy
            Lc = adaptive_laplacian(prior)
            r = solve_quadratic(sysm, alpha, beta=beta, L=Lc, prior=prior, lam=lam, weight=weight, x0=base.x)
            extra = {"source_frame": source, "lineage_hash": lin_hash, "source_holonomy": hol}
        else:
            raise ValueError(method)
        xs.append(r.x)
        total_time += base.seconds if method != "FRAMEWISE_TIKHONOV" else 0.0
        total_time += r.seconds
        meta.append({
            "frame": t,
            "valid": r.valid,
            "info": r.info,
            "iterations": r.iterations,
            "normal_residual": r.normal_residual,
            "seconds": r.seconds,
            "observed_nrmse": evaluate_projection(sysm, r.x)["nrmse"],
            "withheld_nrmse": evaluate_projection(systems["test"][t], r.x)["nrmse"],
            **extra,
        })
    return xs, meta, total_time


def tune_dynamic_methods(
    systems: dict[str, list[System]], closures: list[ClosureState], alpha: float, beta: float
) -> tuple[dict[str, dict[str, float]], list[dict[str, Any]]]:
    selected: dict[str, dict[str, float]] = {
        "FRAMEWISE_TIKHONOV": {"alpha": alpha, "beta": 0.0, "lambda": 0.0},
        "FIXED_SPATIAL": {"alpha": alpha, "beta": beta, "lambda": 0.0},
    }
    traces: list[dict[str, Any]] = []
    dyn = [m for m in METHODS if m not in selected]
    for method in dyn:
        configs: list[tuple[float, float]] = []
        if method == "SPATIOTEMPORAL_IRLS":
            configs = [(b, l) for b in BETAS for l in LAMBDAS]
        elif method.startswith("DIN_"):
            configs = [(beta, l) for l in LAMBDAS]
        else:
            configs = [(0.0, l) for l in LAMBDAS]
        method_records = []
        for b, l in configs:
            xs, meta, seconds = run_sequence(method, systems, closures, alpha, b, l, max(TRANSITION_FRAMES))
            vals = [meta[t]["withheld_nrmse"] for t in TRANSITION_FRAMES]
            valid = all(meta[t]["valid"] for t in TRANSITION_FRAMES)
            rec = {
                "method": method,
                "alpha": alpha,
                "beta": b,
                "lambda": l,
                "transition_mean_nrmse": float(np.mean(vals)),
                "transition_median_nrmse": float(np.median(vals)),
                "valid": valid,
                "seconds": seconds,
            }
            traces.append(rec)
            method_records.append(rec)
        valid_records = [r for r in method_records if r["valid"]]
        if not valid_records:
            raise RuntimeError(f"no valid configuration for {method}")
        best = min(valid_records, key=lambda r: (r["transition_mean_nrmse"], r["lambda"], r["beta"]))
        selected[method] = {"alpha": alpha, "beta": float(best["beta"]), "lambda": float(best["lambda"])}
    return selected, traces


def transition_sigma(meta: list[dict[str, Any]], xs: list[np.ndarray], systems: dict[str, list[System]]) -> float:
    residuals = []
    for t in TRANSITION_FRAMES:
        residuals.append(systems["test"][t].predict(xs[t]) - systems["test"][t].b)
    r = np.concatenate(residuals)
    return float(np.sqrt(np.mean(r * r)) + 1e-12)


def change_proxy(method_x: list[np.ndarray], systems: dict[str, list[System]], t: int) -> dict[str, float]:
    # Detector-space change proxy. Because acquisition angles shift by one degree per frame,
    # this is explicitly an operator-relative proxy rather than intrinsic image ground truth.
    At = systems["test"][t]
    true_change = At.b - At.predict(method_x[t - 1])
    pred_change = At.predict(method_x[t]) - At.predict(method_x[t - 1])
    k = max(1, int(0.1 * true_change.size))
    truth_idx = set(np.argpartition(np.abs(true_change), -k)[-k:].tolist())
    pred_idx = set(np.argpartition(np.abs(pred_change), -k)[-k:].tolist())
    inter = len(truth_idx & pred_idx)
    union = len(truth_idx | pred_idx)
    return {
        "top10_jaccard": float(inter / max(union, 1)),
        "change_nrmse": nrmse(pred_change, true_change),
    }


def fisher_common_basis(systems: dict[str, list[System]]) -> dict[str, Any]:
    rng = np.random.default_rng(SEED + 808)
    Qraw = rng.normal(size=(NPIX, FISHER_DIM))
    Q, _ = np.linalg.qr(Qraw, mode="reduced")
    results = []
    for t in (0, 8, 12):
        record = {"frame": t}
        matrices = {}
        for key in ("o1", "o2", "obs"):
            A = systems[key][t].An
            B = np.asarray(A @ Q)
            F = B.T @ B
            eig = np.linalg.eigvalsh(F)
            eig = np.maximum(eig, 0.0)
            matrices[key] = eig
            record[key] = {
                "effective_rank_1e-8": int(np.sum(eig > max(eig.max(), 1e-30) * 1e-8)),
                "logdet_eps": float(np.sum(np.log(eig + 1e-10))),
                "min_eigen": float(eig.min()),
                "max_eigen": float(eig.max()),
                "condition_eps": float((eig.max() + 1e-10) / (eig.min() + 1e-10)),
            }
        best_single = max(record["o1"]["logdet_eps"], record["o2"]["logdet_eps"])
        record["joint_logdet_gain"] = float(record["obs"]["logdet_eps"] - best_single)
        results.append(record)
    return {
        "status": "TASK_RELATIVE_COMMON_RANDOM_BASIS",
        "basis_dimension": FISHER_DIM,
        "frames": results,
        "interpretation_limit": "Does not establish full-space identifiability.",
    }


def save_montage(path: Path, images: dict[str, np.ndarray]) -> None:
    names = list(images)
    cols = 5
    rows = math.ceil(len(names) / cols)
    fig, axes = plt.subplots(rows, cols, figsize=(3.2 * cols, 3.2 * rows))
    axes = np.atleast_1d(axes).ravel()
    vals = np.concatenate([images[n] for n in names])
    lo, hi = np.percentile(vals, [1, 99])
    for ax, name in zip(axes, names):
        ax.imshow(images[name].reshape((N, N), order="F"), cmap="gray", vmin=lo, vmax=hi)
        ax.set_title(name, fontsize=8)
        ax.axis("off")
    for ax in axes[len(names):]:
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def main() -> int:
    root = Path(os.environ.get("G2_WORKDIR", "/mnt/data/CFL_G2_DYNAMIC_DIN_WORK")).resolve()
    data_dir = root / "data"
    result_dir = root / "results"
    visual_dir = root / "visuals"
    for d in (data_dir, result_dir, visual_dir):
        d.mkdir(parents=True, exist_ok=True)
    data_path = data_dir / "DataDynamic_128x15.mat"
    download_exact(data_path)
    A, m, mat_meta, loader = load_mat(data_path)
    blocks, sinos, block_audit = split_frames(A, m)
    if block_audit["off_frame_nnz"] != 0:
        raise RuntimeError(f"dynamic matrix is not frame-block diagonal: {block_audit['off_frame_nnz']} off-frame nnz")
    systems = make_frame_systems(blocks, sinos)

    data_audit = {
        "program_id": PROGRAM_ID,
        "upstream_doi": UPSTREAM_DOI,
        "source_url": DATA_URL,
        "size_bytes": data_path.stat().st_size,
        "md5": hash_file(data_path, "md5"),
        "sha256": hash_file(data_path, "sha256"),
        "expected_md5_match": hash_file(data_path, "md5") == EXPECTED_MD5,
        "loader": loader,
        "mat_metadata": mat_meta,
        "A_shape": list(A.shape),
        "A_nnz": int(A.nnz),
        "sinogram_shape": list(m.shape),
        "finite_A": bool(np.all(np.isfinite(A.data))),
        "finite_sinogram": bool(np.all(np.isfinite(m))),
        "missingness": int(np.size(m) - np.isfinite(m).sum()),
        "silent_imputation": False,
        "frames": T,
        "projections_per_frame": P,
        "detectors": D,
        "test_positions": TEST_POS.tolist(),
        "observed_positions": OBS_POS.tolist(),
        "block_audit": block_audit,
    }
    write_json(result_dir / "DATA_AUDIT.json", data_audit)

    alpha, alpha_trace = select_framewise_alpha(systems)
    beta, beta_trace = select_fixed_beta(systems, alpha)
    closures = [closure_for_frame(t, systems, alpha) for t in range(T)]
    if not all(c.valid for c in closures):
        raise RuntimeError("closure construction failed solver validity contract")
    selected, tuning = tune_dynamic_methods(systems, closures, alpha, beta)

    all_x: dict[str, list[np.ndarray]] = {}
    all_meta: dict[str, list[dict[str, Any]]] = {}
    method_cost: dict[str, float] = {}
    for method in METHODS:
        cfg = selected[method]
        xs, meta, seconds = run_sequence(method, systems, closures, cfg["alpha"], cfg["beta"], cfg["lambda"], T - 1)
        if not all(mr["valid"] for mr in meta):
            raise RuntimeError(f"{method} has invalid final solves")
        all_x[method] = xs
        all_meta[method] = meta
        method_cost[method] = seconds

    evaluations: dict[str, Any] = {}
    for method in METHODS:
        xs = all_x[method]
        sigma = transition_sigma(all_meta[method], xs, systems)
        frames = []
        for t in TEST_FRAMES:
            pred = systems["test"][t].predict(xs[t])
            residual = pred - systems["test"][t].b
            ch = change_proxy(xs, systems, t)
            frames.append({
                "frame": t,
                "nrmse": nrmse(pred, systems["test"][t].b),
                "correlation": corr(pred, systems["test"][t].b),
                "gaussian_log_score": gaussian_log_score(residual, sigma),
                "coverage_90": float(np.mean(np.abs(residual) <= 1.6448536269514722 * sigma)),
                **ch,
            })
        evaluations[method] = {
            "selected_config": selected[method],
            "transition_sigma": sigma,
            "test_frames": frames,
            "median_test_nrmse": float(np.median([f["nrmse"] for f in frames])),
            "mean_test_nrmse": float(np.mean([f["nrmse"] for f in frames])),
            "mean_log_score": float(np.mean([f["gaussian_log_score"] for f in frames])),
            "mean_coverage_90": float(np.mean([f["coverage_90"] for f in frames])),
            "mean_change_jaccard": float(np.mean([f["top10_jaccard"] for f in frames])),
            "mean_change_nrmse": float(np.mean([f["change_nrmse"] for f in frames])),
            "seconds": method_cost[method],
        }

    baseline_names = [m for m in METHODS if not m.startswith("DIN_")]
    best_baseline = min(baseline_names, key=lambda k: evaluations[k]["median_test_nrmse"])
    din = evaluations["DIN_DIAGONAL_REENTRY"]
    best = evaluations[best_baseline]
    gain = (best["median_test_nrmse"] - din["median_test_nrmse"]) / best["median_test_nrmse"]
    frame_wins = sum(
        evaluations["DIN_DIAGONAL_REENTRY"]["test_frames"][i]["nrmse"]
        < (1.0 - SUPPORT_MARGIN) * evaluations[best_baseline]["test_frames"][i]["nrmse"]
        for i in range(len(TEST_FRAMES))
    )
    reversed_gap = (
        evaluations["DIN_ORDER_REVERSED"]["median_test_nrmse"] - din["median_test_nrmse"]
    ) / evaluations["DIN_ORDER_REVERSED"]["median_test_nrmse"]
    shuffled_gap = (
        evaluations["DIN_LINEAGE_SHUFFLED"]["median_test_nrmse"] - din["median_test_nrmse"]
    ) / evaluations["DIN_LINEAGE_SHUFFLED"]["median_test_nrmse"]
    cost_ratio = din["seconds"] / max(best["seconds"], 1e-12)

    if gain >= SUPPORT_MARGIN and frame_wins >= 3 and reversed_gap >= ABLATION_MARGIN and shuffled_gap >= ABLATION_MARGIN and cost_ratio <= MAX_COST_RATIO:
        outcome = "DIN_LOCAL_SUPPORT"
        qstate = "+0_PROTOFORM_UNREPLICATED_RESOLUTION"
    elif gain <= -SUPPORT_MARGIN and frame_wins <= 1:
        outcome = "DIN_REFUTED"
        qstate = "0_NO_CLOSURE"
    else:
        outcome = "DIN_BASELINE_EQUIVALENT"
        qstate = "0_NO_CLOSURE"
    if evaluations["DIN_ORDER_REVERSED"]["median_test_nrmse"] < (1.0 - SUPPORT_MARGIN) * din["median_test_nrmse"]:
        qstate = "-1_ORDER_ANTI_OPERATOR_CANDIDATE"

    false_closures = []
    for method in METHODS:
        transition_mean = float(np.mean([all_meta[method][t]["withheld_nrmse"] for t in TRANSITION_FRAMES]))
        test_mean = evaluations[method]["mean_test_nrmse"]
        false_closures.append({
            "method": method,
            "transition_mean_nrmse": transition_mean,
            "test_mean_nrmse": test_mean,
            "false_closure": bool(
                transition_mean < 0.95 * float(np.mean([all_meta[best_baseline][t]["withheld_nrmse"] for t in TRANSITION_FRAMES]))
                and test_mean > 1.05 * evaluations[best_baseline]["mean_test_nrmse"]
            ),
        })

    fisher = fisher_common_basis(systems)
    write_json(result_dir / "FISHER_COMMON_BASIS.json", fisher)

    closure_summary = [{
        "frame": c.frame,
        "holonomy": c.holonomy,
        "valid": c.valid,
        "reliability_mean": float(np.mean(c.reliability)),
        "reliability_p10": float(np.quantile(c.reliability, 0.1)),
        "reliability_p90": float(np.quantile(c.reliability, 0.9)),
        "lineage_hash": c.lineage_hash,
    } for c in closures]

    adjudication = {
        "program_id": PROGRAM_ID,
        "outcome": outcome,
        "quaternary_state": qstate,
        "best_baseline": best_baseline,
        "din_relative_gain_vs_best_baseline": float(gain),
        "din_frame_wins_over_2_percent": int(frame_wins),
        "proper_vs_reversed_relative_gain": float(reversed_gap),
        "proper_vs_shuffled_relative_gain": float(shuffled_gap),
        "din_cost_ratio_vs_best_baseline": float(cost_ratio),
        "authority": "NONE",
        "promotion": "BLOCKED",
        "canonical_TOS_DIN": "NOT_TESTED",
        "change_localization_status": "OPERATOR_RELATIVE_PROXY_NOT_INTRINSIC_GROUND_TRUTH",
        "euclideanization_claim": "NOT_TESTED",
        "single_resolution": True,
    }

    results = {
        "program_id": PROGRAM_ID,
        "selected_hyperparameters": selected,
        "alpha_trace": alpha_trace,
        "beta_trace": beta_trace,
        "dynamic_tuning_trace": tuning,
        "evaluations": evaluations,
        "closure_states": closure_summary,
        "false_closure_audit": false_closures,
        "adjudication": adjudication,
        "method_sequence_meta": {m: [r for r in all_meta[m] if r["frame"] in TEST_FRAMES] for m in METHODS},
    }
    write_json(result_dir / "RESULTS.json", results)
    write_json(result_dir / "FINAL_ADJUDICATION.json", adjudication)

    with (result_dir / "TUNING_TRACE.csv").open("w", newline="", encoding="utf-8") as fh:
        fields = sorted({k for r in tuning for k in r.keys()})
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader(); w.writerows(tuning)

    images = {f"{m}_t15": all_x[m][15] for m in METHODS}
    save_montage(visual_dir / "METHODS_FRAME15.png", images)
    save_montage(visual_dir / "DIN_TIME_SERIES.png", {f"DIN_t{t}": all_x["DIN_DIAGONAL_REENTRY"][t] for t in range(T)})

    manifest = {
        "program_id": PROGRAM_ID,
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "dataset_sha256": data_audit["sha256"],
        "result_sha256": hash_file(result_dir / "RESULTS.json"),
        "adjudication_sha256": hash_file(result_dir / "FINAL_ADJUDICATION.json"),
    }
    write_json(result_dir / "RUN_MANIFEST.json", manifest)

    report = f"""# CFL-UEP G2 Dynamic DIN material gate\n\n- Outcome: **{outcome}**\n- Quaternary state: **{qstate}**\n- Best baseline: **{best_baseline}**\n- DIN relative gain: **{gain:.6%}**\n- Proper vs reversed: **{reversed_gap:.6%}**\n- Proper vs shuffled lineage: **{shuffled_gap:.6%}**\n- DIN cost ratio: **{cost_ratio:.3f}x**\n- Authority: **NONE**\n\nThe change-localization endpoint is an operator-relative detector-space proxy, not intrinsic image-space ground truth. Single-resolution evidence cannot promote or canonize DIN.\n"""
    (result_dir / "REPORT.md").write_text(report, encoding="utf-8")

    print(json.dumps(adjudication, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
