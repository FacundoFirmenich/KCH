#!/usr/bin/env python3
"""CFL-UEP G2.1: DIN lens/router on measured dynamic gel-phantom sinograms.

The experiment stays in detector-angle space. It never claims an intrinsic image-space
reconstruction or non-Euclidean ontology. DIN may only alter the future acquisition
lens (angle scores) and route among deployable temporal priors. Direct injection of an
old closure image/state as a pixel prior is forbidden.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

import numpy as np
import scipy
import scipy.io
import scipy.linalg

try:
    import h5py  # type: ignore
except Exception:  # pragma: no cover
    h5py = None

SEED = 20260927
RNG = np.random.default_rng(SEED)
PROGRAM_ID = "CFL-UEP-G2.1-DIN-LENS-ROUTER-GEL-20260927"
PRIMARY_FRAMES = 17
CAL_FRAMES = tuple(range(8, 12))
TEST_FRAMES = tuple(range(12, 17))
PRIMARY_BUDGET = 30
BUDGETS = (18, 30, 45)
FOURIER_ORDERS = (4, 8, 12)
RIDGES = (0.01, 0.1)
RHOS = (0.0, 0.5, 1.0)
DIN_ETAS = (0.25, 0.5, 0.75)
METHODS = (
    "UNIFORM",
    "CURRENT_IG",
    "RECENT_ATTENTION",
    "STATE_SPACE",
    "LOW_RANK_SPARSE",
    "DIN_LENS_ROUTER",
    "DIN_ORDER_REVERSED",
    "DIN_LINEAGE_SHUFFLED",
    "DIN_SOURCE_TIME_SHUFFLED",
)
DEPLOYABLE = METHODS[:6]
ABLATIONS = METHODS[6:]
ORACLE = "ORACLE_POSTHOC_CEILING"


@dataclass(frozen=True)
class Config:
    order: int
    ridge: float
    rho: float
    eta: float = 0.5


@dataclass
class FrameResult:
    method: str
    frame: int
    budget: int
    nrmse: float
    correlation: float
    log_score: float | None
    coverage90: float | None
    seconds: float
    selected_angles: list[int]
    lineage_hash: str | None
    source_frame: int | None
    holonomy_mean: float | None


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def md5_file(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def _unwrap(x: Any) -> Any:
    while isinstance(x, np.ndarray) and x.dtype == object and x.size == 1:
        x = x.reshape(-1)[0]
    return x


def _field(obj: Any, name: str) -> Any:
    obj = _unwrap(obj)
    if hasattr(obj, name):
        return _unwrap(getattr(obj, name))
    if isinstance(obj, np.void) and obj.dtype.names and name in obj.dtype.names:
        return _unwrap(obj[name])
    if isinstance(obj, dict) and name in obj:
        return _unwrap(obj[name])
    raise KeyError(f"field {name!r} not present in {type(obj)!r}")


def _classic_mat(path: Path) -> dict[str, Any]:
    return scipy.io.loadmat(path, squeeze_me=True, struct_as_record=False)


def load_primary(path: Path, key: str) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Return frames x angles x detectors and angles in degrees."""
    try:
        mat = _classic_mat(path)
        obj = mat[key]
        sino = np.asarray(_field(obj, "sinogram"), dtype=np.float64)
        params = _field(obj, "parameters")
        angles = np.asarray(_field(params, "angles"), dtype=np.float64).reshape(-1)
        meta = {"loader": "scipy.io.loadmat", "top_keys": sorted(k for k in mat if not k.startswith("__"))}
    except Exception as exc:
        if h5py is None:
            raise
        with h5py.File(path, "r") as f:  # pragma: no cover - defensive path
            raise RuntimeError(f"HDF5 MATLAB layout not supported for this dataset: {list(f.keys())}") from exc
    if np.nanmax(np.abs(angles)) <= 2 * np.pi + 1e-6:
        angles = np.rad2deg(angles)
    angles = np.mod(angles, 360.0)
    if sino.ndim != 3:
        raise ValueError(f"expected 3D primary sinogram, got {sino.shape}")
    frame_axes = [i for i, n in enumerate(sino.shape) if n == PRIMARY_FRAMES]
    angle_axes = [i for i, n in enumerate(sino.shape) if n == angles.size]
    if not frame_axes or not angle_axes:
        raise ValueError(f"cannot identify frame/angle axes: shape={sino.shape}, angles={angles.size}")
    fa = frame_axes[0]
    aa = next((i for i in angle_axes if i != fa), angle_axes[0])
    da = next(i for i in range(3) if i not in (fa, aa))
    sino = np.moveaxis(sino, (fa, aa, da), (0, 1, 2))
    order = np.argsort(angles)
    angles = angles[order]
    sino = sino[:, order, :]
    if not np.isfinite(sino).all():
        raise ValueError("non-finite primary sinogram values")
    return sino, angles, meta


def load_extra(path: Path, key: str) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    mat = _classic_mat(path)
    obj = mat[key]
    sino = np.asarray(_field(obj, "sinogram"), dtype=np.float64)
    params = _field(obj, "parameters")
    angles = np.asarray(_field(params, "angles"), dtype=np.float64).reshape(-1)
    if np.nanmax(np.abs(angles)) <= 2 * np.pi + 1e-6:
        angles = np.rad2deg(angles)
    angles = np.mod(angles, 360.0)
    sino = np.squeeze(sino)
    if sino.ndim != 2:
        raise ValueError(f"expected 2D extra sinogram, got {sino.shape}")
    if sino.shape[0] == angles.size:
        pass
    elif sino.shape[1] == angles.size:
        sino = sino.T
    else:
        raise ValueError(f"cannot identify extra angle axis: {sino.shape}, angles={angles.size}")
    order = np.argsort(angles)
    angles = angles[order]
    sino = sino[order]
    if not np.isfinite(sino).all():
        raise ValueError("non-finite extra sinogram values")
    return sino, angles, {"loader": "scipy.io.loadmat", "top_keys": sorted(k for k in mat if not k.startswith("__"))}


def nrmse(pred: np.ndarray, truth: np.ndarray) -> float:
    den = np.linalg.norm(truth.ravel())
    return float(np.linalg.norm((pred - truth).ravel()) / max(den, 1e-12))


def corr(pred: np.ndarray, truth: np.ndarray) -> float:
    a = pred.ravel() - float(np.mean(pred))
    b = truth.ravel() - float(np.mean(truth))
    den = np.linalg.norm(a) * np.linalg.norm(b)
    return float(np.dot(a, b) / max(den, 1e-12))


def normalize_score(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64).reshape(-1)
    x = np.where(np.isfinite(x), x, np.nanmedian(x[np.isfinite(x)]) if np.isfinite(x).any() else 0.0)
    lo, hi = np.quantile(x, [0.05, 0.95]) if x.size > 5 else (float(np.min(x)), float(np.max(x)))
    if hi <= lo + 1e-15:
        return np.zeros_like(x)
    return np.clip((x - lo) / (hi - lo), 0.0, 1.0)


def angle_distance(a: np.ndarray, b: float) -> np.ndarray:
    d = np.abs(a - b)
    return np.minimum(d, 360.0 - d)


def evenly_spaced_indices(angles: np.ndarray, candidates: np.ndarray, budget: int, offset: float = 0.0) -> np.ndarray:
    targets = np.mod(np.linspace(0.0, 360.0, budget, endpoint=False) + offset, 360.0)
    available = set(int(i) for i in candidates)
    selected: list[int] = []
    for target in targets:
        if not available:
            break
        idx = min(available, key=lambda i: float(angle_distance(np.array([angles[i]]), target)[0]))
        selected.append(idx)
        available.remove(idx)
    return np.asarray(sorted(selected), dtype=int)


def greedy_diverse_select(
    angles: np.ndarray,
    candidates: np.ndarray,
    score: np.ndarray,
    budget: int,
    initial: Iterable[int] = (),
    score_weight: float = 0.72,
) -> np.ndarray:
    selected = list(dict.fromkeys(int(i) for i in initial if int(i) in set(candidates.tolist())))
    remaining = set(int(i) for i in candidates) - set(selected)
    s = normalize_score(score)
    while len(selected) < budget and remaining:
        if not selected:
            idx = max(remaining, key=lambda i: (float(s[i]), -i))
        else:
            sel_angles = angles[np.asarray(selected)]
            best = None
            best_obj = -np.inf
            for i in remaining:
                min_d = float(np.min(angle_distance(sel_angles, float(angles[i])))) / 180.0
                obj = score_weight * float(s[i]) + (1.0 - score_weight) * min_d
                if obj > best_obj + 1e-15 or (abs(obj - best_obj) <= 1e-15 and (best is None or i < best)):
                    best, best_obj = i, obj
            idx = int(best)
        selected.append(idx)
        remaining.remove(idx)
    return np.asarray(sorted(selected), dtype=int)


def basis(angles_deg: np.ndarray, order: int) -> np.ndarray:
    theta = np.deg2rad(np.mod(angles_deg, 360.0))
    cols = [np.ones_like(theta)]
    for k in range(1, order + 1):
        cols.append(np.cos(k * theta))
        cols.append(np.sin(k * theta))
    return np.column_stack(cols)


def harmonic_penalty(order: int) -> np.ndarray:
    vals = [1e-4]
    for k in range(1, order + 1):
        vals.extend([float(k * k), float(k * k)])
    return np.diag(vals)


def fit_residual(
    y: np.ndarray,
    prior: np.ndarray,
    angles: np.ndarray,
    selected: np.ndarray,
    order: int,
    ridge: float,
) -> tuple[np.ndarray, np.ndarray]:
    B = basis(angles, order)
    Bs = B[selected]
    P = harmonic_penalty(order)
    gram = Bs.T @ Bs + ridge * P
    rhs = Bs.T @ (y[selected] - prior[selected])
    coef = scipy.linalg.solve(gram, rhs, assume_a="pos", check_finite=False)
    pred = prior + B @ coef
    pred[selected] = y[selected]
    invg = scipy.linalg.solve(gram, np.eye(gram.shape[0]), assume_a="pos", check_finite=False)
    variance = np.einsum("ij,jk,ik->i", B, invg, B)
    return pred, variance


def interpolate_angles(values: np.ndarray, source_angles: np.ndarray, target_angles: np.ndarray, order: int = 24, ridge: float = 1e-4) -> np.ndarray:
    B0 = basis(source_angles, min(order, max(1, (len(source_angles) - 1) // 2)))
    Bt = basis(target_angles, min(order, max(1, (len(source_angles) - 1) // 2)))
    P = harmonic_penalty((B0.shape[1] - 1) // 2)
    coef = scipy.linalg.solve(B0.T @ B0 + ridge * P, B0.T @ values, assume_a="pos", check_finite=False)
    return Bt @ coef


def linear_prior(data: np.ndarray, t: int, rho: float) -> np.ndarray:
    if t <= 0:
        return np.zeros_like(data[0])
    if t == 1:
        return data[0].copy()
    return data[t - 1] + rho * (data[t - 1] - data[t - 2])


def state_space_prior(data: np.ndarray, t: int) -> np.ndarray:
    if t <= 1:
        return linear_prior(data, t, 0.0)
    start = max(0, t - 8)
    hist = data[start:t]
    mean = np.mean(hist, axis=0)
    x = (hist[:-1] - mean).reshape(hist.shape[0] - 1, -1)
    y = (hist[1:] - mean).reshape(hist.shape[0] - 1, -1)
    den = float(np.sum(x * x))
    phi = float(np.sum(x * y) / max(den, 1e-12))
    phi = float(np.clip(phi, -0.25, 1.25))
    return mean + phi * (data[t - 1] - mean)


def low_rank_sparse_prior(data: np.ndarray, t: int, rank: int = 3) -> np.ndarray:
    if t <= 2:
        return linear_prior(data, t, 0.5)
    start = max(0, t - 8)
    hist = data[start:t]
    shape = hist.shape[1:]
    X = hist.reshape(hist.shape[0], -1)
    mean = X.mean(axis=0, keepdims=True)
    Xc = X - mean
    gram = Xc @ Xc.T
    evals, U = np.linalg.eigh(gram)
    idx = np.argsort(evals)[::-1]
    evals = np.maximum(evals[idx], 0.0)
    U = U[:, idx]
    r = min(rank, max(1, int(np.sum(evals > 1e-10 * max(evals[0], 1e-12)))))
    S = np.sqrt(np.maximum(evals[:r], 1e-15))
    V = (Xc.T @ U[:, :r]) / S
    scores = U[:, :r] * S
    tt = np.arange(scores.shape[0], dtype=np.float64)
    A = np.column_stack([np.ones_like(tt), tt])
    coef = np.linalg.lstsq(A, scores, rcond=None)[0]
    score_next = np.array([1.0, float(scores.shape[0])]) @ coef
    low = mean.reshape(-1) + V @ score_next
    diffs = np.diff(X, axis=0)
    sparse = np.median(diffs[-min(3, len(diffs)):], axis=0)
    return (low + 0.35 * sparse).reshape(shape)


def all_priors(data: np.ndarray, t: int, rho: float) -> dict[str, np.ndarray]:
    return {
        "linear": linear_prior(data, t, rho),
        "state": state_space_prior(data, t),
        "lowrank": low_rank_sparse_prior(data, t),
    }


def temporal_error_score(data: np.ndarray, t: int, prior_fn: Callable[[np.ndarray, int], np.ndarray]) -> np.ndarray:
    errs = []
    for s in range(max(2, t - 7), t):
        e = data[s] - prior_fn(data, s)
        errs.append(np.mean(e * e, axis=1))
    if not errs:
        return np.ones(data.shape[1])
    return np.sqrt(np.mean(np.stack(errs), axis=0))


def recent_score(data: np.ndarray, t: int) -> np.ndarray:
    if t <= 1:
        return np.ones(data.shape[1])
    return np.sqrt(np.mean((data[t - 1] - data[t - 2]) ** 2, axis=1))


def lowrank_score(data: np.ndarray, t: int) -> np.ndarray:
    prior = low_rank_sparse_prior(data, t)
    last = data[t - 1]
    return np.sqrt(np.mean((last - prior) ** 2, axis=1))


def sequential_closure(
    y: np.ndarray,
    prior: np.ndarray,
    angles: np.ndarray,
    first: np.ndarray,
    second: np.ndarray,
    order: int,
    ridge: float,
    preserve: float = 10.0,
) -> np.ndarray:
    B = basis(angles, order)
    P = harmonic_penalty(order)
    B1, B2 = B[first], B[second]
    g1 = B1.T @ B1 + ridge * P
    c1 = scipy.linalg.solve(g1, B1.T @ (y[first] - prior[first]), assume_a="pos", check_finite=False)
    state = prior + B @ c1
    g2 = B2.T @ B2 + preserve * (B1.T @ B1) + ridge * P
    c2 = scipy.linalg.solve(g2, B2.T @ (y[second] - state[second]), assume_a="pos", check_finite=False)
    return state + B @ c2


def closure_profile(data: np.ndarray, angles: np.ndarray, source_t: int, cfg: Config) -> dict[str, Any]:
    n = len(angles)
    candidates = np.arange(n, dtype=int)
    o1 = evenly_spaced_indices(angles, candidates, min(PRIMARY_BUDGET, n // 4), 0.0)
    offset = 180.0 / max(len(o1), 1)
    o2 = evenly_spaced_indices(angles, np.setdiff1d(candidates, o1), len(o1), offset)
    p = linear_prior(data, source_t, cfg.rho)
    h12 = sequential_closure(data[source_t], p, angles, o1, o2, cfg.order, cfg.ridge)
    h21 = sequential_closure(data[source_t], p, angles, o2, o1, cfg.order, cfg.ridge)
    fused = 0.5 * (h12 + h21)
    hol = np.sqrt(np.mean((h12 - h21) ** 2, axis=1))
    inn12 = np.sqrt(np.mean((h12 - p) ** 2, axis=1))
    inn21 = np.sqrt(np.mean((h21 - p) ** 2, axis=1))
    innovation = np.sqrt(np.mean((fused - p) ** 2, axis=1))
    if source_t > 2:
        prev_p = linear_prior(data, source_t - 1, cfg.rho)
        prev = 0.5 * (
            sequential_closure(data[source_t - 1], prev_p, angles, o1, o2, cfg.order, cfg.ridge)
            + sequential_closure(data[source_t - 1], prev_p, angles, o2, o1, cfg.order, cfg.ridge)
        )
        temporal = np.sqrt(np.mean((fused - prev) ** 2, axis=1))
    else:
        temporal = innovation.copy()
    payload = {
        "program": PROGRAM_ID,
        "source_t": int(source_t),
        "o1": o1.tolist(),
        "o2": o2.tolist(),
        "config": asdict(cfg),
        "h12_digest": sha256_bytes(np.ascontiguousarray(h12).view(np.uint8).tobytes()),
        "h21_digest": sha256_bytes(np.ascontiguousarray(h21).view(np.uint8).tobytes()),
    }
    return {
        "h12": h12,
        "h21": h21,
        "fused": fused,
        "holonomy": hol,
        "innovation": innovation,
        "inn12": inn12,
        "inn21": inn21,
        "temporal": temporal,
        "lineage_hash": sha256_bytes(canonical_json(payload).encode()),
        "source_t": source_t,
    }


def din_lens(
    data: np.ndarray,
    angles: np.ndarray,
    t: int,
    cfg: Config,
    variant: str,
) -> tuple[np.ndarray, np.ndarray, str, int, float]:
    if variant == "DIN_SOURCE_TIME_SHUFFLED":
        source_t = max(2, t - 4)
    else:
        source_t = max(2, t - 2)
    cp = closure_profile(data, angles, source_t, cfg)
    u = normalize_score(cp["holonomy"])
    temp = normalize_score(cp["temporal"])
    if variant == "DIN_ORDER_REVERSED":
        directed = normalize_score(cp["inn21"])
    else:
        directed = normalize_score(cp["inn12"])
    innovation = normalize_score(cp["innovation"])
    lens = 0.32 * u + 0.28 * temp + 0.25 * directed + 0.15 * innovation
    w_state = normalize_score(u + 0.5 * temp)
    w_low = normalize_score(temp + 0.5 * innovation) * (1.0 - 0.35 * w_state)
    w_lin = np.clip(1.0 - 0.55 * w_state - 0.45 * w_low, 0.05, 1.0)
    W = np.column_stack([w_lin, w_state, w_low])
    W /= W.sum(axis=1, keepdims=True)
    lineage = cp["lineage_hash"]
    if variant == "DIN_LINEAGE_SHUFFLED":
        seed = int(hashlib.sha256(f"{t}:{lineage}".encode()).hexdigest()[:8], 16)
        perm = np.random.default_rng(seed).permutation(len(angles))
        lens = lens[perm]
        W = W[perm]
        lineage = sha256_bytes((lineage + ":ANGLE_SHUFFLED").encode())
    return lens, W, lineage, source_t, float(np.mean(cp["holonomy"]))


def evaluation_indices(n_angles: int, offset: int) -> np.ndarray:
    step = max(1, n_angles // 60)
    idx = np.arange(offset % step, n_angles, step, dtype=int)
    return idx[:60] if idx.size >= 60 else idx


def choose_and_predict(
    data: np.ndarray,
    angles: np.ndarray,
    t: int,
    method: str,
    cfg: Config,
    budget: int,
    eval_idx: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, str | None, int | None, float | None]:
    y = data[t]
    n = len(angles)
    candidates = np.setdiff1d(np.arange(n, dtype=int), eval_idx)
    priors = all_priors(data, t, cfg.rho)
    lineage = None
    source_t = None
    hol = None
    if method == "UNIFORM":
        prior = priors["linear"]
        selected = evenly_spaced_indices(angles, candidates, budget, 0.0)
    elif method == "RECENT_ATTENTION":
        prior = priors["linear"]
        selected = greedy_diverse_select(angles, candidates, recent_score(data, t), budget)
    elif method == "STATE_SPACE":
        prior = priors["state"]
        score = temporal_error_score(data, t, lambda d, s: state_space_prior(d, s))
        selected = greedy_diverse_select(angles, candidates, score, budget)
    elif method == "LOW_RANK_SPARSE":
        prior = priors["lowrank"]
        selected = greedy_diverse_select(angles, candidates, lowrank_score(data, t), budget)
    elif method in ("CURRENT_IG", "DIN_LENS_ROUTER", "DIN_ORDER_REVERSED", "DIN_LINEAGE_SHUFFLED", "DIN_SOURCE_TIME_SHUFFLED"):
        seed_n = min(8, max(4, budget // 3))
        seed = evenly_spaced_indices(angles, candidates, seed_n, 0.0)
        if method == "CURRENT_IG":
            prior = priors["linear"]
            _, postvar = fit_residual(y, prior, angles, seed, cfg.order, cfg.ridge)
            histvar = temporal_error_score(data, t, lambda d, s: linear_prior(d, s, cfg.rho))
            score = 0.65 * normalize_score(postvar) + 0.35 * normalize_score(histvar)
        else:
            lens, W, lineage, source_t, hol = din_lens(data, angles, t, cfg, method)
            prior = (
                W[:, 0, None] * priors["linear"]
                + W[:, 1, None] * priors["state"]
                + W[:, 2, None] * priors["lowrank"]
            )
            _, postvar = fit_residual(y, prior, angles, seed, cfg.order, cfg.ridge)
            current = normalize_score(postvar)
            score = cfg.eta * normalize_score(lens) + (1.0 - cfg.eta) * current
        selected = greedy_diverse_select(angles, candidates, score, budget, initial=seed)
    elif method == ORACLE:
        candidate_priors = list(priors.values())
        oracle_prior = min(candidate_priors, key=lambda p: nrmse(p[eval_idx], y[eval_idx]))
        prior = oracle_prior
        actual = np.sqrt(np.mean((y - prior) ** 2, axis=1))
        selected = greedy_diverse_select(angles, candidates, actual, budget, score_weight=0.82)
    else:
        raise KeyError(method)
    pred, _ = fit_residual(y, prior, angles, selected, cfg.order, cfg.ridge)
    return pred, selected, lineage, source_t, hol


def evaluate_frame(
    data: np.ndarray,
    angles: np.ndarray,
    t: int,
    method: str,
    cfg: Config,
    budget: int,
    eval_idx: np.ndarray,
    sigma: float | None = None,
) -> FrameResult:
    start = time.perf_counter()
    pred, selected, lineage, source_t, hol = choose_and_predict(data, angles, t, method, cfg, budget, eval_idx)
    elapsed = time.perf_counter() - start
    err = pred[eval_idx] - data[t, eval_idx]
    if sigma is None:
        log_score = None
        coverage = None
    else:
        s = max(float(sigma), 1e-12)
        log_score = float(np.mean(-0.5 * (np.log(2 * np.pi * s * s) + (err / s) ** 2)))
        coverage = float(np.mean(np.abs(err) <= 1.6448536269514722 * s))
    return FrameResult(
        method=method,
        frame=t,
        budget=budget,
        nrmse=nrmse(pred[eval_idx], data[t, eval_idx]),
        correlation=corr(pred[eval_idx], data[t, eval_idx]),
        log_score=log_score,
        coverage90=coverage,
        seconds=elapsed,
        selected_angles=[int(i) for i in selected],
        lineage_hash=lineage,
        source_frame=source_t,
        holonomy_mean=hol,
    )


def config_grid(method: str) -> list[Config]:
    etas = DIN_ETAS if method.startswith("DIN_") else (0.5,)
    return [Config(o, r, rho, eta) for o in FOURIER_ORDERS for r in RIDGES for rho in RHOS for eta in etas]


def tune_method(data: np.ndarray, angles: np.ndarray, method: str, budget: int) -> tuple[Config, list[dict[str, Any]], float]:
    eval_idx = evaluation_indices(len(angles), 1)
    traces: list[dict[str, Any]] = []
    best_cfg: Config | None = None
    best_score = np.inf
    best_errors: list[np.ndarray] = []
    for cfg in config_grid(method):
        vals = []
        errors = []
        elapsed = 0.0
        valid = True
        for t in CAL_FRAMES:
            try:
                start = time.perf_counter()
                pred, _, _, _, _ = choose_and_predict(data, angles, t, method, cfg, budget, eval_idx)
                elapsed += time.perf_counter() - start
                vals.append(nrmse(pred[eval_idx], data[t, eval_idx]))
                errors.append((pred[eval_idx] - data[t, eval_idx]).ravel())
            except Exception:
                valid = False
                vals = [np.inf]
                errors = []
                break
        score = float(np.mean(vals))
        traces.append({"method": method, **asdict(cfg), "validation_nrmse": score, "seconds": elapsed, "valid": valid})
        key = (score, cfg.order, cfg.ridge, cfg.rho, cfg.eta)
        old = (best_score, best_cfg.order, best_cfg.ridge, best_cfg.rho, best_cfg.eta) if best_cfg else (np.inf, 0, 0, 0, 0)
        if key < old:
            best_score = score
            best_cfg = cfg
            best_errors = errors
    assert best_cfg is not None
    sigma = float(np.sqrt(np.mean(np.concatenate(best_errors) ** 2))) if best_errors else float("nan")
    return best_cfg, traces, sigma


def aggregate(results: list[FrameResult]) -> dict[str, Any]:
    return {
        "mean_nrmse": float(np.mean([r.nrmse for r in results])),
        "median_nrmse": float(np.median([r.nrmse for r in results])),
        "mean_correlation": float(np.mean([r.correlation for r in results])),
        "mean_log_score": float(np.mean([r.log_score for r in results if r.log_score is not None])),
        "mean_coverage90": float(np.mean([r.coverage90 for r in results if r.coverage90 is not None])),
        "seconds": float(np.sum([r.seconds for r in results])),
        "frames": len(results),
    }


def bootstrap_gain(a: np.ndarray, b: np.ndarray, n: int = 20000) -> dict[str, float]:
    # relative gain of a over b, where lower is better
    rng = np.random.default_rng(SEED + 91)
    idx = rng.integers(0, len(a), size=(n, len(a)))
    gains = np.mean((b[idx] - a[idx]) / np.maximum(b[idx], 1e-12), axis=1)
    return {"mean": float(np.mean(gains)), "lo95": float(np.quantile(gains, 0.025)), "hi95": float(np.quantile(gains, 0.975))}


def map_primary_to_extra(values: np.ndarray, primary_angles: np.ndarray, extra_angles: np.ndarray) -> np.ndarray:
    return interpolate_angles(values, primary_angles, extra_angles, order=24, ridge=1e-3)


def dense_method_frame(
    history: np.ndarray,
    primary_angles: np.ndarray,
    target: np.ndarray,
    extra_angles: np.ndarray,
    method: str,
    cfg: Config,
    budget: int,
    eval_idx: np.ndarray,
    sigma: float,
) -> FrameResult:
    # Construct a pseudo data cube with target at t=17 only for the acquisition step.
    mapped = np.stack([map_primary_to_extra(x, primary_angles, extra_angles) for x in history], axis=0)
    cube = np.concatenate([mapped, target[None]], axis=0)
    t = len(history)
    return evaluate_frame(cube, extra_angles, t, method, cfg, budget, eval_idx, sigma)


def consistency_extra1(primary0: np.ndarray, primary_angles: np.ndarray, extra1: np.ndarray, extra_angles: np.ndarray) -> dict[str, float]:
    mapped = map_primary_to_extra(primary0, primary_angles, extra_angles)
    return {"nrmse": nrmse(mapped, extra1), "correlation": corr(mapped, extra1)}


def make_plots(out: Path, summaries: dict[str, Any], efficiency_rows: list[dict[str, Any]], dense_rows: list[dict[str, Any]]) -> None:
    import matplotlib.pyplot as plt

    for res, summary in summaries.items():
        ranking = sorted(summary["methods"].items(), key=lambda kv: kv[1]["median_nrmse"])
        names = [k for k, _ in ranking]
        vals = [v["median_nrmse"] for _, v in ranking]
        fig = plt.figure(figsize=(12, 6))
        ax = fig.add_subplot(111)
        ax.bar(np.arange(len(names)), vals)
        ax.set_xticks(np.arange(len(names)), names, rotation=60, ha="right")
        ax.set_ylabel("Median sealed-angle NRMSE")
        ax.set_title(f"G2.1 router ranking — {res}")
        fig.tight_layout()
        fig.savefig(out / f"RANKING_{res}.png", dpi=160)
        plt.close(fig)
    fig = plt.figure(figsize=(11, 6))
    ax = fig.add_subplot(111)
    by = {}
    for row in efficiency_rows:
        by.setdefault((row["resolution"], row["method"]), []).append(row)
    for (res, method), rows in by.items():
        if method not in ("DIN_LENS_ROUTER", "CURRENT_IG", "RECENT_ATTENTION", "LOW_RANK_SPARSE"):
            continue
        rows = sorted(rows, key=lambda r: r["budget"])
        ax.plot([r["budget"] for r in rows], [r["mean_nrmse"] for r in rows], marker="o", label=f"{res}:{method}")
    ax.set_xlabel("Acquired angles")
    ax.set_ylabel("Mean sealed-angle NRMSE")
    ax.set_title("Measurement-efficiency curves")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out / "EFFICIENCY_CURVES.png", dpi=160)
    plt.close(fig)
    if dense_rows:
        ranking = sorted(dense_rows, key=lambda r: r["nrmse"])
        fig = plt.figure(figsize=(11, 6))
        ax = fig.add_subplot(111)
        ax.bar(np.arange(len(ranking)), [r["nrmse"] for r in ranking])
        ax.set_xticks(np.arange(len(ranking)), [r["method"] for r in ranking], rotation=60, ha="right")
        ax.set_ylabel("Dense frame-18 NRMSE")
        ax.set_title("Independent dense-frame confirmation")
        fig.tight_layout()
        fig.savefig(out / "DENSE_FRAME18_RANKING.png", dpi=160)
        plt.close(fig)


def self_test() -> None:
    rng = np.random.default_rng(1)
    angles = np.linspace(0, 360, 72, endpoint=False)
    d = 12
    data = []
    for t in range(17):
        theta = np.deg2rad(angles)
        base = np.sin(theta[:, None] * 2 + np.linspace(0, 1, d)[None])
        drift = 0.03 * t * np.cos(theta[:, None] * 3)
        data.append(base + drift + 0.001 * rng.normal(size=(len(angles), d)))
    arr = np.stack(data)
    cfg = Config(4, 0.1, 0.5, 0.5)
    eval_idx = evaluation_indices(len(angles), 0)
    for method in METHODS + (ORACLE,):
        r = evaluate_frame(arr, angles, 12, method, cfg, 12, eval_idx, 0.1)
        assert np.isfinite(r.nrmse)
        assert len(r.selected_angles) == 12
    cp = closure_profile(arr, angles, 10, cfg)
    assert cp["h12"].shape == arr[0].shape
    print("SELF_TEST_PASS")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0

    root = Path(os.environ.get("G21_WORKDIR", "g21_work")).resolve()
    data_dir = root / "data"
    results_dir = root / "results"
    visuals_dir = root / "visuals"
    for p in (data_dir, results_dir, visuals_dir):
        p.mkdir(parents=True, exist_ok=True)

    files = {
        "b4": data_dir / "GelPhantomData_b4.mat",
        "b2": data_dir / "GelPhantomData_b2.mat",
        "extra": data_dir / "GelPhantom_extra_frames.mat",
    }
    expected = {
        "b4": "3396dd69ed660d80f6eeab8db7ee39fc",
        "b2": "a72faf42bfee27a1fab50c55ef8dc7a2",
        "extra": "b0c8108893c0b9ac892700bc9689e0f3",
    }
    for k, p in files.items():
        if not p.exists():
            raise FileNotFoundError(p)
        if md5_file(p) != expected[k]:
            raise RuntimeError(f"checksum mismatch for {p.name}")

    datasets: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    audit: dict[str, Any] = {"program_id": PROGRAM_ID, "files": {}, "datasets": {}}
    for res in ("b4", "b2"):
        data, angles, meta = load_primary(files[res], f"GelPhantomData_{res}")
        datasets[res] = (data, angles)
        audit["files"][res] = {"path": files[res].name, "bytes": files[res].stat().st_size, "md5": md5_file(files[res]), "sha256": sha256_file(files[res])}
        audit["datasets"][res] = {
            "shape": list(data.shape), "angle_min": float(angles.min()), "angle_max": float(angles.max()),
            "nonfinite": int(np.size(data) - np.isfinite(data).sum()), "loader": meta,
        }
    extra1, extra_angles1, meta1 = load_extra(files["extra"], "GelPhantomFrame1_b4")
    extra18, extra_angles18, meta18 = load_extra(files["extra"], "GelPhantomFrame18_b4")
    audit["files"]["extra"] = {"path": files["extra"].name, "bytes": files["extra"].stat().st_size, "md5": md5_file(files["extra"]), "sha256": sha256_file(files["extra"])}
    audit["datasets"]["extra1_b4"] = {"shape": list(extra1.shape), "angles": len(extra_angles1), "loader": meta1}
    audit["datasets"]["extra18_b4"] = {"shape": list(extra18.shape), "angles": len(extra_angles18), "loader": meta18}
    write_json(results_dir / "DATA_AUDIT.json", audit)

    summaries: dict[str, Any] = {}
    tuning_rows: list[dict[str, Any]] = []
    frame_rows: list[dict[str, Any]] = []
    selection_receipts: dict[str, Any] = {}
    efficiency_rows: list[dict[str, Any]] = []
    configs: dict[str, dict[str, Config]] = {}
    sigmas: dict[str, dict[str, float]] = {}

    for res, (data, angles) in datasets.items():
        configs[res] = {}
        sigmas[res] = {}
        for method in METHODS:
            cfg, traces, sigma = tune_method(data, angles, method, PRIMARY_BUDGET)
            configs[res][method] = cfg
            sigmas[res][method] = sigma
            for row in traces:
                row["resolution"] = res
                tuning_rows.append(row)
        eval_idx = evaluation_indices(len(angles), 0)
        method_results: dict[str, list[FrameResult]] = {}
        for method in METHODS + (ORACLE,):
            cfg = configs[res].get(method, configs[res]["CURRENT_IG"])
            sigma = sigmas[res].get(method, sigmas[res]["CURRENT_IG"])
            rr = [evaluate_frame(data, angles, t, method, cfg, PRIMARY_BUDGET, eval_idx, sigma) for t in TEST_FRAMES]
            method_results[method] = rr
            for r in rr:
                row = asdict(r)
                row["resolution"] = res
                frame_rows.append(row)
                selection_receipts[f"{res}:{method}:{r.frame}"] = {
                    "selected_angles": r.selected_angles,
                    "lineage_hash": r.lineage_hash,
                    "source_frame": r.source_frame,
                }
        summaries[res] = {
            "configs": {m: asdict(c) for m, c in configs[res].items()},
            "sigma": sigmas[res],
            "methods": {m: aggregate(rr) for m, rr in method_results.items()},
        }
        for budget in BUDGETS:
            for method in DEPLOYABLE:
                cfg = configs[res][method]
                sigma = sigmas[res][method]
                rr = [evaluate_frame(data, angles, t, method, cfg, budget, eval_idx, sigma) for t in TEST_FRAMES]
                efficiency_rows.append({"resolution": res, "method": method, "budget": budget, **aggregate(rr)})

    # Dense external confirmation at frame 18 (b4 only).
    b4, angles4 = datasets["b4"]
    dense_eval = evaluation_indices(len(extra_angles18), 0)
    dense_budget = max(1, int(round(PRIMARY_BUDGET * len(extra_angles18) / len(angles4))))
    dense_rows: list[dict[str, Any]] = []
    for method in METHODS + (ORACLE,):
        cfg = configs["b4"].get(method, configs["b4"]["CURRENT_IG"])
        sigma = sigmas["b4"].get(method, sigmas["b4"]["CURRENT_IG"])
        r = dense_method_frame(b4, angles4, extra18, extra_angles18, method, cfg, dense_budget, dense_eval, sigma)
        dense_rows.append({**asdict(r), "resolution": "b4_dense18"})
    extra_consistency = consistency_extra1(b4[0], angles4, extra1, extra_angles1)

    # Adjudication.
    per_res: dict[str, Any] = {}
    din_positive_both = True
    for res in ("b4", "b2"):
        methods_summary = summaries[res]["methods"]
        best_name, best = min(((m, v) for m, v in methods_summary.items() if m in DEPLOYABLE and m != "DIN_LENS_ROUTER"), key=lambda kv: kv[1]["median_nrmse"])
        din = methods_summary["DIN_LENS_ROUTER"]
        gain = (best["median_nrmse"] - din["median_nrmse"]) / best["median_nrmse"]
        proper_arr = np.array([r["nrmse"] for r in frame_rows if r["resolution"] == res and r["method"] == "DIN_LENS_ROUTER"])
        best_arr = np.array([r["nrmse"] for r in frame_rows if r["resolution"] == res and r["method"] == best_name])
        reversed_med = methods_summary["DIN_ORDER_REVERSED"]["median_nrmse"]
        lineage_med = methods_summary["DIN_LINEAGE_SHUFFLED"]["median_nrmse"]
        time_med = methods_summary["DIN_SOURCE_TIME_SHUFFLED"]["median_nrmse"]
        ablation_gaps = {
            "order": (reversed_med - din["median_nrmse"]) / reversed_med,
            "lineage": (lineage_med - din["median_nrmse"]) / lineage_med,
            "source_time": (time_med - din["median_nrmse"]) / time_med,
        }
        cost_ratio = din["seconds"] / max(best["seconds"], 1e-12)
        wins = int(np.sum(proper_arr <= 0.98 * best_arr))
        local_support = gain >= 0.02 and wins >= 3 and min(ablation_gaps.values()) >= 0.01 and cost_ratio <= 3.0
        din_positive_both &= local_support
        per_res[res] = {
            "best_deployable_rival": best_name,
            "best_median_nrmse": best["median_nrmse"],
            "din_median_nrmse": din["median_nrmse"],
            "relative_gain": gain,
            "frames_won_over_2_percent": wins,
            "ablation_gaps": ablation_gaps,
            "cost_ratio": cost_ratio,
            "bootstrap_gain": bootstrap_gain(proper_arr, best_arr),
            "local_support": local_support,
        }
    dense_best_name, dense_best = min(((r["method"], r) for r in dense_rows if r["method"] in DEPLOYABLE and r["method"] != "DIN_LENS_ROUTER"), key=lambda kv: kv[1]["nrmse"])
    dense_din = next(r for r in dense_rows if r["method"] == "DIN_LENS_ROUTER")
    dense_gain = (dense_best["nrmse"] - dense_din["nrmse"]) / dense_best["nrmse"]
    dense_ablation = {
        "order": (next(r for r in dense_rows if r["method"] == "DIN_ORDER_REVERSED")["nrmse"] - dense_din["nrmse"]) / next(r for r in dense_rows if r["method"] == "DIN_ORDER_REVERSED")["nrmse"],
        "lineage": (next(r for r in dense_rows if r["method"] == "DIN_LINEAGE_SHUFFLED")["nrmse"] - dense_din["nrmse"]) / next(r for r in dense_rows if r["method"] == "DIN_LINEAGE_SHUFFLED")["nrmse"],
        "source_time": (next(r for r in dense_rows if r["method"] == "DIN_SOURCE_TIME_SHUFFLED")["nrmse"] - dense_din["nrmse"]) / next(r for r in dense_rows if r["method"] == "DIN_SOURCE_TIME_SHUFFLED")["nrmse"],
    }
    dense_support = dense_gain >= 0.02 and min(dense_ablation.values()) >= 0.01
    if din_positive_both and dense_support:
        outcome = "DIN_LENS_LOCAL_SUPPORT"
        qstate = "+0_PROTOFORM_UNREPLICATED_RESOLUTION"
    else:
        median_gains = [per_res[x]["relative_gain"] for x in ("b4", "b2")]
        if max(median_gains + [dense_gain]) <= -0.02:
            outcome = "DIN_LENS_REFUTED"
        elif all(abs(x) < 0.02 for x in median_gains + [dense_gain]):
            outcome = "DIN_LENS_BASELINE_EQUIVALENT"
        else:
            outcome = "ABSTAIN_NOT_IDENTIFIABLE"
        qstate = "0_NO_CLOSURE"
    false_closure = {
        res: bool(min(per_res[res]["ablation_gaps"].values()) > 0 and per_res[res]["relative_gain"] < 0)
        for res in ("b4", "b2")
    }
    adjudication = {
        "program_id": PROGRAM_ID,
        "outcome": outcome,
        "quaternary_state": qstate,
        "authority": "NONE",
        "promotion": "BLOCKED",
        "canonicalization": "BLOCKED",
        "per_resolution": per_res,
        "dense_confirmation": {
            "best_deployable_rival": dense_best_name,
            "best_nrmse": dense_best["nrmse"],
            "din_nrmse": dense_din["nrmse"],
            "relative_gain": dense_gain,
            "ablation_gaps": dense_ablation,
            "support": dense_support,
            "budget": dense_budget,
        },
        "false_closure_flags": false_closure,
        "extra_frame1_measurement_consistency": extra_consistency,
        "not_established": [
            "Canonical CFL TOS/DIN",
            "Intrinsic image-space reconstruction quality",
            "Full-space identifiability",
            "Non-Euclidean ontology",
            "General usefulness of active acquisition",
        ],
    }

    write_csv(results_dir / "TUNING_TRACES.csv", tuning_rows)
    write_csv(results_dir / "FRAME_RESULTS.csv", frame_rows)
    write_csv(results_dir / "EFFICIENCY_CURVES.csv", efficiency_rows)
    write_csv(results_dir / "DENSE_FRAME18_RESULTS.csv", dense_rows)
    write_json(results_dir / "SELECTION_RECEIPTS.json", selection_receipts)
    write_json(results_dir / "RESULTS.json", {"program_id": PROGRAM_ID, "summaries": summaries, "dense_results": dense_rows, "extra_frame1_consistency": extra_consistency})
    write_json(results_dir / "FINAL_ADJUDICATION.json", adjudication)
    make_plots(visuals_dir, summaries, efficiency_rows, dense_rows)

    report = [
        f"# {PROGRAM_ID}", "", f"Outcome: `{outcome}`", f"Quaternary state: `{qstate}`", "",
        "## Resolution results", "",
    ]
    for res in ("b4", "b2"):
        x = per_res[res]
        report.extend([
            f"### {res}",
            f"- Best rival: `{x['best_deployable_rival']}`",
            f"- DIN median NRMSE: {x['din_median_nrmse']:.8f}",
            f"- Relative gain: {100*x['relative_gain']:.3f}%",
            f"- Ablation gaps: {canonical_json(x['ablation_gaps'])}",
            f"- Cost ratio: {x['cost_ratio']:.3f}", "",
        ])
    report.extend([
        "## Dense frame 18", "",
        f"- Best rival: `{dense_best_name}`",
        f"- DIN relative gain: {100*dense_gain:.3f}%",
        f"- Dense support: `{dense_support}`", "",
        "## Scope", "",
        "The experiment evaluates active acquisition and sinogram prediction. It does not evaluate intrinsic image-space form or canonical DIN.",
    ])
    (results_dir / "REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")

    manifest = {
        "program_id": PROGRAM_ID,
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "seed": SEED,
        "files": {},
    }
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.name != "RUN_MANIFEST.json":
            manifest["files"][str(p.relative_to(root))] = {"bytes": p.stat().st_size, "sha256": sha256_file(p)}
    write_json(results_dir / "RUN_MANIFEST.json", manifest)
    print(json.dumps(adjudication, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
