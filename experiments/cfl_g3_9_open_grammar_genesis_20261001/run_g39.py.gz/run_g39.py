
import os, json, math, random, hashlib, itertools, time
from dataclasses import dataclass
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np

PROGRAM_ID="CFL-UEP-G3.9-OPEN-GRAMMAR-AND-META-HYPOTHESIS-GENESIS"
DOMAINS=("graph","algebra","number","mechanics")

def sha256_bytes(b): return hashlib.sha256(b).hexdigest()
def canon(o): return json.dumps(o, sort_keys=True, separators=(",",":"))

@dataclass(frozen=True)
class Cand:
    name:str
    family:str
    group:str
    cost:int
    vals:tuple

def universe(domain, seed, n=32):
    rng=np.random.default_rng(seed)
    pts=[]
    seen=set()
    while len(pts)<n:
        if domain=="graph":
            nn=int(rng.integers(3,10)); m=int(rng.integers(nn-1, min(nn*(nn-1)//2,18)+1))
            tri=int(rng.integers(0,min(8,m//3+1))); comp=int(rng.integers(1,min(4,nn)+1))
            x=(nn,m,tri,comp)
        elif domain=="algebra":
            deg=int(rng.integers(1,6)); lc=int(rng.choice([-3,-2,-1,1,2,3]))
            c0=int(rng.integers(-4,5)); disc=int(rng.integers(-9,10))
            x=(deg,lc,c0,disc)
        elif domain=="number":
            a=int(rng.integers(2,18)); b=int(rng.integers(2,18)); c=int(rng.integers(0,11)); d=int(rng.integers(0,8))
            x=(a,b,c,d)
        else:
            m=int(rng.integers(1,7)); k=int(rng.integers(1,7)); q=int(rng.integers(-4,5)); v=int(rng.integers(-4,5))
            x=(m,k,q,v)
        if x not in seen:
            seen.add(x); pts.append(x)
    return tuple(pts)

def vals_of(U, fn):
    return tuple(int(fn(x)) for x in U)

def candidates(domain,U):
    C=[]
    # initial DSL: constants and single-channel affine transforms
    for b in range(-2,3):
        C.append(Cand(f"CONST_{b}","CONST","INITIAL",1, tuple([b]*len(U))))
    for i in range(4):
        for a in (-2,-1,1,2):
            for b in (-2,-1,0,1,2):
                C.append(Cand(f"AFF_{i}_{a}_{b}","AFF","INITIAL",1,vals_of(U,lambda x,i=i,a=a,b=b:a*x[i]+b)))
    # composition births: absent from initial DSL
    for i,j in itertools.combinations(range(4),2):
        for op in ("ADD","SUB","MUL","ABSDIFF"):
            for b in (-1,0,1):
                if op=="ADD": fn=lambda x,i=i,j=j,b=b:x[i]+x[j]+b
                elif op=="SUB": fn=lambda x,i=i,j=j,b=b:x[i]-x[j]+b
                elif op=="MUL": fn=lambda x,i=i,j=j,b=b:x[i]*x[j]+b
                else: fn=lambda x,i=i,j=j,b=b:abs(x[i]-x[j])+b
                C.append(Cand(f"{op}_{i}_{j}_{b}",op,"COMPOSITION",2,vals_of(U,fn)))
    # domain primitive births (new derived primitives / rewrites)
    prim=[]
    if domain=="graph":
        prim=[
          ("CYCLE",lambda x:x[1]-x[0]+x[3]),
          ("EDGEDEF",lambda x:x[0]*(x[0]-1)-2*x[1]),
          ("TRIPAR",lambda x:(x[2]+x[1])%2),
          ("COMPWEIGHT",lambda x:x[3]*x[0]-x[1]),
        ]
    elif domain=="algebra":
        prim=[
          ("SIGNDISC",lambda x:(x[3]>0)-(x[3]<0)),
          ("DISCDEG",lambda x:x[3]+x[0]),
          ("LCC0",lambda x:x[1]*x[2]),
          ("DEGPAR",lambda x:(x[0]+x[2])%2),
        ]
    elif domain=="number":
        prim=[
          ("GCDAB",lambda x:math.gcd(x[0],x[1])),
          ("LCMAB",lambda x:abs(x[0]*x[1])//math.gcd(x[0],x[1])),
          ("PARITYSUM",lambda x:(x[0]+x[1]+x[2])%2),
          ("MOD3MIX",lambda x:(x[0]*x[1]+x[2])%3),
        ]
    else:
        prim=[
          ("ENERGY2",lambda x:x[0]*x[3]*x[3]+x[1]*x[2]*x[2]),
          ("MOMENTUM",lambda x:x[0]*x[3]),
          ("FORCE",lambda x:-x[1]*x[2]),
          ("OSCINV",lambda x:x[1]*x[2]+x[0]*x[3]),
        ]
    for pname,pfn in prim:
        base=vals_of(U,pfn)
        for a in (-1,1,2):
            for b in (-1,0,1):
                C.append(Cand(f"{pname}_{a}_{b}",pname,"PRIMITIVE",3,tuple(a*v+b for v in base)))
    # gauge aliases: syntactically distinct, extensionally equal
    for i in range(4):
        v=vals_of(U,lambda x,i=i:x[i])
        C.append(Cand(f"GAUGE_ID_A_{i}","GAUGE_ID","GAUGE",2,v))
        C.append(Cand(f"GAUGE_ID_B_{i}","GAUGE_ID","GAUGE",3,v))
    # canonicalize exact duplicate names only, retain semantic aliases
    return C

def misspec_vals(domain,U,variant):
    # deliberately outside the bounded initial+meta grammar: cubic cross interactions
    if domain=="graph":
        return vals_of(U,lambda x: x[0]*x[1] + x[2]**3 - 2*x[3] + 7*variant)
    if domain=="algebra":
        return vals_of(U,lambda x: x[3]**2 + x[1]*x[2]*x[0] + 5*variant)
    if domain=="number":
        return vals_of(U,lambda x: x[0]**2 + x[1]**3 - x[2]*x[3] + 11*variant)
    return vals_of(U,lambda x: x[0]*x[3]**3 + x[1]*x[2]**2 + 13*variant)

def taskset(split):
    seed=20261011 if split=="dev" else 20261021
    counts={"KNOWN_GRAMMAR_CONTROL":8 if split=="dev" else 10,
            "COMPOSITION_BIRTH":10 if split=="dev" else 12,
            "PRIMITIVE_BIRTH":10 if split=="dev" else 12,
            "META_GRAMMAR_MISSPECIFICATION":6 if split=="dev" else 8,
            "GAUGE_NULL":6 if split=="dev" else 6}
    tasks=[]
    tid=0
    for di,dom in enumerate(DOMAINS):
        U=universe(dom,seed+1000*di,32)
        C=candidates(dom,U)
        bygroup=defaultdict(list)
        for c in C: bygroup[c.group].append(c)
        # deterministic recurring family schedule encourages prospective library transfer
        comp_fams=["ADD","SUB","MUL","ABSDIFF"]
        prim_fams=sorted({c.family for c in C if c.group=="PRIMITIVE"})
        for lane,n in counts.items():
            for k in range(n):
                tid+=1
                rng=random.Random(seed+di*10000+tid*97)
                if lane=="KNOWN_GRAMMAR_CONTROL":
                    pool=[c for c in C if c.group=="INITIAL" and c.family=="AFF"]
                    truth=pool[(3*k+di)%len(pool)]
                    y=truth.vals; tfam=truth.family; tname=truth.name
                elif lane=="COMPOSITION_BIRTH":
                    fam=comp_fams[k%len(comp_fams)]
                    pool=[c for c in C if c.family==fam]
                    truth=pool[(k*5+di)%len(pool)]
                    y=truth.vals; tfam=fam; tname=truth.name
                elif lane=="PRIMITIVE_BIRTH":
                    fam=prim_fams[k%len(prim_fams)]
                    pool=[c for c in C if c.family==fam]
                    truth=pool[(k*3+di)%len(pool)]
                    y=truth.vals; tfam=fam; tname=truth.name
                elif lane=="GAUGE_NULL":
                    i=(k+di)%4
                    pool=[c for c in C if c.family=="GAUGE_ID" and c.name.endswith(f"_{i}")]
                    truth=pool[0]; y=truth.vals; tfam="GAUGE_ID"; tname=truth.name
                else:
                    y=misspec_vals(dom,U,(k+di)%3-1); tfam="OUTSIDE_META_GRAMMAR"; tname="MISSPEC"
                    if any(c.vals==y for c in C):
                        raise RuntimeError(f"misspecification alias leaked into authorized grammar: {dom} {k}")
                # fixed observations: choose diverse points
                obs=tuple(sorted(rng.sample(range(len(U)),2)))
                query_pool=tuple(i for i in range(len(U)) if i not in obs)
                tasks.append({"id":f"{split}_{dom}_{lane}_{k:03d}","domain":dom,"lane":lane,
                              "U":U,"y":y,"truth_family":tfam,"truth_name":tname,
                              "obs0":obs,"query_pool":query_pool,"candidates":C})
    return tasks

def compat(c,obs,y): return all(c.vals[i]==y[i] for i in obs)
def mismatch(c,obs,y): return sum(c.vals[i]!=y[i] for i in obs)
def verifier(c,y): return c.vals==y

def task_features(t):
    obs=t["obs0"]; U=t["U"]; y=t["y"]
    X=np.asarray([U[i] for i in obs],dtype=float); yy=np.asarray([y[i] for i in obs],dtype=float)
    feats=[DOMAINS.index(t["domain"]),yy.mean(),yy.std(),yy.min(),yy.max()]
    feats += list(X.mean(0))+list(X.std(0))
    # best initial residual signature
    ini=[c for c in t["candidates"] if c.group=="INITIAL"]
    mm=min(mismatch(c,obs,y) for c in ini)
    feats += [mm]
    return np.asarray(feats,float)

def train_neural(dev):
    from sklearn.ensemble import RandomForestClassifier
    X=[];Y=[]
    for t in dev:
        if t["lane"] in ("COMPOSITION_BIRTH","PRIMITIVE_BIRTH","KNOWN_GRAMMAR_CONTROL"):
            X.append(task_features(t)); Y.append(t["truth_family"])
    clf=RandomForestClassifier(n_estimators=160,max_depth=9,random_state=937,class_weight="balanced_subsample")
    clf.fit(np.vstack(X),np.asarray(Y))
    return clf

def family_score(t,fam,obs):
    pool=[c for c in t["candidates"] if c.family==fam]
    if not pool:return 10**9
    return min(mismatch(c,obs,t["y"]) for c in pool)

def choose_query(t,cands,obs):
    avail=[i for i in t["query_pool"] if i not in obs]
    if not avail:return None
    live=[c for c in cands if compat(c,obs,t["y"])]
    if len(live)<2:
        live=cands[:min(30,len(cands))]
    best=None
    for i in avail:
        cnt=Counter(c.vals[i] for c in live)
        n=sum(cnt.values())
        ent=0.0
        for v in cnt.values():
            p=v/n; ent-=p*math.log2(p)
        key=(ent,-i)
        if best is None or key>best[0]: best=(key,i)
    return best[1] if best else avail[0]

def ordered_candidates(t,method,obs,library,clf,rng):
    C=t["candidates"]
    ini=[c for c in C if c.group=="INITIAL"]
    meta=[c for c in C if c.group!="INITIAL"]
    fams=sorted({c.family for c in meta})
    if method=="ACTIVE_VERSION_SPACE_WITH_FIXED_GRAMMAR":
        return sorted(ini,key=lambda c:(mismatch(c,obs,t["y"]),c.cost,c.name))
    if method=="BAYESIAN_GRAMMAR_INDUCTION":
        return sorted(C,key=lambda c:(mismatch(c,obs,t["y"]), c.cost+0.25*(c.family not in library), c.name))
    if method=="MDL_LIBRARY_LEARNING":
        return sorted(C,key=lambda c:(mismatch(c,obs,t["y"]), c.cost-(1.25 if c.family in library else 0), len(c.name),c.name))
    if method=="EGRAPH_REWRITE_SYNTHESIS":
        # semantic canonical reps first; aliases de-prioritized
        seen=set(); arr=[]
        for c in sorted(C,key=lambda c:(c.cost,mismatch(c,obs,t["y"]),c.name)):
            h=hash(c.vals)
            if h not in seen: seen.add(h); arr.append(c)
        return arr
    if method=="DREAMCODER_STYLE_LIBRARY_LEARNING":
        return sorted(C,key=lambda c:(0 if c.family in library else 1,mismatch(c,obs,t["y"]),c.cost,c.name))
    if method=="GENETIC_PROGRAMMING_WITH_VERIFIER":
        arr=C.copy(); rng.shuffle(arr)
        return sorted(arr[:80],key=lambda c:(mismatch(c,obs,t["y"]),rng.random()))
    if method=="NEURAL_PROGRAM_SYNTHESIS_AMORTIZED":
        pred=clf.predict(task_features(t).reshape(1,-1))[0]
        return sorted(C,key=lambda c:(0 if c.family==pred else 1,mismatch(c,obs,t["y"]),c.cost,c.name))
    if method=="TOS_NO_META_GRAMMAR_REENTRY":
        # freeze top family from initial residual geometry
        scored=sorted((family_score(t,f,obs),f) for f in fams)
        top=scored[0][1] if scored else None
        arr=ini+[c for c in meta if c.family==top]
        return sorted(arr,key=lambda c:(mismatch(c,obs,t["y"]),c.cost,c.name))
    if method=="TOS_FULL_OPEN_GRAMMAR_DIN":
        # birth two best families from current residual geometry; verified library has priority
        scored=sorted((family_score(t,f,obs)-(0.35 if f in library else 0),f) for f in fams)
        tops=[f for _,f in scored[:2]]
        arr=ini+[c for c in meta if c.family in tops or c.family in library]
        return sorted(arr,key=lambda c:(mismatch(c,obs,t["y"]),0 if c.family in library else 1,c.cost,c.name))
    if method=="EXPANDED_GRAMMAR_ORACLE_CEILING":
        return sorted(C,key=lambda c:(0 if verifier(c,t["y"]) else 1,c.cost,c.name))
    raise ValueError(method)

METHODS=[
"EXPANDED_GRAMMAR_ORACLE_CEILING",
"ACTIVE_VERSION_SPACE_WITH_FIXED_GRAMMAR",
"BAYESIAN_GRAMMAR_INDUCTION",
"MDL_LIBRARY_LEARNING",
"GENETIC_PROGRAMMING_WITH_VERIFIER",
"EGRAPH_REWRITE_SYNTHESIS",
"DREAMCODER_STYLE_LIBRARY_LEARNING",
"NEURAL_PROGRAM_SYNTHESIS_AMORTIZED",
"TOS_NO_META_GRAMMAR_REENTRY",
"TOS_FULL_OPEN_GRAMMAR_DIN",
]

def run_method(t,method,library,clf,seed):
    rng=random.Random(seed)
    obs=list(t["obs0"])
    verifier_calls=0; queries=0; candidate_checks=0
    generated_fams=set()
    generated_names=set()
    found=None
    max_rounds=3 if method=="TOS_FULL_OPEN_GRAMMAR_DIN" else 1
    candidate_budget=45 if method!="EXPANDED_GRAMMAR_ORACLE_CEILING" else 10**9
    for rnd in range(max_rounds):
        # Full meta-grammar re-entry is allowed to ask one family-discriminating query
        # before committing to births; the no-reentry ablation freezes from obs0.
        if method=="TOS_FULL_OPEN_GRAMMAR_DIN":
            broad=t["candidates"] if rnd==0 else ordered_candidates(t,method,tuple(obs),library,clf,rng)
            q=choose_query(t,broad,obs)
            if q is not None:
                obs.append(q); queries+=1
        arr=ordered_candidates(t,method,tuple(obs),library,clf,rng)
        for c in arr:
            if verifier_calls>=candidate_budget: break
            candidate_checks+=1
            generated_fams.add(c.family); generated_names.add(c.name)
            if not compat(c,obs,t["y"]): continue
            verifier_calls+=1
            if verifier(c,t["y"]):
                found=c; break
        if found: break
        if method=="TOS_FULL_OPEN_GRAMMAR_DIN" and rnd<max_rounds-1:
            continue
        break

    lane=t["lane"]
    if found is not None:
        if lane=="GAUGE_NULL":
            state="GAUGE_ABSTAIN"
        else:
            state="AUTHORIZED_CLOSURE"
    else:
        if lane=="META_GRAMMAR_MISSPECIFICATION":
            state="MODEL_MISMATCH"
        else:
            state="ABSTAIN"

    truth_recall = (t["truth_name"] in generated_names) if t["truth_name"]!="MISSPEC" else False
    fam_recall = (t["truth_family"] in generated_fams) if t["truth_family"]!="OUTSIDE_META_GRAMMAR" else False
    correct_state = ((lane=="META_GRAMMAR_MISSPECIFICATION" and state=="MODEL_MISMATCH") or
                     (lane=="GAUGE_NULL" and state=="GAUGE_ABSTAIN") or
                     (lane not in ("META_GRAMMAR_MISSPECIFICATION","GAUGE_NULL") and state=="AUTHORIZED_CLOSURE"))
    false_promotion = (state=="AUTHORIZED_CLOSURE" and lane in ("META_GRAMMAR_MISSPECIFICATION","GAUGE_NULL"))
    return {"task_id":t["id"],"domain":t["domain"],"lane":lane,"method":method,
            "state":state,"correct_state":bool(correct_state),"false_promotion":bool(false_promotion),
            "truth_recall":bool(truth_recall),"family_recall":bool(fam_recall),
            "verifier_calls":verifier_calls,"queries":queries,"candidate_checks":candidate_checks,
            "found_name":found.name if found else None,"found_family":found.family if found else None}

def evaluate(split):
    dev=taskset("dev")
    tasks=taskset(split)
    clf=train_neural(dev)
    rows=[]
    # library is per method and domain; task order is prospective
    libs={m:{d:set() for d in DOMAINS} for m in METHODS}
    first_cost={m:{} for m in METHODS}
    transfer=[]
    for ti,t in enumerate(tasks):
        for mi,m in enumerate(METHODS):
            lib=libs[m][t["domain"]]
            r=run_method(t,m,lib,clf,seed=99173+ti*31+mi*7)
            rows.append(r)
            if r["state"] in ("AUTHORIZED_CLOSURE","GAUGE_ABSTAIN") and r["found_family"]:
                fam=r["found_family"]
                key=(t["domain"],fam)
                if key not in first_cost[m]:
                    first_cost[m][key]=r["candidate_checks"]
                else:
                    transfer.append({"method":m,"domain":t["domain"],"family":fam,
                                     "first_cost":first_cost[m][key],"later_cost":r["candidate_checks"],
                                     "gain":first_cost[m][key]-r["candidate_checks"]})
                if m in ("MDL_LIBRARY_LEARNING","DREAMCODER_STYLE_LIBRARY_LEARNING","TOS_FULL_OPEN_GRAMMAR_DIN"):
                    lib.add(fam)
    return tasks,rows,transfer

def summarize(tasks,rows,transfer):
    out={}
    for m in METHODS:
        rs=[r for r in rows if r["method"]==m]
        construct=[r for r in rs if r["lane"] not in ("META_GRAMMAR_MISSPECIFICATION","GAUGE_NULL")]
        novel=[r for r in rs if r["lane"] in ("COMPOSITION_BIRTH","PRIMITIVE_BIRTH")]
        miss=[r for r in rs if r["lane"]=="META_GRAMMAR_MISSPECIFICATION"]
        gauge=[r for r in rs if r["lane"]=="GAUGE_NULL"]
        tr=[x for x in transfer if x["method"]==m]
        out[m]={
          "authority_accuracy":sum(r["correct_state"] for r in rs)/len(rs),
          "construct_closure":sum(r["state"]=="AUTHORIZED_CLOSURE" for r in construct)/len(construct),
          "novel_truth_recall":sum(r["truth_recall"] for r in novel)/len(novel),
          "novel_family_recall":sum(r["family_recall"] for r in novel)/len(novel),
          "false_promotion":sum(r["false_promotion"] for r in rs)/len(rs),
          "misspec_detection":sum(r["state"]=="MODEL_MISMATCH" for r in miss)/len(miss),
          "gauge_abstention":sum(r["state"]=="GAUGE_ABSTAIN" for r in gauge)/len(gauge),
          "mean_verifier_calls":float(np.mean([r["verifier_calls"] for r in rs])),
          "mean_queries":float(np.mean([r["queries"] for r in rs])),
          "mean_candidate_checks":float(np.mean([r["candidate_checks"] for r in rs])),
          "mean_transfer_gain":float(np.mean([x["gain"] for x in tr])) if tr else 0.0,
          "transfer_n":len(tr)
        }
    return out

def bootstrap_delta(rows,ma,mb,metric_filter,metric_fn,B=4000,seed=44):
    ra={r["task_id"]:r for r in rows if r["method"]==ma and metric_filter(r)}
    rb={r["task_id"]:r for r in rows if r["method"]==mb and metric_filter(r)}
    ids=sorted(set(ra)&set(rb))
    dif=np.array([metric_fn(ra[i])-metric_fn(rb[i]) for i in ids],float)
    rng=np.random.default_rng(seed)
    sims=np.empty(B)
    for b in range(B):
        sims[b]=rng.choice(dif,size=len(dif),replace=True).mean()
    return float(dif.mean()), [float(np.quantile(sims,.025)),float(np.quantile(sims,.975))],len(ids)

def main():
    split=os.environ.get("G39_SPLIT","private")
    wd=Path(os.environ.get("G39_WORKDIR","g39_work"))
    (wd/"results").mkdir(parents=True,exist_ok=True); (wd/"evidence").mkdir(parents=True,exist_ok=True)
    t0=time.time()
    tasks,rows,transfer=evaluate(split)
    summary=summarize(tasks,rows,transfer)
    d,ci,n=bootstrap_delta(rows,"TOS_FULL_OPEN_GRAMMAR_DIN","TOS_NO_META_GRAMMAR_REENTRY",
      lambda r:r["lane"] in ("COMPOSITION_BIRTH","PRIMITIVE_BIRTH"),lambda r:1.0 if r["truth_recall"] else 0.0)
    deploy=[m for m in METHODS if m!="EXPANDED_GRAMMAR_ORACLE_CEILING"]
    best=max(deploy,key=lambda m:(summary[m]["novel_truth_recall"],summary[m]["authority_accuracy"],-summary[m]["mean_verifier_calls"]))
    db,cib,nb=bootstrap_delta(rows,"TOS_FULL_OPEN_GRAMMAR_DIN",best,
      lambda r:r["lane"] in ("COMPOSITION_BIRTH","PRIMITIVE_BIRTH"),lambda r:1.0 if r["truth_recall"] else 0.0)
    adjud={"program_id":PROGRAM_ID,"split":split,"tasks":len(tasks),"rows":len(rows),
           "summary":summary,"din_vs_no_reentry_novel_truth_recall":{"delta":d,"ci95":ci,"n":n},
           "best_deployable":best,"tos_vs_best_novel_truth_recall":{"delta":db,"ci95":cib,"n":nb},
           "outcome":"OPEN_GRAMMAR_GENESIS_DEMONSTRATED_GLOBAL_SUPERIORITY_NOT_SUPPORTED" if summary["TOS_FULL_OPEN_GRAMMAR_DIN"]["novel_truth_recall"]>0 else "FAIL",
           "authority":"NONE","promotion":"BLOCKED","canonicalization":"BLOCKED",
           "elapsed_s":time.time()-t0}
    # truth manifest contains hashes only, not hidden program outputs
    manifest=[]
    for t in tasks:
        manifest.append({"task_id":t["id"],"domain":t["domain"],"lane":t["lane"],
                         "truth_family":t["truth_family"],"truth_name":t["truth_name"],
                         "universe_sha256":sha256_bytes(canon(t["U"]).encode()),
                         "truth_sha256":sha256_bytes(canon(t["y"]).encode())})
    for path,obj in [(wd/"results/SUMMARY.json",summary),(wd/"results/FINAL_ADJUDICATION.json",adjud),
                     (wd/"results/TRANSFER.json",transfer),(wd/"evidence/TRUTH_MANIFEST.json",manifest)]:
        path.write_text(json.dumps(obj,indent=2,sort_keys=True))
    with (wd/"results/METHOD_RESULTS.jsonl").open("w") as f:
        for r in rows:f.write(canon(r)+"\n")
    print(json.dumps(adjud,indent=2,sort_keys=True))

if __name__=="__main__":
    main()
