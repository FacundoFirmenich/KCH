#!/usr/bin/env python3
import runpy, json, pathlib, collections
import numpy as np
m=runpy.run_path('/mnt/data/run_g35.py',run_name='g35lib')
tasks=m['generate_tasks'](8)
rows=[]
for t in tasks:
    if t.lane!='COMPOSITION_OOD' or t.regime=='ANTI': continue
    sp=m['SPACES'][t.domain]
    named_cids=tuple(sorted({sp.raw_to_class[r] for r,x in sp.raw.items() if x.lane=='NAMED'}))
    named_pre=m['filter_classes'](sp,named_cids,t.demos)
    truth_in_named=t.truth_class in named_cids
    truth_compatible_named=t.truth_class in named_pre
    named_target_vals=m['target_outputs'](sp,named_pre,t.target) if named_pre else set()
    named_target_exact=(len(named_target_vals)==1 and m['model_apply'](sp.raw[t.truth_raw],t.target,sp.p) in named_target_vals)
    # best named-only family-minimax query if the catalog has any compatible classes
    if named_pre and t.query_pool:
        proxy=m['Task'](t.task_id,t.domain,'NAMED_ONLY',t.regime,t.truth_raw,t.truth_class,t.demos,t.target,t.query_pool,named_pre)
        q=m['q_family_minimax'](proxy,sp)
        post=m['observe_query'](proxy,sp,q)
        post_target=m['target_outputs'](sp,post,t.target) if post else set()
        named_post_exact=(len(post_target)==1 and m['model_apply'](sp.raw[t.truth_raw],t.target,sp.p) in post_target)
        fam_state=m['claim_state'](sp,post,tuple(x for x in t.query_pool if x!=q),'family')
    else:
        q=None;post=tuple();named_post_exact=False;fam_state='MODEL_MISMATCH_CATALOG_INCOMPLETE'
    full_pre=t.pre_classes
    full_target=m['target_outputs'](sp,full_pre,t.target) if full_pre else set()
    full_target_exact=(len(full_target)==1 and m['model_apply'](sp.raw[t.truth_raw],t.target,sp.p) in full_target)
    rows.append({'task_id':t.task_id,'domain':t.domain,'regime':t.regime,
                 'truth_mapping_class_in_named_catalog':truth_in_named,
                 'named_pre_classes':len(named_pre),'named_target_exact_pre':named_target_exact,
                 'named_target_exact_post_query':named_post_exact,'named_family_state_post':fam_state,
                 'composition_closure_pre_classes':len(full_pre),'composition_closure_target_exact_pre':full_target_exact,
                 'composition_closure_contains_truth_class':t.truth_class in full_pre})
summary={
 'status':'HARD_COMPOSITION_EXTENSION_AUDIT',
 'tasks':len(rows),
 'truth_mapping_absent_from_named_catalog':sum(not r['truth_mapping_class_in_named_catalog'] for r in rows),
 'named_catalog_empty_after_demos':sum(r['named_pre_classes']==0 for r in rows),
 'named_target_exact_pre_rate':float(np.mean([r['named_target_exact_pre'] for r in rows])),
 'named_target_exact_post_rate':float(np.mean([r['named_target_exact_post_query'] for r in rows])),
 'composition_closure_contains_truth_rate':float(np.mean([r['composition_closure_contains_truth_class'] for r in rows])),
 'composition_closure_target_exact_pre_rate':float(np.mean([r['composition_closure_target_exact_pre'] for r in rows])),
 'by_domain':{}
}
for d in m['DOMAINS']:
 z=[r for r in rows if r['domain']==d]
 summary['by_domain'][d]={
   'n':len(z),
   'truth_absent_named':sum(not r['truth_mapping_class_in_named_catalog'] for r in z),
   'named_post_exact_rate':float(np.mean([r['named_target_exact_post_query'] for r in z])),
   'composition_truth_retained_rate':float(np.mean([r['composition_closure_contains_truth_class'] for r in z]))
 }
out=pathlib.Path('/mnt/data/CFL_G3_5_ACTIVE_TOPOLOGY_RUN/audit');out.mkdir(parents=True,exist_ok=True)
(out/'COMPOSITION_HARD_EXTENSION.json').write_text(json.dumps({'summary':summary,'tasks':rows},indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
