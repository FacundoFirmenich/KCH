#!/usr/bin/env python3
from __future__ import annotations
import dataclasses, hashlib, itertools, json, math, os, random, statistics
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import numpy as np

PROGRAM_ID='CFL-UEP-G3.5-ACTIVE-TOPOLOGY-DISAMBIGUATION'
VERSION='0.1.0'
SEED=350928
DOMAINS={'graph':5,'algebra':7,'number':11,'mechanics':13}
NAMED_CHARTS=[('ID',(0,0,0)),('L1',(1,0,0)),('L2',(2,0,0)),('Q1',(0,1,0)),('Q2',(0,2,0)),('C1',(0,0,1)),('C2',(0,0,2))]
# Hard-extension lane: these charts are NOT named primitives. They are synthesized from the
# closure of primitive programs. Precompilation below is only a finite exact optimization of
# the program grammar, not a family label available to the named-catalog baseline.
PRIMITIVE_PROGRAMS=[('L1',(1,0,0)),('Q1',(0,1,0)),('C1',(0,0,1))]
COMPOSED_CHARTS=[]
for (n1,c1),(n2,c2) in itertools.combinations(PRIMITIVE_PROGRAMS,2):
    COMPOSED_CHARTS.append((f'{n1}∘{n2}',tuple(a+b for a,b in zip(c1,c2))))
ALL_CHARTS=NAMED_CHARTS+COMPOSED_CHARTS
MATRICES=[((1,0),(0,1)),((1,1),(0,1)),((1,0),(1,1)),((0,1),(1,0)),((1,1),(1,2)),((2,1),(1,1))]
SHIFTS=[(0,0),(1,0),(0,1),(1,1)]
REGIMES=('PRED_SAFE_MODEL_AMBIG','PRED_AND_MODEL_AMBIG','MODEL_IDENTIFIED','JURISDICTION_NONIDENT')
ALL_REGIMES=REGIMES+('ANTI',)


def canon(x):
    if dataclasses.is_dataclass(x): return canon(asdict(x))
    if isinstance(x,dict): return {str(k):canon(x[k]) for k in sorted(x,key=str)}
    if isinstance(x,(list,tuple,set)): return [canon(v) for v in x]
    if isinstance(x,np.generic): return x.item()
    if isinstance(x,float): return None if not math.isfinite(x) else float(x)
    return x

def cjson(x):return json.dumps(canon(x),sort_keys=True,separators=(',',':'))
def h(x):return hashlib.sha256(cjson(x).encode()).hexdigest()
def write_json(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(canon(x),indent=2,sort_keys=True)+'\n')
def write_jsonl(p,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w') as f:
        for r in rows:f.write(cjson(r)+'\n')


def chart_apply(coeff,x,p):
    a1,a2,a3=coeff;u,v=x
    return (u%p,(v+a1*u+a2*u*u+a3*u*u*u)%p)
def chart_inv(coeff,w,p):
    a1,a2,a3=coeff;u,v=w
    return (u%p,(v-a1*u-a2*u*u-a3*u*u*u)%p)
def op_apply(A,b,x,p):
    return ((A[0][0]*x[0]+A[0][1]*x[1]+b[0])%p,(A[1][0]*x[0]+A[1][1]*x[1]+b[1])%p)
def model_apply(raw,xobs,p):
    z=chart_inv(raw.chart_coeff,xobs,p);y=op_apply(raw.A,raw.b,z,p);return chart_apply(raw.chart_coeff,y,p)

def det(A,p):return (A[0][0]*A[1][1]-A[0][1]*A[1][0])%p

def family_label(name):
    if name=='ID':return 'IDENTITY'
    if name.startswith('L') and len(name)==2:return 'LINEAR'
    if name.startswith('Q') and len(name)==2:return 'QUADRATIC'
    if name.startswith('C') and len(name)==2:return 'CUBIC'
    return 'COMPOSED'

@dataclass(frozen=True)
class RawModel:
    rid:str; chart_name:str; chart_coeff:tuple[int,int,int]; family:str; lane:str; A:tuple[tuple[int,int],tuple[int,int]]; b:tuple[int,int]; complexity:int

@dataclass
class ModelClass:
    cid:str; signature:tuple[tuple[int,int],...]; raw_ids:tuple[str,...]; families:tuple[str,...]; operators:tuple[str,...]; complexities:tuple[int,...]

@dataclass
class DomainSpace:
    domain:str;p:int;inputs:tuple[tuple[int,int],...];raw:dict[str,RawModel];classes:dict[str,ModelClass];raw_to_class:dict[str,str]

@dataclass
class Task:
    task_id:str;domain:str;lane:str;regime:str;truth_raw:str;truth_class:str;demos:tuple[tuple[tuple[int,int],tuple[int,int]],...];target:tuple[int,int];query_pool:tuple[tuple[int,int],...];pre_classes:tuple[str,...]


def build_space(domain,p):
    inputs=tuple((i,j) for i in range(p) for j in range(p));raw={}
    for cname,coeff0 in ALL_CHARTS:
        coeff=tuple(v%p for v in coeff0);lane='COMPOSITION_OOD' if '∘' in cname else 'NAMED'
        fam=family_label(cname)
        for A0 in MATRICES:
            A=tuple(tuple(v%p for v in row) for row in A0)
            if det(A,p)==0:continue
            for b0 in SHIFTS:
                b=tuple(v%p for v in b0)
                rid=h((domain,cname,coeff,A,b))[:16]
                complexity=sum(v!=0 for v in coeff)+sum(A[i][j]!=(1 if i==j else 0) for i in range(2) for j in range(2))+sum(v!=0 for v in b)
                raw[rid]=RawModel(rid,cname,coeff,fam,lane,A,b,complexity)
    siggroups={}
    for rid,m in raw.items():
        sig=tuple(model_apply(m,x,p) for x in inputs);siggroups.setdefault(sig,[]).append(rid)
    classes={};raw_to_class={}
    for sig,rids in siggroups.items():
        cid=h((domain,sig))[:16];fams=tuple(sorted({raw[r].family for r in rids}));ops=tuple(sorted({cjson((raw[r].A,raw[r].b)) for r in rids}));comps=tuple(sorted(raw[r].complexity for r in rids))
        classes[cid]=ModelClass(cid,sig,tuple(sorted(rids)),fams,ops,comps)
        for r in rids:raw_to_class[r]=cid
    return DomainSpace(domain,p,inputs,raw,classes,raw_to_class)

SPACES={d:build_space(d,p) for d,p in DOMAINS.items()}


def out_at(space,cid,x):
    idx=space.inputs.index(x);return space.classes[cid].signature[idx]
def filter_classes(space,cids,demos):
    return tuple(sorted(cid for cid in cids if all(out_at(space,cid,x)==y for x,y in demos)))
def target_outputs(space,cids,x):return {out_at(space,cid,x) for cid in cids}
def family_set(space,cids):return {f for cid in cids for f in space.classes[cid].families}
def operator_set(space,cids):return {o for cid in cids for o in space.classes[cid].operators}

def partition(space,cids,q):
    d={}
    for cid in cids:d.setdefault(out_at(space,cid,q),[]).append(cid)
    return {y:tuple(sorted(v)) for y,v in d.items()}

def agreement_inputs(space,cids,exclude):
    return [x for x in space.inputs if x not in exclude and len(target_outputs(space,cids,x))==1]
def discrim_inputs(space,cids,exclude):
    return [x for x in space.inputs if x not in exclude and len(target_outputs(space,cids,x))>1]


def query_can_reduce(space,cids,qpool):
    return any(len(partition(space,cids,q))>1 for q in qpool)

def claim_state(space,cids,qpool,claim):
    if not cids:return '-1'
    if claim=='mapping': vals=set(cids)
    elif claim=='family': vals=family_set(space,cids)
    elif claim=='operator': vals=operator_set(space,cids)
    else: return '0'
    if len(vals)==1:return '1'
    # +0 only if at least one future admissible observation can reduce the relevant claim fiber.
    for q in qpool:
        parts=partition(space,cids,q)
        for cell in parts.values():
            vv=set(cell) if claim=='mapping' else (family_set(space,cell) if claim=='family' else operator_set(space,cell))
            if len(vv)<len(vals):return '+0'
    return '0'


def make_task(domain,lane,regime,seed,max_tries=5000):
    sp=SPACES[domain];rng=random.Random(seed)
    raws=[r for r,m in sp.raw.items() if m.lane==lane]
    allc=tuple(sorted(sp.classes))
    for _ in range(max_tries):
        tr=rng.choice(raws);tc=sp.raw_to_class[tr]
        # choose demo count by regime
        k=2 if regime!='MODEL_IDENTIFIED' else rng.choice([3,4,5])
        demos_x=rng.sample(list(sp.inputs),k)
        truth=sp.raw[tr];demos=tuple((x,model_apply(truth,x,sp.p)) for x in demos_x)
        fib=filter_classes(sp,allc,demos)
        if tc not in fib:continue
        remain=[x for x in sp.inputs if x not in demos_x]
        rng.shuffle(remain)
        # choose target before q pool
        found=False
        for target in remain[:min(30,len(remain))]:
            outs=target_outputs(sp,fib,target)
            if regime=='MODEL_IDENTIFIED' and len(fib)!=1:continue
            if regime=='PRED_SAFE_MODEL_AMBIG' and not (len(fib)>1 and len(outs)==1):continue
            if regime in ('PRED_AND_MODEL_AMBIG','JURISDICTION_NONIDENT') and not (len(fib)>1 and len(outs)>1):continue
            exclude=set(demos_x+[target])
            if regime=='JURISDICTION_NONIDENT':
                agree=agreement_inputs(sp,fib,exclude)
                if len(agree)<6:continue
                qpool=tuple(rng.sample(agree,6))
                if query_can_reduce(sp,fib,qpool):continue
            elif regime=='MODEL_IDENTIFIED':
                qpool=tuple(rng.sample([x for x in sp.inputs if x not in exclude],min(6,len(sp.inputs)-len(exclude))))
            else:
                disc=discrim_inputs(sp,fib,exclude)
                if not disc:continue
                others=[x for x in sp.inputs if x not in exclude and x not in disc]
                q=[rng.choice(disc)]
                rest=[x for x in sp.inputs if x not in exclude and x not in q]
                rng.shuffle(rest);q+=rest[:5]
                qpool=tuple(q)
                if not query_can_reduce(sp,fib,qpool):continue
            found=True;break
        if not found:continue
        return Task(h((domain,lane,regime,seed,tr,tuple(demos_x),target,qpool))[:20],domain,lane,regime,tr,tc,demos,target,qpool,fib)
    raise RuntimeError(f'cannot generate {domain} {lane} {regime}')


def make_anti_task(domain,lane,seed,max_tries=3000):
    sp=SPACES[domain];rng=random.Random(seed);raws=[r for r,m in sp.raw.items() if m.lane==lane];allc=tuple(sorted(sp.classes))
    for _ in range(max_tries):
        tr=rng.choice(raws);truth=sp.raw[tr];xs=rng.sample(list(sp.inputs),3);demos=[(x,model_apply(truth,x,sp.p)) for x in xs]
        # deterministically corrupt one observed output until the exact model fiber is empty.
        found=False
        for i in range(len(demos)):
            x,y=demos[i]
            for delta in ((1,0),(0,1),(1,1),(2,0)):
                bad=list(demos);bad[i]=(x,((y[0]+delta[0])%sp.p,(y[1]+delta[1])%sp.p));fib=filter_classes(sp,allc,tuple(bad))
                if not fib:
                    demos=bad;found=True;break
            if found:break
        if not found:continue
        remain=[x for x in sp.inputs if x not in xs];target=rng.choice(remain);remain=[x for x in remain if x!=target];qpool=tuple(rng.sample(remain,min(6,len(remain))))
        return Task(h((domain,lane,'ANTI',seed,tr,tuple(demos),target,qpool))[:20],domain,lane,'ANTI',tr,sp.raw_to_class[tr],tuple(demos),target,qpool,tuple())
    raise RuntimeError(f'cannot generate anti {domain} {lane}')

def generate_tasks(n_each=8):
    tasks=[]
    for di,d in enumerate(DOMAINS):
        for li,lane in enumerate(('NAMED','COMPOSITION_OOD')):
            for ri,reg in enumerate(REGIMES):
                for i in range(n_each):tasks.append(make_task(d,lane,reg,SEED+di*100000+li*10000+ri*1000+i))
            for i in range(max(2,n_each//2)):tasks.append(make_anti_task(d,lane,SEED+di*100000+li*10000+9000+i))
    return tasks

# ---------- query strategies ----------
def cell_claim_counts(space,cell):return (len(cell),len(family_set(space,cell)),len(operator_set(space,cell)))
def partition_profile(space,cids,q):
    parts=partition(space,cids,q);profiles=[cell_claim_counts(space,c) for c in parts.values()]
    return parts,profiles

def q_random(task,space):return task.query_pool[int(task.task_id[:8],16)%len(task.query_pool)] if task.query_pool else None

def q_exact_minimax(task,space):
    best=None
    for q in task.query_pool:
        parts,_=partition_profile(space,task.pre_classes,q);key=(max(map(len,parts.values())),sum(len(c)**2 for c in parts.values()),repr(q))
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def q_eig(task,space):
    n=len(task.pre_classes);best=None
    for q in task.query_pool:
        parts=partition(space,task.pre_classes,q)
        # probability is used ONLY to rank queries; it never determines Form.
        exp=sum((len(c)/n)*math.log(max(1,len(c))) for c in parts.values())
        key=(exp,repr(q))
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def mdl_weight(space,cid):return math.exp(-8*min(space.classes[cid].complexities))
def q_bayes_mdl(task,space):
    weights={c:mdl_weight(space,c) for c in task.pre_classes};tot=sum(weights.values());best=None
    for q in task.query_pool:
        parts=partition(space,task.pre_classes,q);exp=0.0
        for cell in parts.values():
            w=sum(weights[c] for c in cell);p=w/tot
            if w>0:
                norm=[weights[c]/w for c in cell];ent=-sum(v*math.log(v) for v in norm if v>0)
            else:ent=0
            exp+=p*ent
        key=(exp,repr(q))
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def q_variance(task,space):
    best=None
    for q in task.query_pool:
        arr=np.array([out_at(space,c,q) for c in task.pre_classes],float);v=float(arr.var(axis=0).sum());key=(-v,repr(q))
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def q_mdl_disagree(task,space):
    cmin=min(min(space.classes[c].complexities) for c in task.pre_classes);short=[c for c in task.pre_classes if min(space.classes[c].complexities)==cmin]
    best=None
    for q in task.query_pool:
        k=len(partition(space,short,q));key=(-k,repr(q))
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def q_family_minimax(task,space):
    best=None
    for q in task.query_pool:
        parts=partition(space,task.pre_classes,q);key=(max(len(family_set(space,c)) for c in parts.values()),max(len(c) for c in parts.values()),sum(len(c)**2 for c in parts.values()),repr(q))
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def q_tos(task,space):
    # Deterministic conformational criterion: no posterior. Minimize the worst residual
    # class/family/operator fiber lexicographically, then the full sorted partition profile.
    best=None
    for q in task.query_pool:
        parts,profiles=partition_profile(space,task.pre_classes,q)
        worst=(max(v[0] for v in profiles),max(v[1] for v in profiles),max(v[2] for v in profiles))
        prof=tuple(sorted((v[0],v[1],v[2]) for v in profiles)[::-1])
        key=(worst,prof,repr(q))
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

STRATEGIES={
 'RANDOM_QUERY':q_random,
 'EXACT_MINIMAX_QUERY':q_exact_minimax,
 'EXACT_EIG_QUERY':q_eig,
 'BAYES_MDL_QUERY':q_bayes_mdl,
 'MAX_PREDICTIVE_VARIANCE_QUERY':q_variance,
 'MDL_DISAGREEMENT_QUERY':q_mdl_disagree,
 'EXACT_FAMILY_MINIMAX_QUERY':q_family_minimax,
 'TOS_ACTIVE_TOPOLOGY_O3':q_tos,
}


def observe_query(task,space,q):
    if q is None:return task.pre_classes
    truth=space.raw[task.truth_raw];y=model_apply(truth,q,space.p)
    return tuple(sorted(c for c in task.pre_classes if out_at(space,c,q)==y))

def evaluate_strategy(task,name,fn):
    sp=SPACES[task.domain];pre=task.pre_classes
    if len(pre)==0:return {'method':name,'query':None,'pre_classes':0,'post_classes':0,'normalized_fiber_reduction':0.0,
        'mapping_state':'-1','family_state':'-1','operator_state':'-1','ontology_state':'0',
        'mapping_form':False,'family_form':False,'operator_form':False,'target_pre_values':0,'target_post_values':0,
        'prediction_exact':False,'false_form_promotion':False}
    if name=='TOS_NO_O3':
        q=None;post=pre
    else:
        q=fn(task,sp);post=observe_query(task,sp,q)
    remq=tuple(x for x in task.query_pool if x!=q)
    mapst=claim_state(sp,post,remq,'mapping');famst=claim_state(sp,post,remq,'family');opst=claim_state(sp,post,remq,'operator')
    pre_n=len(pre);post_n=len(post);norm=(pre_n-post_n)/(pre_n-1) if pre_n>1 else 1.0
    target_pre=len(target_outputs(sp,pre,task.target));target_post=len(target_outputs(sp,post,task.target)) if post else 0
    return {'method':name,'query':q,'pre_classes':pre_n,'post_classes':post_n,'normalized_fiber_reduction':norm,
            'mapping_state':mapst,'family_state':famst,'operator_state':opst,'ontology_state':'0',
            'mapping_form':mapst=='1','family_form':famst=='1','operator_form':opst=='1',
            'target_pre_values':target_pre,'target_post_values':target_post,'prediction_exact':target_post==1,
            'false_form_promotion':False}


def legacy_probability_control(task):
    sp=SPACES[task.domain];weights={c:mdl_weight(sp,c) for c in task.pre_classes};tot=sum(weights.values());mx=(max(weights.values())/tot) if weights and tot else 0
    # INVALID legacy rule included only as a negative control. It is not a valid CFL adjudicator.
    promotes=mx>=0.999
    exact_family_unique=len(family_set(sp,task.pre_classes))==1
    return {'task_id':task.task_id,'posterior_max':mx,'legacy_promotes_form':promotes,'exact_family_form':exact_family_unique,'false_form_promotion':promotes and not exact_family_unique}


def bootstrap_delta(rows,a,b,key='family_form',n=3000):
    aa={r['task_id']:int(r[key]) for r in rows if r['method']==a and r['regime'] not in ('MODEL_IDENTIFIED','ANTI')};bb={r['task_id']:int(r[key]) for r in rows if r['method']==b and r['regime'] not in ('MODEL_IDENTIFIED','ANTI')};ids=sorted(set(aa)&set(bb));d=np.array([aa[i]-bb[i] for i in ids],float);rng=np.random.default_rng(SEED);bs=[float(np.mean(rng.choice(d,size=len(d),replace=True))) for _ in range(n)];return {'delta':float(d.mean()),'ci':[float(np.quantile(bs,.025)),float(np.quantile(bs,.975))],'n':len(d)}


def main():
    out=Path(os.environ.get('G35_WORKDIR','/mnt/data/CFL_G3_5_ACTIVE_TOPOLOGY_RUN'));out.mkdir(parents=True,exist_ok=True)
    tasks=generate_tasks(8)
    write_jsonl(out/'evidence'/'TASKS.jsonl',[{'task_id':t.task_id,'domain':t.domain,'lane':t.lane,'regime':t.regime,'truth_class_hash':h(t.truth_class),'demos':t.demos,'target':t.target,'query_pool':t.query_pool,'pre_classes':len(t.pre_classes)} for t in tasks])
    rows=[]
    for t in tasks:
        for name,fn in STRATEGIES.items():
            r=evaluate_strategy(t,name,fn);r.update({'task_id':t.task_id,'domain':t.domain,'lane':t.lane,'regime':t.regime});rows.append(r)
        r=evaluate_strategy(t,'TOS_NO_O3',lambda a,b:None);r.update({'task_id':t.task_id,'domain':t.domain,'lane':t.lane,'regime':t.regime});rows.append(r)
    write_jsonl(out/'results'/'PREDICTIONS.jsonl',rows)
    legacy=[legacy_probability_control(t) for t in tasks];write_jsonl(out/'results'/'LEGACY_PROBABILITY_CONTROL.jsonl',legacy)
    # summary
    methods=sorted(set(r['method'] for r in rows));summary={}
    for m in methods:
        z=[r for r in rows if r['method']==m];amb=[r for r in z if r['regime'] not in ('MODEL_IDENTIFIED','ANTI')]
        summary[m]={
          'mapping_form_rate_ambiguous':sum(r['mapping_form'] for r in amb)/len(amb),
          'family_form_rate_ambiguous':sum(r['family_form'] for r in amb)/len(amb),
          'operator_form_rate_ambiguous':sum(r['operator_form'] for r in amb)/len(amb),
          'mean_normalized_fiber_reduction':float(np.mean([r['normalized_fiber_reduction'] for r in amb])),
          'prediction_exact_rate':sum(r['prediction_exact'] for r in z)/len(z),
          'false_form_promotion_rate':sum(r['false_form_promotion'] for r in z)/len(z)
        }
    write_json(out/'results'/'SUMMARY.json',summary)
    # strongest valid baseline by family-form rate then mapping-form then reduction
    baseline_methods=[m for m in methods if m not in ('TOS_ACTIVE_TOPOLOGY_O3','TOS_NO_O3')]
    best=max(baseline_methods,key=lambda m:(summary[m]['family_form_rate_ambiguous'],summary[m]['mapping_form_rate_ambiguous'],summary[m]['mean_normalized_fiber_reduction']))
    boot=bootstrap_delta(rows,'TOS_ACTIVE_TOPOLOGY_O3',best,'family_form')
    legacy_fp=sum(r['false_form_promotion'] for r in legacy)/len(legacy)
    # by lane/domain
    def rate(sub,method,key):
        zz=[r for r in rows if r['method']==method and sub(r) and r['regime'] not in ('MODEL_IDENTIFIED','ANTI')];return sum(r[key] for r in zz)/len(zz) if zz else None
    by_domain={d:rate(lambda r,d=d:r['domain']==d,'TOS_ACTIVE_TOPOLOGY_O3','family_form') for d in DOMAINS}
    by_lane={l:rate(lambda r,l=l:r['lane']==l,'TOS_ACTIVE_TOPOLOGY_O3','family_form') for l in ('NAMED','COMPOSITION_OOD')}
    tos=summary['TOS_ACTIVE_TOPOLOGY_O3'];b=summary[best]
    support=(boot['delta']>=.02 and boot['ci'][0]>0 and sum(v is not None and v>b['family_form_rate_ambiguous'] for v in by_domain.values())>=3 and tos['false_form_promotion_rate']<=.02)
    outcome='G3_5_LOCAL_SUPPORT' if support else ('G3_5_REFUTED' if boot['delta']<=-.02 else 'G3_5_BASELINE_EQUIVALENT')
    adj={'program_id':PROGRAM_ID,'version':VERSION,'outcome':outcome,'form_semantics':'CATEGORICAL_NONPROBABILISTIC_ONLY',
         'probability_role':'QUERY_SELECTION_ONLY_NEVER_FORM_CERTIFICATION','strongest_valid_baseline':best,
         'tos_family_form_rate':tos['family_form_rate_ambiguous'],'baseline_family_form_rate':b['family_form_rate_ambiguous'],'paired_bootstrap':boot,
         'tos_mapping_form_rate':tos['mapping_form_rate_ambiguous'],'tos_mean_fiber_reduction':tos['mean_normalized_fiber_reduction'],
         'by_domain_family_form':by_domain,'by_lane_family_form':by_lane,'legacy_probability_false_form_rate':legacy_fp,
         'form_gate':{'mapping':'state 1 iff exact post-query mapping-class fiber has cardinality one','family':'state 1 iff exact post-query family set has cardinality one','operator':'state 1 iff exact post-query operator set has cardinality one','ontology':'always 0 in generated kernel'},
         'benchmark_state':'+0_ACTIVE_DISAMBIGUATION_BENCHMARK_PROTOFORM','o3_claim_state':'0_BASELINE_EQUIVALENT' if outcome=='G3_5_BASELINE_EQUIVALENT' else '+0_UNREPLICATED','authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED'}
    write_json(out/'results'/'FINAL_ADJUDICATION.json',adj)
    write_json(out/'results'/'RUN_MANIFEST.json',{'program_id':PROGRAM_ID,'version':VERSION,'task_count':len(tasks),'prediction_rows':len(rows),'domain_spaces':{d:{'p':s.p,'raw_models':len(s.raw),'mapping_classes':len(s.classes)} for d,s in SPACES.items()},'adjudication':adj})
    (out/'results'/'REPORT.md').write_text(f'''# CFL G3.5 Active Topology Disambiguation\n\nOutcome: **{outcome}**. Form is categorical and non-probabilistic in this gate. Probability/entropy may rank a query, but state 1 is emitted only after exact fiber collapse.\n\nTOS family-Form collapse rate on initially ambiguous tasks: {tos['family_form_rate_ambiguous']:.4f}; strongest valid baseline `{best}`: {b['family_form_rate_ambiguous']:.4f}; paired delta {boot['delta']:.4f}, 95% CI {boot['ci']}. Legacy probability-threshold control false-Form rate: {legacy_fp:.4f}.\n''')
    print(json.dumps(adj,indent=2))

if __name__=='__main__':main()
