#!/usr/bin/env python3
"""CFL-UEP G1.2: dimensionless closure on measured lotus-root CT data.

This is a preregistered third-object material gate. It repairs the scale,
convergence, adaptive-update, external-test and Fisher-diagnostic defects found
in G1/G1.1. It does not implement or canonize full TOS\\ or CFL.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import platform
import sys
import time
import urllib.request
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import h5py
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import scipy
import scipy.io
import scipy.sparse as sp
import scipy.sparse.linalg as spla

PROGRAM_ID = "CFL-UEP-G1.2-DIMENSIONLESS-CLOSURE-LOTUS-20260927"
DATA_URL = "https://zenodo.org/records/1254204/files/LotusData128.mat?download=1"
UPSTREAM_DOI = "10.5281/zenodo.1254204"
EXPECTED_MD5 = "da8b8d64b3becf987d84c6a2eceda2eb"
EXPECTED_SIZE = 110_740_268
N = 128
N_ANGLES = 120
SEED = 12027

# Three disjoint, preregistered external masks. None is used for tuning.
TEST_MASKS = {
    "T0_mod12_eq0": np.arange(0, N_ANGLES, 12, dtype=int),
    "T1_mod12_eq4": np.arange(4, N_ANGLES, 12, dtype=int),
    "T2_mod12_eq8": np.arange(8, N_ANGLES, 12, dtype=int),
}

# Dimensionless grids after local operator and Laplacian normalization.
ALPHAS = [1e-3, 1e-2, 1e-1]
BETAS = [1e-2, 1e-1]
MUS = [0.3, 3.0]
LAMBDAS = [1e-2, 1e-1]
CG_RTOL = 2e-6
CG_MAXITER = 1200
POWER_ITERS = 14
CV_FOLDS = 3
UPDATE_MIN = 1e-6
NORMAL_RESIDUAL_MAX = 2e-5
SUPPORT_MARGIN = 0.02
FALSE_CLOSURE_MARGIN = 0.05
MAX_COST_RATIO = 2.0
CROSS_GAIN_MIN = 0.05
PRESERVATION_DELTA_MAX = 0.015
HOLONOMY_MAX = 0.35
VALIDATION_ENVELOPE_MAX_RATIO = 1.05
FISHER_SKETCH = 96
SIGMA_CACHE: dict[str, float] = {}

BASELINE_METHODS = [
    "JOINT_TIKHONOV",
    "FIXED_LAPLACIAN",
    "SELF_ADAPTIVE_ONCE",
    "IRLS2",
    "OLD_PHI12_LAPLACIAN",
]
CLOSURE_METHODS = ["DBFTC_ONE_CYCLE", "DFIC_THREE_CYCLE"]
ALL_METHODS = BASELINE_METHODS + CLOSURE_METHODS


@dataclass
class SolveResult:
    image: np.ndarray
    info: int
    seconds: float
    iterations: int
    normal_residual: float
    update_rel: float
    valid: bool
    reason: str


@dataclass
class ScaledSystem:
    A: sp.csr_matrix
    b: np.ndarray
    sigma: float
    name: str

    def forward(self, x: np.ndarray) -> np.ndarray:
        return np.asarray(self.A @ x).ravel() / self.sigma

    def rhs(self) -> np.ndarray:
        return np.asarray(self.A.T @ self.b).ravel() / (self.sigma * self.sigma)

    def data_nrmse(self, x: np.ndarray) -> float:
        return nrmse(self.A @ x, self.b)


def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def hash_file(path: Path, algorithm: str = "sha256") -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def download_exact(path: Path) -> None:
    if path.exists() and hash_file(path, "md5") == EXPECTED_MD5:
        return
    tmp = path.with_suffix(path.suffix + ".part")
    tmp.unlink(missing_ok=True)
    req = urllib.request.Request(DATA_URL, headers={"User-Agent": "CFL-UEP-G1.2/1.0"})
    with urllib.request.urlopen(req, timeout=1200) as response, tmp.open("wb") as out:
        while True:
            block = response.read(1 << 20)
            if not block:
                break
            out.write(block)
    if hash_file(tmp, "md5") != EXPECTED_MD5:
        raise RuntimeError("Lotus dataset checksum mismatch")
    tmp.replace(path)


def load_fips_mat(path: Path) -> tuple[sp.csr_matrix, np.ndarray, dict[str, Any], str]:
    """Load classic MAT or MATLAB v7.3/HDF5 sparse data."""
    metadata: dict[str, Any] = {}
    try:
        raw = scipy.io.loadmat(path)
        keys = sorted(k for k in raw if not k.startswith("__"))
        if "A" not in raw or "m" not in raw:
            raise RuntimeError(f"A/m missing; keys={keys}")
        A = raw["A"]
        if not sp.issparse(A):
            A = sp.csr_matrix(A)
        raw_m = np.asarray(raw["m"], dtype=np.float64)
        for key in ("normA", "N", "n", "angles"):
            if key in raw:
                arr = np.asarray(raw[key]).squeeze()
                metadata[key] = arr.tolist() if arr.ndim else float(arr)
        loader = "scipy.io.loadmat"
    except (NotImplementedError, ValueError):
        with h5py.File(path, "r") as f:
            keys = sorted(f.keys())
            if "A" not in f or "m" not in f:
                raise RuntimeError(f"A/m missing in HDF5 MAT; keys={keys}")
            g = f["A"]
            if isinstance(g, h5py.Group) and all(k in g for k in ("data", "ir", "jc")):
                data = np.asarray(g["data"], dtype=np.float64).ravel()
                ir = np.asarray(g["ir"], dtype=np.int64).ravel()
                jc = np.asarray(g["jc"], dtype=np.int64).ravel()
                n_rows = int(g.attrs.get("MATLAB_sparse", int(ir.max()) + 1))
                n_cols = int(jc.size - 1)
                A = sp.csc_matrix((data, ir, jc), shape=(n_rows, n_cols))
            else:
                A = sp.csr_matrix(np.asarray(g, dtype=np.float64).T)
            raw_m = np.asarray(f["m"], dtype=np.float64)
            for key in ("normA", "N", "n", "angles"):
                if key in f:
                    arr = np.asarray(f[key]).squeeze()
                    metadata[key] = arr.tolist() if arr.ndim else float(arr)
            loader = "h5py_matlab_v7.3"
    A = A.tocsr().astype(np.float64)
    if raw_m.ndim != 2:
        raise RuntimeError(f"Expected 2D sinogram, found {raw_m.shape}")
    if raw_m.shape[1] == N_ANGLES:
        m = raw_m
    elif raw_m.shape[0] == N_ANGLES:
        m = raw_m.T
    else:
        raise RuntimeError(f"Cannot identify 120-angle axis in sinogram {raw_m.shape}")
    if A.shape[0] != m.size:
        raise RuntimeError(f"A rows {A.shape[0]} != sinogram size {m.size}")
    if A.shape[1] != N * N:
        raise RuntimeError(f"A columns {A.shape[1]} != {N*N}")
    metadata["keys"] = keys
    return A, np.asarray(m, dtype=np.float64), metadata, loader


def rows_for_angles(angles: Iterable[int], detector_count: int) -> np.ndarray:
    return np.concatenate([
        np.arange(int(a) * detector_count, (int(a) + 1) * detector_count, dtype=np.int64)
        for a in angles
    ])


def subset(A: sp.csr_matrix, m: np.ndarray, angles: Sequence[int]) -> tuple[sp.csr_matrix, np.ndarray]:
    angles_arr = np.asarray(angles, dtype=int)
    rows = rows_for_angles(angles_arr, m.shape[0])
    return A[rows, :].tocsr(), np.asarray(m[:, angles_arr], dtype=np.float64).reshape(-1, order="F")


def nrmse(pred: np.ndarray, target: np.ndarray) -> float:
    return float(np.linalg.norm(np.asarray(pred).ravel() - np.asarray(target).ravel()) /
                 max(np.linalg.norm(np.asarray(target).ravel()), 1e-15))


def correlation(pred: np.ndarray, target: np.ndarray) -> float:
    x, y = np.asarray(pred).ravel(), np.asarray(target).ravel()
    if np.std(x) < 1e-15 or np.std(y) < 1e-15:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def relative_change(x: np.ndarray, y: np.ndarray) -> float:
    return float(np.linalg.norm(np.asarray(x) - np.asarray(y)) / max(np.linalg.norm(np.asarray(y)), 1e-15))


def robust_scale(x: np.ndarray) -> float:
    z = np.asarray(x, dtype=np.float64).ravel()
    z = z[np.isfinite(z) & (z > 0)]
    return float(np.median(z) + 1e-12) if z.size else 1.0


def power_operator_norm(A: sp.csr_matrix, seed: int, iters: int = POWER_ITERS) -> float:
    rng = np.random.default_rng(seed)
    x = rng.normal(size=A.shape[1])
    x /= max(np.linalg.norm(x), 1e-15)
    sigma = 0.0
    for _ in range(iters):
        y = np.asarray(A @ x).ravel()
        sigma = float(np.linalg.norm(y))
        if sigma <= 1e-15:
            return 1.0
        z = np.asarray(A.T @ y).ravel()
        nz = np.linalg.norm(z)
        if nz <= 1e-15:
            return sigma
        x = z / nz
    return max(sigma, 1e-12)


def make_system(A: sp.csr_matrix, b: np.ndarray, name: str, seed: int) -> ScaledSystem:
    if name not in SIGMA_CACHE:
        SIGMA_CACHE[name] = power_operator_norm(A, seed)
    return ScaledSystem(A=A, b=np.asarray(b, dtype=np.float64), sigma=SIGMA_CACHE[name], name=name)


def solve_meta(result: SolveResult) -> dict[str, Any]:
    return {
        "info": result.info,
        "seconds": result.seconds,
        "iterations": result.iterations,
        "normal_residual": result.normal_residual,
        "update_rel": result.update_rel,
        "valid": result.valid,
        "reason": result.reason,
    }


def build_laplacian(n: int, weights_h: np.ndarray | None = None,
                    weights_v: np.ndarray | None = None) -> sp.csr_matrix:
    if weights_h is None:
        weights_h = np.ones((n, n - 1), dtype=np.float64)
    if weights_v is None:
        weights_v = np.ones((n - 1, n), dtype=np.float64)
    rows: list[int] = []
    cols: list[int] = []
    vals: list[float] = []
    diag = np.zeros(n * n, dtype=np.float64)

    def idx(r: int, c: int) -> int:
        return r + c * n

    for r in range(n):
        for c in range(n - 1):
            i, j = idx(r, c), idx(r, c + 1)
            w = float(weights_h[r, c])
            diag[i] += w; diag[j] += w
            rows.extend((i, j)); cols.extend((j, i)); vals.extend((-w, -w))
    for r in range(n - 1):
        for c in range(n):
            i, j = idx(r, c), idx(r + 1, c)
            w = float(weights_v[r, c])
            diag[i] += w; diag[j] += w
            rows.extend((i, j)); cols.extend((j, i)); vals.extend((-w, -w))
    rows.extend(range(n * n)); cols.extend(range(n * n)); vals.extend(diag.tolist())
    return sp.coo_matrix((vals, (rows, cols)), shape=(n * n, n * n)).tocsr()


def laplacian_scale(L: sp.csr_matrix) -> float:
    # For a weighted graph Laplacian, lambda_max <= 2*max weighted degree.
    return max(2.0 * float(np.max(L.diagonal())), 1e-12)


def edge_laplacian(x: np.ndarray, n: int) -> sp.csr_matrix:
    img = np.asarray(x).reshape((n, n), order="F")
    h = np.abs(np.diff(img, axis=1))
    v = np.abs(np.diff(img, axis=0))
    wh = np.clip(np.exp(-h / robust_scale(h)), 0.03, 8.0)
    wv = np.clip(np.exp(-v / robust_scale(v)), 0.03, 8.0)
    return build_laplacian(n, wh, wv)


def phi12_laplacian(x1: np.ndarray, x2: np.ndarray, n: int) -> tuple[sp.csr_matrix, dict[str, float]]:
    i1 = np.asarray(x1).reshape((n, n), order="F")
    i2 = np.asarray(x2).reshape((n, n), order="F")
    h1, h2 = np.diff(i1, axis=1), np.diff(i2, axis=1)
    v1, v2 = np.diff(i1, axis=0), np.diff(i2, axis=0)
    eh, ev = 0.5 * (np.abs(h1) + np.abs(h2)), 0.5 * (np.abs(v1) + np.abs(v2))
    dh, dv = np.abs(h1 - h2), np.abs(v1 - v2)
    wh = np.clip(np.exp(-eh / robust_scale(eh)) * (1.0 + dh / robust_scale(dh)), 0.03, 8.0)
    wv = np.clip(np.exp(-ev / robust_scale(ev)) * (1.0 + dv / robust_scale(dv)), 0.03, 8.0)
    return build_laplacian(n, wh, wv), {
        "edge_h_median": float(np.median(eh)),
        "edge_v_median": float(np.median(ev)),
        "disagreement_h_median": float(np.median(dh)),
        "disagreement_v_median": float(np.median(dv)),
    }


def solve_quadratic(sysm: ScaledSystem, alpha: float, beta: float = 0.0,
                    L: sp.csr_matrix | None = None, x0: np.ndarray | None = None,
                    require_update: bool = False) -> SolveResult:
    n = sysm.A.shape[1]
    sigma2 = sysm.sigma * sysm.sigma
    rhs = np.asarray(sysm.A.T @ sysm.b).ravel() / sigma2
    lscale = laplacian_scale(L) if (beta > 0 and L is not None) else 1.0
    iterations = 0

    def mv(x: np.ndarray) -> np.ndarray:
        out = np.asarray(sysm.A.T @ (sysm.A @ x)).ravel() / sigma2 + alpha * x
        if beta > 0 and L is not None:
            out += beta * np.asarray(L @ x).ravel() / lscale
        return out

    def callback(_: np.ndarray) -> None:
        nonlocal iterations
        iterations += 1

    diag = np.asarray(sysm.A.power(2).sum(axis=0)).ravel() / sigma2 + alpha
    if beta > 0 and L is not None:
        diag += beta * L.diagonal() / lscale
    op = spla.LinearOperator((n, n), matvec=mv, dtype=np.float64)
    pre = spla.LinearOperator((n, n), matvec=lambda x: x / np.maximum(diag, 1e-12), dtype=np.float64)
    start = time.perf_counter()
    x, info = spla.cg(op, rhs, x0=x0, rtol=CG_RTOL, atol=0.0,
                      maxiter=CG_MAXITER, M=pre, callback=callback)
    elapsed = time.perf_counter() - start
    x = np.asarray(x)
    normal_residual = float(np.linalg.norm(mv(x) - rhs) / max(np.linalg.norm(rhs), 1e-15))
    update_rel = relative_change(x, x0) if x0 is not None else float("nan")
    valid = bool(info == 0 and np.isfinite(normal_residual) and normal_residual <= NORMAL_RESIDUAL_MAX)
    reason = "OK" if valid else f"CG_OR_RESIDUAL_FAILURE(info={info},res={normal_residual:.3e})"
    if valid and require_update and (not np.isfinite(update_rel) or update_rel <= UPDATE_MIN):
        valid = False
        reason = f"DEGENERATE_ZERO_UPDATE({update_rel:.3e})"
    return SolveResult(x, int(info), float(elapsed), int(iterations), normal_residual,
                       float(update_rel), valid, reason)


def solve_transport(target: ScaledSystem, preserve: ScaledSystem, x_start: np.ndarray,
                    mu: float, lam: float) -> SolveResult:
    n = target.A.shape[1]
    st2 = target.sigma * target.sigma
    sp2 = preserve.sigma * preserve.sigma
    residual = target.b - target.A @ x_start
    rhs = np.asarray(target.A.T @ residual).ravel() / st2
    iterations = 0

    def mv(d: np.ndarray) -> np.ndarray:
        return (np.asarray(target.A.T @ (target.A @ d)).ravel() / st2
                + mu * np.asarray(preserve.A.T @ (preserve.A @ d)).ravel() / sp2
                + lam * d)

    def callback(_: np.ndarray) -> None:
        nonlocal iterations
        iterations += 1

    diag = (np.asarray(target.A.power(2).sum(axis=0)).ravel() / st2
            + mu * np.asarray(preserve.A.power(2).sum(axis=0)).ravel() / sp2 + lam)
    op = spla.LinearOperator((n, n), matvec=mv, dtype=np.float64)
    pre = spla.LinearOperator((n, n), matvec=lambda x: x / np.maximum(diag, 1e-12), dtype=np.float64)
    start = time.perf_counter()
    d, info = spla.cg(op, rhs, rtol=CG_RTOL, atol=0.0, maxiter=CG_MAXITER, M=pre, callback=callback)
    elapsed = time.perf_counter() - start
    d = np.asarray(d)
    normal_residual = float(np.linalg.norm(mv(d) - rhs) / max(np.linalg.norm(rhs), 1e-15))
    update_rel = float(np.linalg.norm(d) / max(np.linalg.norm(x_start), 1e-15))
    valid = bool(info == 0 and np.isfinite(normal_residual) and normal_residual <= NORMAL_RESIDUAL_MAX
                 and update_rel > UPDATE_MIN)
    if info != 0 or normal_residual > NORMAL_RESIDUAL_MAX:
        reason = f"CG_OR_RESIDUAL_FAILURE(info={info},res={normal_residual:.3e})"
    elif update_rel <= UPDATE_MIN:
        reason = f"DEGENERATE_ZERO_UPDATE({update_rel:.3e})"
    else:
        reason = "OK"
    return SolveResult(d, int(info), float(elapsed), int(iterations), normal_residual,
                       update_rel, valid, reason)


def all_test_angles() -> np.ndarray:
    return np.sort(np.concatenate(list(TEST_MASKS.values())))


def cv_partitions() -> list[dict[str, np.ndarray]]:
    all_angles = np.arange(N_ANGLES, dtype=int)
    test_set = set(all_test_angles().tolist())
    non_test = np.array([a for a in all_angles if a not in test_set], dtype=int)
    folds: list[dict[str, np.ndarray]] = []
    for fold in range(CV_FOLDS):
        val = non_test[np.arange(non_test.size) % CV_FOLDS == fold]
        val_set = set(val.tolist())
        train = np.array([a for a in non_test if a not in val_set], dtype=int)
        o1, o2 = train[::2], train[1::2]
        folds.append({"fold": np.array([fold]), "train": train, "val": val, "o1": o1, "o2": o2})
    return folds


def candidate_record(method: str, config: dict[str, float], fold: int, val: float,
                     train: float, result: SolveResult | None,
                     extra: dict[str, Any] | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {
        "method": method,
        "config": config,
        "fold": fold,
        "val_nrmse": float(val),
        "train_nrmse": float(train),
    }
    if result is not None:
        out.update({
            "solve_seconds": result.seconds,
            "iterations": result.iterations,
            "info": result.info,
            "normal_residual": result.normal_residual,
            "update_rel": result.update_rel,
            "valid": result.valid,
            "reason": result.reason,
        })
    if extra:
        out.update(extra)
    return out


def config_key(config: dict[str, float]) -> str:
    return json.dumps(config, sort_keys=True, separators=(",", ":"))


def select_config(records: list[dict[str, Any]], method: str, closure: bool = False) -> dict[str, Any]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for rec in records:
        if rec.get("method") == method and bool(rec.get("valid", True)):
            groups[config_key(rec["config"])].append(rec)
    ranked: list[dict[str, Any]] = []
    for key, rs in groups.items():
        if len(rs) != CV_FOLDS:
            continue
        vals = np.array([r["val_nrmse"] for r in rs], dtype=float)
        score = float(np.median(vals) + 0.25 * (np.percentile(vals, 75) - np.percentile(vals, 25)))
        pass_count = sum(bool(r.get("closure_gate_pass", False)) for r in rs)
        if closure:
            score += 0.05 * (CV_FOLDS - pass_count)
            score += 0.02 * float(np.median([r.get("holonomy", 1.0) for r in rs]))
        ranked.append({
            "config": json.loads(key),
            "score": score,
            "median_val_nrmse": float(np.median(vals)),
            "iqr_val_nrmse": float(np.percentile(vals, 75) - np.percentile(vals, 25)),
            "closure_pass_count": pass_count,
            "records": rs,
        })
    if not ranked:
        return {"status": "NOT_IDENTIFIABLE_NO_VALID_CONFIG", "config": None,
                "score": float("inf"), "median_val_nrmse": float("inf"),
                "closure_pass_count": 0, "records": []}
    best = min(ranked, key=lambda z: (z["score"], config_key(z["config"])))
    best["status"] = "SELECTED"
    return best


def tune_partial_alpha(sys1: ScaledSystem, sys2: ScaledSystem,
                       Aval: sp.csr_matrix, bval: np.ndarray) -> tuple[float, np.ndarray, np.ndarray, list[dict[str, Any]]]:
    trace = []
    best: tuple[float, float] | None = None
    best_pair: tuple[np.ndarray, np.ndarray] | None = None
    for alpha in ALPHAS:
        s1 = solve_quadratic(sys1, alpha)
        s2 = solve_quadratic(sys2, alpha)
        if not (s1.valid and s2.valid):
            score = float("inf")
        else:
            score = 0.5 * (nrmse(Aval @ s1.image, bval) + nrmse(Aval @ s2.image, bval))
        trace.append({
            "method": "PARTIAL_ALPHA_SELECTION",
            "config": {"alpha": alpha},
            "mean_val_nrmse": score,
            "O1_valid": s1.valid,
            "O2_valid": s2.valid,
            "O1_reason": s1.reason,
            "O2_reason": s2.reason,
        })
        if np.isfinite(score) and (best is None or (score, alpha) < best):
            best = (score, alpha); best_pair = (s1.image, s2.image)
    if best is None or best_pair is None:
        raise RuntimeError("No valid partial-view alpha")
    return float(best[1]), best_pair[0], best_pair[1], trace


def closure_cycle(sys1: ScaledSystem, sys2: ScaledSystem, x1: np.ndarray, x2: np.ndarray,
                  mu: float, lam: float, cycles: int) -> tuple[np.ndarray, dict[str, Any]]:
    p12 = np.asarray(x1).copy()
    p21 = np.asarray(x2).copy()
    all_results: list[SolveResult] = []
    start_cross_12 = sys2.data_nrmse(p12)
    start_cross_21 = sys1.data_nrmse(p21)
    own1_before = sys1.data_nrmse(p12)
    own2_before = sys2.data_nrmse(p21)
    for _ in range(cycles):
        d12 = solve_transport(sys2, sys1, p12, mu, lam)
        all_results.append(d12)
        if not d12.valid:
            break
        p12 = p12 + d12.image
        # Re-anchor softly to the originating view through the reverse constrained correction.
        d12b = solve_transport(sys1, sys2, p12, mu, lam)
        all_results.append(d12b)
        if not d12b.valid:
            break
        p12 = p12 + 0.5 * d12b.image

        d21 = solve_transport(sys1, sys2, p21, mu, lam)
        all_results.append(d21)
        if not d21.valid:
            break
        p21 = p21 + d21.image
        d21b = solve_transport(sys2, sys1, p21, mu, lam)
        all_results.append(d21b)
        if not d21b.valid:
            break
        p21 = p21 + 0.5 * d21b.image
    fused = 0.5 * (p12 + p21)
    valid = bool(len(all_results) == cycles * 4 and all(r.valid for r in all_results))
    after_cross_12 = sys2.data_nrmse(p12)
    after_cross_21 = sys1.data_nrmse(p21)
    own1_after = sys1.data_nrmse(p12)
    own2_after = sys2.data_nrmse(p21)
    holonomy = float(np.linalg.norm(p12 - p21) / max(np.linalg.norm(fused), 1e-15))
    metrics = {
        "cycles": cycles,
        "cross_gain_12": float((start_cross_12 - after_cross_12) / max(start_cross_12, 1e-15)),
        "cross_gain_21": float((start_cross_21 - after_cross_21) / max(start_cross_21, 1e-15)),
        "preservation_delta_1": float(own1_after - own1_before),
        "preservation_delta_2": float(own2_after - own2_before),
        "holonomy": holonomy,
        "transport_valid": valid,
        "transport_seconds": float(sum(r.seconds for r in all_results)),
        "transport_iterations": int(sum(r.iterations for r in all_results)),
        "max_normal_residual": float(max((r.normal_residual for r in all_results), default=float("inf"))),
        "min_update_rel": float(min((r.update_rel for r in all_results), default=0.0)),
        "failure_reasons": [r.reason for r in all_results if not r.valid],
        "path12": p12,
        "path21": p21,
    }
    return fused, metrics


def randomized_fisher_audit(A1: sp.csr_matrix, A2: sp.csr_matrix, seed: int,
                            sketch: int = FISHER_SKETCH) -> dict[str, Any]:
    rng = np.random.default_rng(seed)
    k = min(sketch, A1.shape[1] // 4, A1.shape[0] - 1, A2.shape[0] - 1)
    omega1 = rng.normal(size=(A1.shape[0], k))
    omega2 = rng.normal(size=(A2.shape[0], k))
    y1 = np.asarray(A1.T @ omega1)
    y2 = np.asarray(A2.T @ omega2)
    q1, _ = np.linalg.qr(y1, mode="reduced")
    q2, _ = np.linalg.qr(y2, mode="reduced")
    s = np.linalg.svd(q1.T @ q2, compute_uv=False)
    cos2 = np.clip(s * s, 0.0, 1.0)
    novelty = float(1.0 - np.mean(cos2))
    angles = np.arccos(np.clip(s, 0.0, 1.0))

    # Construct a joint probe basis with the portion of Q2 not explained by Q1.
    residual = q2 - q1 @ (q1.T @ q2)
    q2n, r2n = np.linalg.qr(residual, mode="reduced")
    diag = np.abs(np.diag(r2n)) if r2n.ndim == 2 else np.array([])
    keep = diag > (diag.max() * 1e-8 if diag.size else 1.0)
    qjoint = np.concatenate([q1, q2n[:, keep]], axis=1) if np.any(keep) else q1
    if qjoint.shape[1] > 2 * k:
        qjoint = qjoint[:, :2 * k]
    sigma1 = power_operator_norm(A1, seed + 11, 10)
    sigma2 = power_operator_norm(A2, seed + 13, 10)
    b1 = np.asarray(A1 @ qjoint) / sigma1
    b2 = np.asarray(A2 @ qjoint) / sigma2
    g1 = b1.T @ b1
    g2 = b2.T @ b2
    gj = g1 + g2

    def spectral_summary(g: np.ndarray) -> dict[str, float]:
        eig = np.linalg.eigvalsh(0.5 * (g + g.T))
        eig = np.clip(eig, 0.0, None)
        positive = eig[eig > max(eig.max() * 1e-12, 1e-15)] if eig.size else np.array([])
        tr = float(eig.sum())
        tr2 = float(np.square(eig).sum())
        return {
            "dimension": int(eig.size),
            "numerical_rank": int(positive.size),
            "effective_rank": float((tr * tr) / max(tr2, 1e-15)),
            "lambda_min_positive": float(positive.min()) if positive.size else 0.0,
            "lambda_median": float(np.median(eig)) if eig.size else 0.0,
            "lambda_max": float(eig.max()) if eig.size else 0.0,
            "condition_positive": float(positive.max() / positive.min()) if positive.size else float("inf"),
            "logdet_eps": float(np.log(eig + 1e-8).sum()),
        }

    return {
        "status": "RANDOMIZED_ROWSPACE_SPECTRAL_AUDIT_NOT_EXACT_FULL_RANK",
        "sketch_dimension": int(k),
        "joint_probe_dimension": int(qjoint.shape[1]),
        "mean_cos2_overlap": float(np.mean(cos2)),
        "rowspace_novelty": novelty,
        "principal_angle_min_rad": float(angles.min()),
        "principal_angle_median_rad": float(np.median(angles)),
        "principal_angle_max_rad": float(angles.max()),
        "O1_structural_nullity_lower_bound": int(max(0, A1.shape[1] - A1.shape[0])),
        "O2_structural_nullity_lower_bound": int(max(0, A2.shape[1] - A2.shape[0])),
        "O1": spectral_summary(g1),
        "O2": spectral_summary(g2),
        "joint": spectral_summary(gj),
    }


def fit_cv(A: sp.csr_matrix, m: np.ndarray, n: int) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any]]:
    records: list[dict[str, Any]] = []
    fold_summaries: list[dict[str, Any]] = []
    partial_alphas: list[float] = []
    L_fixed = build_laplacian(n)
    for fold_info in cv_partitions():
        fold = int(fold_info["fold"][0])
        A1, b1 = subset(A, m, fold_info["o1"])
        A2, b2 = subset(A, m, fold_info["o2"])
        Atr, btr = subset(A, m, fold_info["train"])
        Aval, bval = subset(A, m, fold_info["val"])
        sys1 = make_system(A1, b1, f"fold{fold}-O1", SEED + fold * 100 + 1)
        sys2 = make_system(A2, b2, f"fold{fold}-O2", SEED + fold * 100 + 2)
        systr = make_system(Atr, btr, f"fold{fold}-train", SEED + fold * 100 + 3)
        partial_alpha, x1, x2, ptrace = tune_partial_alpha(sys1, sys2, Aval, bval)
        partial_alphas.append(partial_alpha)
        for p in ptrace:
            p["fold"] = fold; records.append(p)

        prelim: dict[float, SolveResult] = {}
        for alpha in ALPHAS:
            s = solve_quadratic(systr, alpha)
            prelim[alpha] = s
            records.append(candidate_record(
                "JOINT_TIKHONOV", {"alpha": alpha}, fold,
                nrmse(Aval @ s.image, bval) if s.valid else float("inf"),
                systr.data_nrmse(s.image), s,
            ))

        for alpha in ALPHAS:
            for beta in BETAS:
                s = solve_quadratic(systr, alpha, beta, L_fixed)
                records.append(candidate_record(
                    "FIXED_LAPLACIAN", {"alpha": alpha, "beta": beta}, fold,
                    nrmse(Aval @ s.image, bval) if s.valid else float("inf"),
                    systr.data_nrmse(s.image), s,
                ))

                pre = prelim[alpha]
                if pre.valid:
                    L0 = edge_laplacian(pre.image, n)
                    s1 = solve_quadratic(systr, alpha, beta, L0, x0=pre.image, require_update=True)
                else:
                    s1 = pre
                records.append(candidate_record(
                    "SELF_ADAPTIVE_ONCE", {"alpha": alpha, "beta": beta}, fold,
                    nrmse(Aval @ s1.image, bval) if s1.valid else float("inf"),
                    systr.data_nrmse(s1.image), s1,
                    {"pre_update_valid": pre.valid},
                ))
                if s1.valid:
                    L1 = edge_laplacian(s1.image, n)
                    s2 = solve_quadratic(systr, alpha, beta, L1, x0=s1.image, require_update=True)
                else:
                    s2 = s1
                records.append(candidate_record(
                    "IRLS2", {"alpha": alpha, "beta": beta}, fold,
                    nrmse(Aval @ s2.image, bval) if s2.valid else float("inf"),
                    systr.data_nrmse(s2.image), s2,
                    {"stage1_valid": s1.valid},
                ))

        Lphi, phi_stats = phi12_laplacian(x1, x2, n)
        for alpha in ALPHAS:
            for beta in BETAS:
                s = solve_quadratic(systr, alpha, beta, Lphi)
                records.append(candidate_record(
                    "OLD_PHI12_LAPLACIAN", {"alpha": alpha, "beta": beta}, fold,
                    nrmse(Aval @ s.image, bval) if s.valid else float("inf"),
                    systr.data_nrmse(s.image), s,
                    {"partial_alpha": partial_alpha, **phi_stats},
                ))

        valid_baseline_vals = [
            r["val_nrmse"] for r in records
            if r.get("fold") == fold and r.get("method") in BASELINE_METHODS and r.get("valid", False)
        ]
        baseline_envelope = min(valid_baseline_vals) if valid_baseline_vals else float("inf")

        for mu in MUS:
            for lam in LAMBDAS:
                method, cycles = "DBFTC_ONE_CYCLE", 1
                fused, met = closure_cycle(sys1, sys2, x1, x2, mu, lam, cycles)
                val = nrmse(Aval @ fused, bval)
                valid = bool(met["transport_valid"] and np.isfinite(val))
                gate = bool(
                    valid
                    and met["cross_gain_12"] >= CROSS_GAIN_MIN
                    and met["cross_gain_21"] >= CROSS_GAIN_MIN
                    and met["preservation_delta_1"] <= PRESERVATION_DELTA_MAX
                    and met["preservation_delta_2"] <= PRESERVATION_DELTA_MAX
                    and met["holonomy"] <= HOLONOMY_MAX
                    and val <= baseline_envelope * VALIDATION_ENVELOPE_MAX_RATIO
                )
                dummy = SolveResult(
                    fused, 0 if valid else 1, met["transport_seconds"],
                    met["transport_iterations"], met["max_normal_residual"],
                    met["min_update_rel"], valid,
                    "OK" if valid else ";".join(met["failure_reasons"]) or "TRANSPORT_INVALID",
                )
                extra = {k: v for k, v in met.items() if k not in {"path12", "path21"}}
                extra.update({
                    "closure_gate_pass": gate,
                    "validation_baseline_envelope": baseline_envelope,
                    "partial_alpha": partial_alpha,
                })
                records.append(candidate_record(
                    method, {"mu": mu, "lambda": lam, "cycles": cycles}, fold,
                    val if valid else float("inf"), systr.data_nrmse(fused), dummy, extra,
                ))

        fold_summaries.append({
            "fold": fold,
            "angles": {k: [int(x) for x in v] for k, v in fold_info.items() if k != "fold"},
            "partial_alpha": partial_alpha,
            "local_scales": {"O1": sys1.sigma, "O2": sys2.sigma, "train": systr.sigma},
            "baseline_envelope": baseline_envelope,
        })

    # Select the dimensionless one-cycle transport first, then reuse that exact
    # configuration for the more expensive three-cycle closure. This successive
    # design is preregistered and avoids a multiplicative compute advantage.
    selected_dbftc = select_config(records, "DBFTC_ONE_CYCLE", closure=True)
    if selected_dbftc["status"] != "SELECTED":
        raise RuntimeError("No valid DBFTC configuration for second-stage DFIC")
    inherited = selected_dbftc["config"]
    for fold_info in cv_partitions():
        fold = int(fold_info["fold"][0])
        A1, b1 = subset(A, m, fold_info["o1"]); A2, b2 = subset(A, m, fold_info["o2"])
        Atr, btr = subset(A, m, fold_info["train"]); Aval, bval = subset(A, m, fold_info["val"])
        sys1 = make_system(A1, b1, f"fold{fold}-O1", SEED + fold * 100 + 1)
        sys2 = make_system(A2, b2, f"fold{fold}-O2", SEED + fold * 100 + 2)
        systr = make_system(Atr, btr, f"fold{fold}-train", SEED + fold * 100 + 3)
        partial_alpha = fold_summaries[fold]["partial_alpha"]
        p1 = solve_quadratic(sys1, partial_alpha); p2 = solve_quadratic(sys2, partial_alpha)
        fused, met = closure_cycle(sys1, sys2, p1.image, p2.image, inherited["mu"], inherited["lambda"], 3)
        val = nrmse(Aval @ fused, bval)
        valid = bool(p1.valid and p2.valid and met["transport_valid"] and np.isfinite(val))
        envelope = fold_summaries[fold]["baseline_envelope"]
        gate = bool(valid and met["cross_gain_12"] >= CROSS_GAIN_MIN
                    and met["cross_gain_21"] >= CROSS_GAIN_MIN
                    and met["preservation_delta_1"] <= PRESERVATION_DELTA_MAX
                    and met["preservation_delta_2"] <= PRESERVATION_DELTA_MAX
                    and met["holonomy"] <= HOLONOMY_MAX
                    and val <= envelope * VALIDATION_ENVELOPE_MAX_RATIO)
        dummy = SolveResult(fused, 0 if valid else 1, met["transport_seconds"],
                            met["transport_iterations"], met["max_normal_residual"],
                            met["min_update_rel"], valid,
                            "OK" if valid else ";".join(met["failure_reasons"]) or "TRANSPORT_INVALID")
        extra = {k: v for k, v in met.items() if k not in {"path12", "path21"}}
        extra.update({"closure_gate_pass": gate, "validation_baseline_envelope": envelope,
                      "partial_alpha": partial_alpha, "inherited_from_DBFTC": True})
        records.append(candidate_record(
            "DFIC_THREE_CYCLE", {"mu": inherited["mu"], "lambda": inherited["lambda"], "cycles": 3},
            fold, val if valid else float("inf"), systr.data_nrmse(fused), dummy, extra))

    selected = {mth: select_config(records, mth, closure=(mth in CLOSURE_METHODS)) for mth in ALL_METHODS}
    counts = {a: partial_alphas.count(a) for a in ALPHAS}
    final_partial_alpha = min(ALPHAS, key=lambda a: (-counts[a], a))
    return records, {"selected": selected, "partial_alpha": final_partial_alpha}, {"folds": fold_summaries}


def fit_final_method(method: str, config: dict[str, float], A: sp.csr_matrix, m: np.ndarray,
                     non_test: np.ndarray, o1_angles: np.ndarray, o2_angles: np.ndarray,
                     partial_alpha: float, n: int) -> tuple[np.ndarray, dict[str, Any]]:
    Atr, btr = subset(A, m, non_test)
    A1, b1 = subset(A, m, o1_angles)
    A2, b2 = subset(A, m, o2_angles)
    systr = make_system(Atr, btr, "final-train", SEED + 800)
    sys1 = make_system(A1, b1, "final-O1", SEED + 801)
    sys2 = make_system(A2, b2, "final-O2", SEED + 802)
    L_fixed = build_laplacian(n)

    if method == "JOINT_TIKHONOV":
        s = solve_quadratic(systr, config["alpha"])
        return s.image, solve_meta(s) | {"operator_scale": systr.sigma}
    if method == "FIXED_LAPLACIAN":
        s = solve_quadratic(systr, config["alpha"], config["beta"], L_fixed)
        return s.image, solve_meta(s) | {"operator_scale": systr.sigma}
    if method in {"SELF_ADAPTIVE_ONCE", "IRLS2"}:
        pre = solve_quadratic(systr, config["alpha"])
        L0 = edge_laplacian(pre.image, n)
        s1 = solve_quadratic(systr, config["alpha"], config["beta"], L0,
                             x0=pre.image, require_update=True)
        if method == "SELF_ADAPTIVE_ONCE":
            return s1.image, solve_meta(s1) | {"operator_scale": systr.sigma, "pre_valid": pre.valid,
                                              "seconds": pre.seconds + s1.seconds,
                                              "iterations": pre.iterations + s1.iterations}
        L1 = edge_laplacian(s1.image, n)
        s2 = solve_quadratic(systr, config["alpha"], config["beta"], L1,
                             x0=s1.image, require_update=True)
        return s2.image, solve_meta(s2) | {"operator_scale": systr.sigma,
                                     "pre_valid": pre.valid, "stage1_valid": s1.valid,
                                     "seconds": pre.seconds + s1.seconds + s2.seconds,
                                     "iterations": pre.iterations + s1.iterations + s2.iterations}

    p1 = solve_quadratic(sys1, partial_alpha)
    p2 = solve_quadratic(sys2, partial_alpha)
    if not (p1.valid and p2.valid):
        raise RuntimeError(f"Final partial solves invalid for {method}")
    x1, x2 = p1.image, p2.image
    if method == "OLD_PHI12_LAPLACIAN":
        L, stats = phi12_laplacian(x1, x2, n)
        s = solve_quadratic(systr, config["alpha"], config["beta"], L)
        return s.image, solve_meta(s) | stats | {"operator_scale": systr.sigma}
    if method in CLOSURE_METHODS:
        fused, met = closure_cycle(sys1, sys2, x1, x2, config["mu"], config["lambda"], int(config["cycles"]))
        valid = bool(met["transport_valid"])
        meta = {k: v for k, v in met.items() if k not in {"path12", "path21"}}
        meta.update({
            "valid": valid,
            "reason": "OK" if valid else ";".join(met["failure_reasons"]) or "TRANSPORT_INVALID",
            "partial_O1_valid": p1.valid,
            "partial_O2_valid": p2.valid,
            "partial_seconds": p1.seconds + p2.seconds,
            "partial_iterations": p1.iterations + p2.iterations,
            "seconds": p1.seconds + p2.seconds + met["transport_seconds"],
            "iterations": p1.iterations + p2.iterations + met["transport_iterations"],
            "operator_scale_O1": sys1.sigma,
            "operator_scale_O2": sys2.sigma,
        })
        return fused, meta
    raise ValueError(method)


def evaluate_masks(A: sp.csr_matrix, m: np.ndarray, x: np.ndarray) -> dict[str, Any]:
    per_mask = {}
    for name, angles in TEST_MASKS.items():
        At, bt = subset(A, m, angles)
        pred = At @ x
        per_mask[name] = {
            "angles": [int(a) for a in angles],
            "nrmse": nrmse(pred, bt),
            "correlation": correlation(pred, bt),
        }
    vals = np.array([v["nrmse"] for v in per_mask.values()])
    return {
        "per_mask": per_mask,
        "median_nrmse": float(np.median(vals)),
        "mean_nrmse": float(np.mean(vals)),
        "worst_nrmse": float(np.max(vals)),
    }


def save_montage(path: Path, images: dict[str, np.ndarray], n: int) -> None:
    names = list(images)
    cols = 3
    rows = math.ceil(len(names) / cols)
    finite = np.concatenate([x[np.isfinite(x)] for x in images.values()])
    vmin, vmax = np.percentile(finite, [1, 99])
    fig, axes = plt.subplots(rows, cols, figsize=(12, 4 * rows))
    axes_arr = np.atleast_1d(axes).ravel()
    for ax, name in zip(axes_arr, names):
        ax.imshow(images[name].reshape((n, n), order="F"), cmap="gray", vmin=vmin, vmax=vmax)
        ax.set_title(name); ax.axis("off")
    for ax in axes_arr[len(names):]:
        ax.axis("off")
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def main() -> int:
    np.random.seed(SEED)
    root = Path(os.environ.get("G12_WORKDIR", "g12_work")).resolve()
    data_dir, results_dir = root / "data", root / "results"
    data_dir.mkdir(parents=True, exist_ok=True); results_dir.mkdir(parents=True, exist_ok=True)
    data_path = data_dir / "LotusData128.mat"
    download_exact(data_path)
    if hash_file(data_path, "md5") != EXPECTED_MD5:
        raise RuntimeError("Checksum gate failed")
    A, m, metadata, loader = load_fips_mat(data_path)
    if not np.isfinite(A.data).all() or not np.isfinite(m).all():
        raise RuntimeError("Non-finite values found; silent imputation is forbidden")

    file_size = data_path.stat().st_size
    audit = {
        "program_id": PROGRAM_ID,
        "doi": UPSTREAM_DOI,
        "download_url": DATA_URL,
        "file": data_path.name,
        "size_bytes": file_size,
        "expected_size_bytes": EXPECTED_SIZE,
        "size_matches_expected": file_size == EXPECTED_SIZE,
        "md5": hash_file(data_path, "md5"),
        "expected_md5": EXPECTED_MD5,
        "sha256": hash_file(data_path, "sha256"),
        "loader": loader,
        "A_shape": list(A.shape),
        "A_nnz": int(A.nnz),
        "m_shape": list(m.shape),
        "finite_A": bool(np.isfinite(A.data).all()),
        "finite_m": bool(np.isfinite(m).all()),
        "missingness": 0,
        "silent_imputation": False,
        "mat_metadata": metadata,
        "test_masks": {k: [int(x) for x in v] for k, v in TEST_MASKS.items()},
    }
    write_json(results_dir / "DATA_AUDIT.json", audit)

    records, selection, folds = fit_cv(A, m, N)
    selected = selection["selected"]
    for method in ALL_METHODS:
        if selected[method]["status"] != "SELECTED":
            raise RuntimeError(f"No valid configuration for required method {method}: {selected[method]}")

    test_angles = all_test_angles()
    non_test = np.array([a for a in range(N_ANGLES) if a not in set(test_angles.tolist())], dtype=int)
    o1_final, o2_final = non_test[::2], non_test[1::2]

    images: dict[str, np.ndarray] = {}
    final: dict[str, Any] = {}
    for method in ALL_METHODS:
        config = selected[method]["config"]
        image, meta = fit_final_method(method, config, A, m, non_test, o1_final, o2_final,
                                       selection["partial_alpha"], N)
        images[method] = image
        final[method] = {
            "config": config,
            "cv_median_nrmse": selected[method]["median_val_nrmse"],
            "closure_pass_count": selected[method].get("closure_pass_count", 0),
            "fit_meta": meta,
            "test": evaluate_masks(A, m, image),
        }

    baseline_rank = sorted(BASELINE_METHODS, key=lambda mth: final[mth]["test"]["median_nrmse"])
    strongest_baseline = baseline_rank[0]
    preselected_baseline = min(BASELINE_METHODS, key=lambda mth: selected[mth]["score"])

    closure_adjudications = {}
    for method in CLOSURE_METHODS:
        candidate = final[method]
        valid = bool(candidate["fit_meta"].get("valid", False))
        cv_pass = int(candidate["closure_pass_count"])
        costs = float(candidate["fit_meta"].get("seconds", float("inf")))
        baseline_cost = float(final[strongest_baseline]["fit_meta"].get("seconds", 1e-12))
        cost_ratio = costs / max(baseline_cost, 1e-12)
        mask_gains = {}
        wins = losses = 0
        for mask in TEST_MASKS:
            c = candidate["test"]["per_mask"][mask]["nrmse"]
            b = final[strongest_baseline]["test"]["per_mask"][mask]["nrmse"]
            gain = (b - c) / max(b, 1e-15)
            mask_gains[mask] = float(gain)
            wins += gain >= SUPPORT_MARGIN
            losses += gain <= -SUPPORT_MARGIN
        median_gain = ((final[strongest_baseline]["test"]["median_nrmse"]
                        - candidate["test"]["median_nrmse"])
                       / final[strongest_baseline]["test"]["median_nrmse"])
        false_closure = bool(cv_pass >= 2 and losses >= 2 and median_gain <= -FALSE_CLOSURE_MARGIN)
        if not valid:
            outcome = "ABSTAIN_SOLVER_OR_TRANSPORT_INVALID"
            state = "0_NO_CLOSURE"
        elif cv_pass < 2:
            outcome = "ABSTAIN_CV_CLOSURE_GATE_NOT_MET"
            state = "0_NO_CLOSURE"
        elif wins >= 2 and median_gain >= SUPPORT_MARGIN and cost_ratio <= MAX_COST_RATIO:
            outcome = "LOCAL_SUPPORT_IN_THIRD_OBJECT"
            state = "+0_PROTOFORM"
        elif losses >= 2:
            outcome = "REFUTED_IN_THIRD_OBJECT"
            state = "PSEUDOFORM_FALSE_OR_INFERIOR_CLOSURE" if false_closure else "0_NO_CLOSURE"
        else:
            outcome = "BASELINE_EQUIVALENT"
            state = "+0_PROTOFORM_UNRESOLVED"
        closure_adjudications[method] = {
            "outcome": outcome,
            "quaternary_state": state,
            "valid": valid,
            "cv_closure_pass_count": cv_pass,
            "strongest_baseline": strongest_baseline,
            "preselected_baseline": preselected_baseline,
            "median_gain_vs_strongest_baseline": float(median_gain),
            "mask_gains": mask_gains,
            "wins_over_2pct": int(wins),
            "losses_over_2pct": int(losses),
            "cost_ratio_vs_strongest_baseline": float(cost_ratio),
            "false_closure": false_closure,
        }

    A1f, _ = subset(A, m, o1_final)
    A2f, _ = subset(A, m, o2_final)
    fisher = randomized_fisher_audit(A1f, A2f, SEED + 900)
    write_json(results_dir / "FISHER_SPECTRAL_AUDIT.json", fisher)

    # Preserve all CV records.
    cv_path = results_dir / "CV_RECORDS.csv"
    fieldnames = sorted({k for r in records for k in r if k not in {"config"}} | {"config_json"})
    with cv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for r in records:
            row = {k: v for k, v in r.items() if k != "config"}
            row["config_json"] = json.dumps(r.get("config", {}), sort_keys=True)
            writer.writerow(row)

    result = {
        "program_id": PROGRAM_ID,
        "status": "EXECUTED_THIRD_OBJECT_MATERIAL_GATE",
        "dataset": audit,
        "folds": folds,
        "selection": selection,
        "final": final,
        "baseline_ranking_by_external_median": baseline_rank,
        "strongest_external_baseline": strongest_baseline,
        "preselected_cv_baseline": preselected_baseline,
        "closure_adjudications": closure_adjudications,
        "fisher_audit_file": "FISHER_SPECTRAL_AUDIT.json",
        "authority": "NONE",
        "promotion": "BLOCKED",
        "canonical_TOS": "NOT_TESTED",
        "CFL_general": "NOT_ADJUDICATED",
        "H6_euclideanization": "NOT_TESTED_SINGLE_EUCLIDEANIZED_OPERATOR",
    }
    write_json(results_dir / "RESULTS.json", result)
    save_montage(results_dir / "ALL_METHODS_MONTAGE.png", images, N)

    manifest = {
        "program_id": PROGRAM_ID,
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "dataset_sha256": audit["sha256"],
        "results_sha256": hash_file(results_dir / "RESULTS.json"),
        "fisher_sha256": hash_file(results_dir / "FISHER_SPECTRAL_AUDIT.json"),
        "cv_sha256": hash_file(cv_path),
        "seed": SEED,
    }
    write_json(results_dir / "RUN_MANIFEST.json", manifest)

    lines = [
        "# CFL–UEP G1.2 Dimensionless Closure — execution report",
        "",
        f"Dataset: LotusData128.mat; SHA-256 `{audit['sha256']}`.",
        "",
        f"Strongest external baseline: `{strongest_baseline}`.",
        f"Preselected CV baseline: `{preselected_baseline}`.",
        "",
        "## External median NRMSE",
        "",
    ]
    for method in sorted(ALL_METHODS, key=lambda mth: final[mth]["test"]["median_nrmse"]):
        lines.append(f"- `{method}`: {final[method]['test']['median_nrmse']:.8f}")
    lines += ["", "## Closure adjudications", ""]
    for method, adj in closure_adjudications.items():
        lines.append(f"- `{method}`: `{adj['outcome']}` / `{adj['quaternary_state']}`; median gain {adj['median_gain_vs_strongest_baseline']:.6f}.")
    lines += [
        "",
        "## Scope",
        "",
        "This gate tests dimensionless numerical closure on a third measured physical object.",
        "It does not canonize TOS\\, CFL, non-Euclidean ontology, or domain-general closure.",
    ]
    (results_dir / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(json.dumps({
        "strongest_baseline": strongest_baseline,
        "external_median_nrmse": {mth: final[mth]["test"]["median_nrmse"] for mth in ALL_METHODS},
        "closure": closure_adjudications,
        "fisher_rowspace_novelty": fisher["rowspace_novelty"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
