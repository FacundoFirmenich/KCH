#!/usr/bin/env python3
from __future__ import annotations
import json, math, hashlib, random, statistics, time, os, itertools, sys
from pathlib import Path
from collections import Counter, defaultdict
import numpy as np
from scipy.optimize import linprog, minimize

PROGRAM_ID='CFL-UEP-G3.6-OPEN-INTERVENTION-GRAMMAR-GENESIS'
VERSION='0.1.0'; SEED=360928
DIMS={'graph':5,'algebra':4,'number':2,'mechanics':4}; DOMAINS=tuple(DIMS)
P=8
METHODS=('EXACT_CONTINUOUS_CLAIM_EIG','D_OPTIMAL_LINEARIZED','GRADIENT_SOFT_MI','BEAM_PROGRAM_SYNTHESIS','MDL_DISAGREEMENT_DESIGN','RANDOM_FEASIBLE_INTERVENTION','TOS_NO_PHI','TOS_NO_O3','TOS_FULL_INTERVENTION_GENESIS')

def canon(v):
    if isinstance(v,dict): return {str(k):canon(v[k]) for k in sorted(v,key=str)}
    if isinstance(v,(list,tuple)): return [canon(q) for q in v]
    if isinstance(v,np.ndarray): return canon(v.tolist())
    if isinstance(v,np.generic): return v.item()
    if isinstance(v,float): return None if not math.isfinite(v) else float(v)
    return v

def cjson(v): return json.dumps(canon(v),sort_keys=True,separators=(',',':'))
def whash(v): return hashlib.sha256(cjson(v).encode()).hexdigest()
def write_json(p,v): p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(canon(v),indent=2,sort_keys=True)+'\n')
def write_jsonl(p,rows):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w') as f:
        for r in rows:f.write(cjson(r)+'\n')

def valid(domain,x):
    if domain=='graph': return len(x)==5 and all(q in (0,1) for q in x)
    if domain=='algebra': return len(x)==4 and x[0]!=x[1] and x[2]!=0 and max(abs(q) for q in x)<=30
    if domain=='number': return len(x)==2 and x[0]>x[1]>0 and x[0]<=40
    if domain=='mechanics': return len(x)==4 and min(x)>0 and max(x)<=30
    return False

def ell(domain,x):
    if domain=='graph': return int(x[-1])&1
    if domain=='algebra': return int(x[-1])
    if domain=='number': return int(x[0]-x[1]-5)
    if domain=='mechanics': return int(x[-1]-1)

def sample_on_history(domain,rng):
    if domain=='graph': return tuple([rng.randint(0,1) for _ in range(4)]+[0])
    if domain=='algebra':
        while True:
            x=(rng.randint(-3,1),rng.randint(2,6),rng.choice([-2,-1,1,2]),0)
            if valid(domain,x): return x
    if domain=='number':
        n=rng.randint(1,10); return (n+5,n)
    if domain=='mechanics': return tuple([rng.randint(1,6) for _ in range(3)]+[1])

def sample_probe(domain,rng,zero=False):
    if zero:return sample_on_history(domain,rng)
    for _ in range(500):
        if domain=='graph': x=tuple(rng.randint(0,1) for _ in range(5))
        elif domain=='algebra': x=(rng.randint(-4,2),rng.randint(2,7),rng.choice([-2,-1,1,2]),rng.choice([-3,-2,-1,1,2,3]))
        elif domain=='number':
            n=rng.randint(1,8); gap=rng.choice([2,3,4,6,7,8]);x=(n+gap,n)
        else: x=tuple(rng.randint(1,6) for _ in range(4))
        if valid(domain,x) and ell(domain,x)!=(0 if domain!='graph' else 0):return x
    raise RuntimeError('probe')

def apply_model(model,x):
    d=len(x); y=list(x); L=ell(model['domain'],x)
    if model['domain']=='graph':
        if model['alpha']&1:y[model['out']]=int(y[model['out']])^(L&1)
    else:
        y[model['out']]=int(y[model['out']])+int(model['alpha'])*int(L)
    return tuple(y)

def model_family(m): return m['family']
def make_models(domain):
    d=DIMS[domain]; mods=[{'domain':domain,'out':0,'alpha':0,'family':'BASE','ontology_id':'BASE'}]
    if domain=='graph':
        for j in range(min(d,4)):mods.append({'domain':domain,'out':j,'alpha':1,'family':f'OUT{j}','ontology_id':f'XOR_L_TO_{j}'})
    else:
        # Small exact perturbations; family groups by output coordinate.
        for j in range(min(d,4)):
            mods.append({'domain':domain,'out':j,'alpha':1,'family':f'OUT{j}','ontology_id':f'PLUS_L_TO_{j}'})
        if d>=4: mods.append({'domain':domain,'out':0,'alpha':2,'family':'OUT0','ontology_id':'PLUS_2L_TO_0'})
    return mods[:6]

def generate_task(domain,regime,seed,lane='CONTINUOUS'):
    rng=random.Random(seed); models=make_models(domain); truth_idx=0
    hist=[sample_on_history(domain,rng) for _ in range(DIMS[domain]+1)]
    # Exact compatibility certificate: all models agree on O1/O2 history.
    hist_outputs=[[apply_model(m,x) for x in hist] for m in models]
    assert all(v==hist_outputs[0] for v in hist_outputs)
    target=sample_probe(domain,rng,zero=(regime=='A')) if regime!='C' else sample_probe(domain,rng,zero=False)
    target_preds=[apply_model(m,target) for m in models]
    if regime=='A': assert len(set(target_preds))==1
    if regime=='B': assert len(set(target_preds))>=2
    if regime=='C': models=models[:1];target_preds=target_preds[:1]
    if regime=='N':
        base=models[0];models=[{**base,'family':f'GAUGE{i}','ontology_id':f'GAUGE_EQUIV_{i}'} for i in range(3)];target_preds=[apply_model(m,target) for m in models]
    probes=[]
    for j in range(P): probes.append(sample_probe(domain,rng,zero=False))
    S=np.zeros((len(models),P),float)
    for i,m in enumerate(models):
        for j,x in enumerate(probes):
            y=apply_model(m,x); k=j%DIMS[domain]
            S[i,j]=float(y[k])
    # Model-symmetric scaling.
    med=np.median(S,axis=0); scale=np.std(S,axis=0);scale=np.where(scale<1e-9,1.0,scale); Z=(S-med)/scale
    return {'task_id':f'g36_{domain}_{regime}_{lane}_{seed}','domain':domain,'regime':regime,'lane':lane,'models':models,'truth_idx':truth_idx,'history':hist,'target':target,'target_preds':target_preds,'probes':probes,'S':Z}

def entropy(vals):
    n=len(vals)
    if n<=1:return 0.0
    c=Counter(vals);return -sum((v/n)*math.log2(v/n) for v in c.values())

def cond_entropy(labels,bits):
    n=len(labels);by=defaultdict(list)
    for l,b in zip(labels,bits):by[b].append(l)
    return sum(len(v)/n*entropy(v) for v in by.values())

def bits_for(S,w,b):return tuple(int(z>=0) for z in S@w+b)
def stats(task,bits):
    mods=task['models']; fam=[model_family(m) for m in mods]; tar=[cjson(v) for v in task['target_preds']]
    return {'model_ig':entropy(bits),'family_ig':entropy(fam)-cond_entropy(fam,bits),'target_ig':entropy(tar)-cond_entropy(tar,bits),'distinct_bits':len(set(bits))}

def key(task,st,complexity=0):
    if task['regime']=='B':return (st['target_ig'],st['family_ig'],st['model_ig'],-complexity)
    return (st['family_ig'],st['model_ig'],st['target_ig'],-complexity)

def norm_plane(w,b):
    w=np.asarray(w,float);n=np.linalg.norm(w)
    if n<1e-12:return None
    w=w/n;b=float(b)/n;nz=np.flatnonzero(np.abs(w)>1e-10)
    if len(nz) and w[nz[0]]<0:w=-w;b=-b
    return w,b

def sep_lp(S,bits):
    n,p=S.shape;y=np.asarray([1 if q else -1 for q in bits],float)
    c=np.r_[np.ones(2*p),0.0];A=[];rhs=[]
    for i in range(n):A.append(np.r_[-y[i]*S[i],y[i]*S[i],-y[i]]);rhs.append(-1.0)
    r=linprog(c,A_ub=np.asarray(A),b_ub=np.asarray(rhs),bounds=[(0,None)]*(2*p)+[(None,None)],method='highs')
    if not r.success:return None
    return norm_plane(r.x[:p]-r.x[p:2*p],r.x[-1])

def exact_design(task):
    S=task['S'];n=len(task['models']);best=None;evals=0
    if n<=1:return None,{'reason':'singleton','evals':0}
    for mask in range(1,1<<(n-1)):
        bits=[0]+[((mask>>(i-1))&1) for i in range(1,n)]
        if len(set(bits))<2:continue
        q=sep_lp(S,bits);evals+=1
        if q is None:continue
        w,b=q;actual=bits_for(S,w,b);st=stats(task,actual);comp=float(np.sum(np.abs(w)))
        kk=key(task,st,comp)
        if best is None or kk>best[0]:best=(kk,q,st,comp)
    if best is None:return None,{'reason':'no informative feasible plane','evals':evals}
    return best[1],{'evals':evals,'stats':best[2],'complexity':best[3]}

def threshold_best(task,w,mdl=0):
    S=task['S'];z=S@w;u=sorted(set(float(x) for x in z))
    if len(u)<2:return None
    best=None
    for a,bv in zip(u[:-1],u[1:]):
        b=-(a+bv)/2;st=stats(task,bits_for(S,w,b));comp=float(np.sum(np.abs(w)))+mdl*np.count_nonzero(w)
        kk=key(task,st,comp)
        if best is None or kk>best[0]:best=(kk,(w,b),st)
    return best

def topvec(C):
    C=np.atleast_2d(np.asarray(C,float));v,U=np.linalg.eigh(C);w=U[:,np.argmax(v)];return None if np.linalg.norm(w)<1e-12 else w/np.linalg.norm(w)

def tos_design(task,phi=True):
    S=task['S'];mods=task['models'];reg=task['regime']
    if len(mods)<=1 or np.max(np.var(S,axis=0))<1e-12:return None,{'reason':'no reducible fiber'}
    if phi:
        labels=[cjson(v) for v in task['target_preds']] if reg=='B' else [model_family(m) for m in mods]
        G=defaultdict(list)
        for i,l in enumerate(labels):G[l].append(S[i])
        cents=np.array([np.mean(v,axis=0) for v in G.values()])
        C=np.cov(cents,rowvar=False,bias=True) if len(cents)>1 else np.cov(S,rowvar=False,bias=True)
        C=np.atleast_2d(C)+0.1*np.atleast_2d(np.cov(S,rowvar=False,bias=True))
    else:C=np.atleast_2d(np.cov(S,rowvar=False,bias=True))
    w=topvec(C)
    if w is None:return None,{'reason':'zero disagreement'}
    bt=threshold_best(task,w)
    if bt is None:return None,{'reason':'projection constant'}
    return bt[1],{'stats':bt[2],'complexity':float(np.sum(np.abs(w)))}

def dopt(task):
    S=task['S'];C=np.atleast_2d(np.cov(S,rowvar=False,bias=True));w=topvec(C)
    if w is None:return None,{'reason':'zero'}
    bt=threshold_best(task,w);return (bt[1],{'stats':bt[2]}) if bt else (None,{'reason':'constant'})

def grammar_weights(p):
    out=[]
    for k in (1,2,3):
        for idx in itertools.combinations(range(p),k):
            for signs in itertools.product((-1.,1.),repeat=k):
                w=np.zeros(p)
                for j,s in zip(idx,signs):w[j]=s
                w/=np.linalg.norm(w);out.append(w)
    return out

def beam(task,mdl=False):
    best=None;ev=0
    for w in grammar_weights(task['S'].shape[1]):
        bt=threshold_best(task,w,0.05 if mdl else 0);ev+=1
        if bt and (best is None or bt[0]>best[0]):best=bt
    if best is None:return None,{'reason':'none','evals':ev}
    return best[1],{'stats':best[2],'evals':ev,'complexity':float(np.sum(np.abs(best[1][0])))}

def soft_obj(theta,task):
    S=task['S'];p=S.shape[1];q=norm_plane(theta[:p],theta[-1])
    if q is None:return 999
    w,b=q;z=np.clip(S@w+b,-20,20);pr=1/(1+np.exp(-5*z))
    labels=[cjson(v) for v in task['target_preds']] if task['regime']=='B' else [model_family(m) for m in task['models']]
    # soft claim separation: between label-group mean response probabilities + total variance
    G=defaultdict(list)
    for l,r in zip(labels,pr):G[l].append(r)
    means=np.array([np.mean(v) for v in G.values()]);return -(3*np.var(means)+np.var(pr))

def grad_design(task,seed):
    p=task['S'].shape[1];rng=np.random.default_rng(seed);best=None
    for _ in range(4):
        r=minimize(soft_obj,np.r_[rng.normal(size=p),rng.normal()],args=(task,),method='L-BFGS-B',options={'maxiter':80})
        if best is None or r.fun<best.fun:best=r
    q=norm_plane(best.x[:p],best.x[-1]);
    if q is None:return None,{'reason':'zero'}
    st=stats(task,bits_for(task['S'],*q));return q,{'stats':st,'complexity':float(np.sum(np.abs(q[0])))}

def random_design(task,seed):
    rng=np.random.default_rng(seed);w=rng.normal(size=task['S'].shape[1]);w/=np.linalg.norm(w);bt=threshold_best(task,w)
    if not bt:return None,{'reason':'constant'}
    return bt[1],{'stats':bt[2]}

def realize(task,q):
    n=len(task['models']);fam=[model_family(m) for m in task['models']];tar=[cjson(v) for v in task['target_preds']]
    if q is None:post=list(range(n));truthbit=None
    else:
        bits=bits_for(task['S'],*q);truthbit=bits[task['truth_idx']];post=[i for i,b in enumerate(bits) if b==truthbit]
    pf=len(set(fam));pt=len(set(tar));
    return {'pre_models':n,'post_models':len(post),'model_reduction':1-len(post)/n if n else 0,'pre_families':pf,'post_families':len(set(fam[i] for i in post)),'family_reduction':1-len(set(fam[i] for i in post))/pf if pf else 0,'pre_targets':pt,'post_targets':len(set(tar[i] for i in post)),'target_resolved':len(set(tar[i] for i in post))==1,'model_resolved':len(post)==1,'truth_retained':task['truth_idx'] in post,'truth_bit':truthbit}

def run_method(task,m):
    seed=int(hashlib.sha256((task['task_id']+m).encode()).hexdigest()[:16],16)
    if m=='EXACT_CONTINUOUS_CLAIM_EIG':q,meta=exact_design(task)
    elif m=='D_OPTIMAL_LINEARIZED':q,meta=dopt(task)
    elif m=='GRADIENT_SOFT_MI':q,meta=grad_design(task,seed)
    elif m=='BEAM_PROGRAM_SYNTHESIS':q,meta=beam(task,False)
    elif m=='MDL_DISAGREEMENT_DESIGN':q,meta=beam(task,True)
    elif m=='RANDOM_FEASIBLE_INTERVENTION':q,meta=random_design(task,seed)
    elif m=='TOS_NO_PHI':q,meta=tos_design(task,False)
    elif m=='TOS_NO_O3':q,meta=None,{'reason':'withheld'}
    elif m=='TOS_FULL_INTERVENTION_GENESIS':q,meta=tos_design(task,True)
    return q,meta,realize(task,q)

def make_stress(task,seed):
    rng=np.random.default_rng(seed);S0=task['S']
    for _ in range(100):
        Q,_=np.linalg.qr(rng.normal(size=(P,P)));S=S0@Q;tt={**task,'S':S,'lane':'HELDOUT_COMPOSITION'}
        ex,_=exact_design(tt)
        if ex is None:continue
        exs=key(tt,stats(tt,bits_for(S,*ex)),0)[:3]
        bestsingle=(0,0,0)
        for j in range(P):
            w=np.zeros(P);w[j]=1;bt=threshold_best(tt,w)
            if bt:bestsingle=max(bestsingle,key(tt,bt[2],0)[:3])
        if bestsingle<exs:return tt,{ 'single_channel_score':bestsingle,'synthesized_score':exs,'rotation_hash':hashlib.sha256(Q.tobytes()).hexdigest() }
    return {**task,'lane':'HELDOUT_COMPOSITION'}, {'stress_generation':'fallback_no_strict_gap'}

def dataset():
    tasks=[];seed=1000000
    for di,d in enumerate(DOMAINS):
        for i in range(6):tasks.append(generate_task(d,'A',seed+di*1000+i))
        for i in range(6):tasks.append(generate_task(d,'B',seed+di*1000+100+i))
        for i in range(3):tasks.append(generate_task(d,'C',seed+di*1000+200+i))
        for i in range(2):tasks.append(generate_task(d,'N',seed+di*1000+300+i,lane='NULL'))
    stress=[];met=[]
    for di,d in enumerate(('algebra','number','mechanics')):
        for reg in ('A','B'):
            for i in range(2):
                t=generate_task(d,reg,1200000+di*1000+(0 if reg=='A' else 100)+i);t,m=make_stress(t,SEED+di*100+i);stress.append(t);met.append((t['task_id'],m))
    return tasks+stress,dict(met)

def aggregate(rows,lane=None):
    out={}
    for m in METHODS:
        z=[r for r in rows if r['method']==m and r['regime'] in ('A','B') and (lane is None or r['lane']==lane)]
        if not z:continue
        b=[r for r in z if r['regime']=='B']
        out[m]={'n':len(z),'mean_expected_primary_ig':float(np.mean([r['expected_primary_ig'] for r in z if r['expected_primary_ig'] is not None])),'mean_model_reduction':float(np.mean([r['model_reduction'] for r in z])),'mean_family_reduction':float(np.mean([r['family_reduction'] for r in z])),'target_resolution_B':float(np.mean([r['target_resolved'] for r in b])) if b else None,'model_collapse_rate':float(np.mean([r['model_resolved'] for r in z])),'truth_retention':float(np.mean([r['truth_retained'] for r in z])),'intervention_rate':float(np.mean([r['queried'] for r in z]))}
    return out

def paired_boot(rows,a,b,lane='CONTINUOUS',metric='expected_primary_ig',nboot=5000):
    A={(r['task_id'],r['lane']):r for r in rows if r['method']==a and r['regime'] in ('A','B') and r['lane']==lane};B={(r['task_id'],r['lane']):r for r in rows if r['method']==b and r['regime'] in ('A','B') and r['lane']==lane};ks=sorted(set(A)&set(B));d=np.array([A[k][metric]-B[k][metric] for k in ks],dtype=float)
    rng=np.random.default_rng(SEED);boot=[float(np.mean(rng.choice(d,len(d),replace=True))) for _ in range(nboot)]
    return {'n':len(d),'delta':float(np.mean(d)),'ci':[float(np.quantile(boot,.025)),float(np.quantile(boot,.975))]}

def main():
    out=Path(os.environ.get('G36_WORKDIR','/mnt/data/CFL_G3_6_INTERVENTION_RUN'));out.mkdir(parents=True,exist_ok=True)
    tasks,stressmeta=dataset();truth=[];rows=[]
    print('TASKS',len(tasks),flush=True)
    for ti,t in enumerate(tasks):
        truth.append({'task_id':t['task_id'],'domain':t['domain'],'regime':t['regime'],'lane':t['lane'],'fiber_size':len(t['models']),'target_classes':len(set(cjson(v) for v in t['target_preds'])),'signature_hash':hashlib.sha256(np.asarray(t['S'],np.float64).tobytes()).hexdigest(),'stress_meta':stressmeta.get(t['task_id'])})
        if ti%10==0:print('task',ti,t['domain'],t['regime'],t['lane'],flush=True)
        for m in METHODS:
            ts=time.perf_counter();q,meta,rr=run_method(t,m);elapsed=(time.perf_counter()-ts)*1000
            st=(meta or {}).get('stats') or {}
            primary_ig=(st.get('target_ig') if t['regime']=='B' else st.get('family_ig')) if t['regime'] in ('A','B') else None
            rows.append({'task_id':t['task_id'],'domain':t['domain'],'regime':t['regime'],'lane':t['lane'],'method':m,'queried':q is not None,'runtime_ms':elapsed,'complexity_l1':float(np.sum(np.abs(q[0]))) if q is not None else None,'plane_hash':whash({'w':np.round(q[0],10).tolist(),'b':round(float(q[1]),10)}) if q is not None else None,'expected_primary_ig':primary_ig,'meta':meta,**rr})
    write_jsonl(out/'evidence'/'TRUTH_MANIFEST.jsonl',truth);write_jsonl(out/'results'/'INTERVENTION_RESULTS.jsonl',rows)
    allagg=aggregate(rows);mainagg=aggregate(rows,'CONTINUOUS');stressagg=aggregate(rows,'HELDOUT_COMPOSITION')
    null={m:{'n':len(z:=[r for r in rows if r['method']==m and r['regime']=='N']),'correct_abstention_rate':float(np.mean([not r['queried'] for r in z])) if z else None,'mean_model_reduction':float(np.mean([r['model_reduction'] for r in z])) if z else None} for m in METHODS}
    tos='TOS_FULL_INTERVENTION_GENESIS'; exact='EXACT_CONTINUOUS_CLAIM_EIG';boot=paired_boot(rows,tos,exact,metric='expected_primary_ig')
    # realized outcome identity is stricter than score tie but invariant to hyperplane scale/gauge.
    A={(r['task_id'],r['lane']):r for r in rows if r['method']==tos and r['regime'] in ('A','B')};B={(r['task_id'],r['lane']):r for r in rows if r['method']==exact and r['regime'] in ('A','B')};ids=[]
    for k in sorted(set(A)&set(B)):ids.append((A[k]['post_models'],A[k]['post_families'],A[k]['post_targets'])==(B[k]['post_models'],B[k]['post_families'],B[k]['post_targets']))
    support=boot['delta']>=.02 and boot['ci'][0]>0
    if support: outcome='G3_6_LOCAL_SUPPORT'
    elif boot['ci'][1] < 0: outcome='G3_6_INFERIOR_TO_EXACT_CONTINUOUS_DESIGN'
    else: outcome='G3_6_BASELINE_EQUIVALENT'
    adj={'program_id':PROGRAM_ID,'version':VERSION,'material_gate':'PASS_LOCAL','outcome':outcome,'intervention_genesis_demonstrated':allagg[tos]['mean_model_reduction']>0,'main_lane':{'tos':mainagg[tos],'exact':mainagg[exact],'d_optimal':mainagg['D_OPTIMAL_LINEARIZED'],'gradient_mi':mainagg['GRADIENT_SOFT_MI'],'beam':mainagg['BEAM_PROGRAM_SYNTHESIS'],'random':mainagg['RANDOM_FEASIBLE_INTERVENTION']},'stress_lane':{'tos':stressagg[tos],'exact':stressagg[exact],'random':stressagg['RANDOM_FEASIBLE_INTERVENTION']},'null_lane_tos_correct_abstention_rate':null[tos]['correct_abstention_rate'],'paired_tos_minus_exact_expected_primary_ig':boot,'realized_outcome_identity_rate_tos_exact':float(np.mean(ids)),'benchmark_state':'+0_OPEN_INTERVENTION_GENESIS_BENCHMARK_PROTOFORM','o3_claim_state':'+0_UNREPLICATED' if support else ('0_LOCAL_INFERIOR_TO_EXACT_DESIGN' if outcome=='G3_6_INFERIOR_TO_EXACT_CONTINUOUS_DESIGN' else '0_BASELINE_EQUIVALENT'),'authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED','interpretation':'Complete interventions are continuous hyperplanes synthesized over primitive sensor channels, not selectable items in a finite query pool. The exact matched comparator enumerates all linearly realizable binary partitions of the current model fiber and solves LPs to construct minimum-L1 separators.'}
    write_json(out/'results'/'SUMMARY.json',{'all':allagg,'continuous':mainagg,'heldout_composition':stressagg,'null':null});write_json(out/'results'/'FINAL_ADJUDICATION.json',adj);write_json(out/'results'/'RUN_MANIFEST.json',{'program_id':PROGRAM_ID,'task_n':len(tasks),'row_n':len(rows),'truth_manifest_sha256':hashlib.sha256((out/'evidence'/'TRUTH_MANIFEST.jsonl').read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'adjudication':adj})
    (out/'results'/'REPORT.md').write_text(f"# CFL G3.6 Open Intervention Grammar Genesis\n\nOutcome: **{outcome}**\n\nMain expected claim IG: TOS {mainagg[tos]['mean_expected_primary_ig']:.4f}; exact continuous claim-EIG {mainagg[exact]['mean_expected_primary_ig']:.4f}. Realized model-fiber reduction: TOS {mainagg[tos]['mean_model_reduction']:.4f}; exact {mainagg[exact]['mean_model_reduction']:.4f}; random {mainagg['RANDOM_FEASIBLE_INTERVENTION']['mean_model_reduction']:.4f}. Paired TOS-exact expected-IG delta {boot['delta']:.6f}, 95% CI {boot['ci']}.\n")
    print(json.dumps(adj,indent=2),flush=True)
if __name__=='__main__':main()
