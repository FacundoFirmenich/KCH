#!/usr/bin/env python3
from __future__ import annotations
import dataclasses, hashlib, itertools, json, math, os, random, statistics
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import numpy as np

PROGRAM_ID='CFL-UEP-G4.1-OPEN-OPERATOR-TYPE-ARITY-AND-ALGEBRA-GENESIS'
VERSION='0.1.0'
SEED=410928
N=4
QDOMAIN=tuple(range(16))
UNDEF=16
PERMS=tuple(itertools.permutations(range(N)))
DEV_TYPES=('UNARY_TOTAL_NONBIJ','BINARY_COMM')
PRIVATE_TYPES=('BINARY_NONCOMM','EQUIV_QUOTIENT','GRAPH_NEIGHBOR','HIGHER_CLOSURE')
ALL_TYPES=DEV_TYPES+PRIVATE_TYPES

# ---------- IO ----------
def canon(v):
    if dataclasses.is_dataclass(v): return canon(asdict(v))
    if isinstance(v,dict): return {str(k):canon(v[k]) for k in sorted(v,key=lambda z:str(z))}
    if isinstance(v,(list,tuple)): return [canon(x) for x in v]
    if isinstance(v,set): return sorted(canon(x) for x in v)
    if isinstance(v,np.generic): return v.item()
    if isinstance(v,float): return None if not math.isfinite(v) else float(v)
    return v

def cjson(v): return json.dumps(canon(v),sort_keys=True,separators=(',',':'))
def h(v): return hashlib.sha256(cjson(v).encode()).hexdigest()
def write_json(p:Path,v): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(canon(v),indent=2,sort_keys=True)+'\n')
def write_jsonl(p:Path,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w') as f:
        for r in rows:f.write(cjson(r)+'\n')

@dataclass(frozen=True)
class Model:
    mid:str
    typ:str
    table:tuple[int,...]
    sig:str
    complexity:int

@dataclass
class Task:
    task_id:str
    lane:str
    regime:str
    truth_mid:str
    truth_type:str
    truth_sig:str
    demos:tuple[tuple[int,int],...]
    query_pool:tuple[int,...]
    pre_fiber:tuple[str,...]
    sealed_perm:tuple[int,...]

# ---------- finite structures ----------
def perm_set(mask:int,p):
    out=0
    for i in range(N):
        if mask>>i & 1: out |= 1<<p[i]
    return out

def inv_perm(p):
    z=[0]*N
    for i,j in enumerate(p): z[j]=i
    return tuple(z)

def transform_table(typ,table,p):
    ip=inv_perm(p)
    out=[UNDEF]*16
    if typ=='UNARY_TOTAL_NONBIJ':
        for xo in range(N):
            x=ip[xo]; y=table[x]; out[xo]=p[y]
    elif typ in ('BINARY_COMM','BINARY_NONCOMM'):
        for xo in range(N):
            for yo in range(N):
                x,y=ip[xo],ip[yo]; out[4*xo+yo]=p[table[4*x+y]]
    elif typ=='EQUIV_QUOTIENT':
        for xo in range(N):
            for yo in range(N):
                x,y=ip[xo],ip[yo]; out[4*xo+yo]=table[4*x+y]
    elif typ=='GRAPH_NEIGHBOR':
        for xo in range(N):
            x=ip[xo]; out[xo]=perm_set(table[x],p)
    elif typ=='HIGHER_CLOSURE':
        for So in range(16):
            S=perm_set(So,ip); out[So]=perm_set(table[S],p)
    return tuple(out)

def signature(typ,table):
    # representation-independent semantic class under carrier relabeling.
    best=min(transform_table(typ,table,p) for p in PERMS)
    return h((typ,best))[:20]

def add_model(models,typ,table,complexity):
    table=tuple(map(int,table)); mid=h((typ,table))[:20]; models[mid]=Model(mid,typ,table,signature(typ,table),complexity)

def partitions4():
    # all set partitions represented by block labels canonicalized by first occurrence
    out=[]
    def rec(labels,i,maxlab):
        if i==N:
            out.append(tuple(labels));return
        for lab in range(maxlab+2):
            labels.append(lab);rec(labels,i+1,max(maxlab,lab));labels.pop()
    rec([0],1,0)
    # canonical filter
    keep=[]
    for z in out:
        m={};nxt=0;c=[]
        for a in z:
            if a not in m:m[a]=nxt;nxt+=1
            c.append(m[a])
        c=tuple(c)
        if c not in keep:keep.append(c)
    return keep

def build_universe():
    M={}
    # unary total non-bijective: exhaustive
    for f in itertools.product(range(N),repeat=N):
        if len(set(f))<N:add_model(M,'UNARY_TOTAL_NONBIJ',tuple(f)+(UNDEF,)*12,1+len(set(f)))
    # binary affine families over Z4. BINARY_COMM iff coefficients equal.
    for a,b,c in itertools.product(range(N),repeat=3):
        tab=tuple((a*x+b*y+c)%N for x in range(N) for y in range(N))
        typ='BINARY_COMM' if a==b else 'BINARY_NONCOMM'
        add_model(M,typ,tab,2+int(a!=0)+int(b!=0)+int(c!=0))
    # equivalence relations: exhaustive partitions
    for part in partitions4():
        tab=tuple(int(part[x]==part[y]) for x in range(N) for y in range(N))
        add_model(M,'EQUIV_QUOTIENT',tab,1+len(set(part)))
    # undirected graph neighborhoods: exhaustive
    edges=[(i,j) for i in range(N) for j in range(i+1,N)]
    for bits in range(1<<len(edges)):
        neigh=[0]*N
        for k,(i,j) in enumerate(edges):
            if bits>>k&1:
                neigh[i]|=1<<j;neigh[j]|=1<<i
        tab=tuple(neigh)+(UNDEF,)*12
        add_model(M,'GRAPH_NEIGHBOR',tab,1+bin(bits).count('1'))
    # higher-order closure: deterministic bounded sample of directed reachability closures.
    # This preserves the semantic lane while preventing universe-construction cost from dominating the active gate.
    ded=set(); directed=[(i,j) for i in range(N) for j in range(N) if i!=j]
    rr=random.Random(410928)
    masks=set([0,(1<<len(directed))-1])
    # single edges, simple cycles/chains and a deterministic random panel
    for k in range(len(directed)): masks.add(1<<k)
    while len(masks)<192: masks.add(rr.randrange(1<<len(directed)))
    for bits in sorted(masks):
        reach=[[False]*N for _ in range(N)]
        for i in range(N):reach[i][i]=True
        for k,(i,j) in enumerate(directed):
            if bits>>k&1:reach[i][j]=True
        for k in range(N):
            for i in range(N):
                if reach[i][k]:
                    for j in range(N):reach[i][j]=reach[i][j] or reach[k][j]
        tab=[]
        for mask in range(16):
            out=0
            for i in range(N):
                if mask>>i&1:
                    for j in range(N):
                        if reach[i][j]:out|=1<<j
            tab.append(out)
        tt=tuple(tab)
        if tt in ded:continue
        ded.add(tt); add_model(M,'HIGHER_CLOSURE',tt,1+sum(bin(v).count('1') for v in tt)//16)
    return M

MODELS=build_universe(); MIDS=tuple(sorted(MODELS))
BYTYPE={t:tuple(m for m in MIDS if MODELS[m].typ==t) for t in ALL_TYPES}

# ---------- fibers / claims ----------
def filter_fiber(mids,demos):
    return tuple(m for m in mids if all(MODELS[m].table[q]==y for q,y in demos))
def typeset(fib):return {MODELS[m].typ for m in fib}
def sigset(fib):return {MODELS[m].sig for m in fib}
def response_partition(fib,q):
    d={}
    for m in fib:d.setdefault(MODELS[m].table[q],[]).append(m)
    return {y:tuple(v) for y,v in d.items()}

def claim_state(fib,remaining,claim):
    if not fib:return '-1'
    vals=typeset(fib) if claim=='type' else sigset(fib)
    if len(vals)==1:return '1'
    for q in remaining:
        parts=response_partition(fib,q)
        for cell in parts.values():
            vv=typeset(cell) if claim=='type' else sigset(cell)
            if len(vv)<len(vals):return '+0'
    return '0'

def model_complexity(mid):return MODELS[mid].complexity

# ---------- query strategies ----------
def q_random(task,fib,remaining):return remaining[int(task.task_id[:8],16)%len(remaining)] if remaining else None

def q_type_minimax(task,fib,remaining):
    best=None
    for q in remaining:
        parts=response_partition(fib,q)
        key=(max(len(typeset(c)) for c in parts.values()),max(len(sigset(c)) for c in parts.values()),sum(len(c)**2 for c in parts.values()),q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def q_op_minimax(task,fib,remaining):
    best=None
    for q in remaining:
        parts=response_partition(fib,q)
        key=(max(len(sigset(c)) for c in parts.values()),max(len(typeset(c)) for c in parts.values()),sum(len(c)**2 for c in parts.values()),q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def q_eig(task,fib,remaining):
    n=len(fib);best=None
    for q in remaining:
        parts=response_partition(fib,q);exp=sum((len(c)/n)*math.log(max(1,len(sigset(c)))) for c in parts.values());key=(exp,q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def q_mdl(task,fib,remaining):
    w={m:math.exp(-0.8*model_complexity(m)) for m in fib};tot=sum(w.values());best=None
    for q in remaining:
        parts=response_partition(fib,q);exp=0.0
        for c in parts.values():
            wc=sum(w[m] for m in c);p=wc/tot
            bysig={}
            for m in c:bysig[MODELS[m].sig]=bysig.get(MODELS[m].sig,0)+w[m]
            ent=0.0
            for z in bysig.values():
                pp=z/wc;ent-=pp*math.log(pp)
            exp+=p*ent
        key=(exp,q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

def q_tos(task,fib,remaining):
    # conformational lexicographic criterion: type fiber first, then operator class, then raw model fiber.
    best=None
    for q in remaining:
        parts=response_partition(fib,q)
        profiles=sorted((len(typeset(c)),len(sigset(c)),len(c)) for c in parts.values())[::-1]
        worst=profiles[0];key=(worst,tuple(profiles),q)
        if best is None or key<best[0]:best=(key,q)
    return best[1] if best else None

STRATS={'RANDOM_QUERY':q_random,'EXACT_TYPE_MINIMAX':q_type_minimax,'EXACT_OPERATOR_MINIMAX':q_op_minimax,'EXACT_EIG_QUERY':q_eig,'MDL_TYPE_OPERATOR_INDUCTION':q_mdl,'TOS_FULL_TYPED_METAOPERATOR_GENESIS':q_tos}

# ---------- tasks ----------
def truth_response(mid,q):return MODELS[mid].table[q]

def simulate(mid,demos,pool,strat,budget=3):
    fib=filter_fiber(MIDS,demos);used=[];remaining=list(pool)
    for _ in range(budget):
        if len(sigset(fib))<=1:break
        q=strat(None if False else CURRENT_TASK,fib,remaining)  # CURRENT_TASK set in evaluator
        if q is None:break
        y=truth_response(mid,q);used.append((q,y));fib=filter_fiber(fib,[(q,y)]);remaining=[x for x in remaining if x!=q]
    return fib,used

CURRENT_TASK=None

def greedy_close(mid,demos,pool,strat,budget=3):
    global CURRENT_TASK
    fib=filter_fiber(MIDS,demos);remaining=list(pool);used=[]
    fake=Task('0','', '',mid,MODELS[mid].typ,MODELS[mid].sig,tuple(demos),tuple(pool),fib,tuple(range(N)))
    CURRENT_TASK=fake
    for _ in range(budget):
        if len(sigset(fib))<=1:break
        q=strat(fake,fib,remaining)
        if q is None:break
        y=truth_response(mid,q);used.append((q,y));fib=filter_fiber(fib,[(q,y)]);remaining.remove(q)
    return fib,used

def choose_demos(mid,rng,k):
    qs=rng.sample(list(QDOMAIN),k);return tuple((q,truth_response(mid,q)) for q in qs)

def search_task(truth_type,regime,seed,lane):
    rng=random.Random(seed)
    candidates=list(BYTYPE[truth_type]);rng.shuffle(candidates)
    for mid in candidates:
        for _ in range(600):
            if regime=='ANTI':
                q=rng.choice(QDOMAIN);y=truth_response(mid,q);demos=((q,y),(q,(y+1)%17));fib=filter_fiber(MIDS,demos)
                if fib:continue
                pool=tuple(rng.sample([z for z in QDOMAIN if z!=q],min(6,15)))
                return make_task(mid,lane,regime,demos,pool,tuple())
            k={'TYPE_AND_OPERATOR_AMBIG':2,'TYPE_FORM_OPERATOR_AMBIG':3,'ALREADY_FORM':7,'JURISDICTION_NONIDENT_TYPE':2}[regime]
            demos=choose_demos(mid,rng,k);fib=filter_fiber(MIDS,demos)
            if mid not in fib:continue
            tset,sset=typeset(fib),sigset(fib)
            remaining=[q for q in QDOMAIN if q not in {a for a,b in demos}]
            if regime=='TYPE_AND_OPERATOR_AMBIG':
                if len(tset)<=1 or len(sset)<=1:continue
                pool=tuple(rng.sample(remaining,min(8,len(remaining))))
                ff,_=greedy_close(mid,demos,pool,q_op_minimax,3)
                if len(sigset(ff))!=1:continue
            elif regime=='TYPE_FORM_OPERATOR_AMBIG':
                if len(tset)!=1 or len(sset)<=1:continue
                pool=tuple(rng.sample(remaining,min(8,len(remaining))))
                ff,_=greedy_close(mid,demos,pool,q_op_minimax,3)
                if len(sigset(ff))!=1:continue
            elif regime=='ALREADY_FORM':
                if len(sset)!=1:continue
                pool=tuple(rng.sample(remaining,min(6,len(remaining))))
            elif regime=='JURISDICTION_NONIDENT_TYPE':
                if len(tset)<=1:continue
                # Jurisdictional null is defined on the *actual truth path*: every admissible query leaves
                # the type fiber non-singleton for the observed response. This is the deployable notion of
                # non-identifiability for the realized system, not a requirement that every counterfactual cell be inert.
                good=[]
                for q in remaining:
                    y=truth_response(mid,q);cell=filter_fiber(fib,[(q,y)])
                    if len(typeset(cell))>1:good.append(q)
                if len(good)<3:continue
                pool=tuple(good[:6])
                ff=fib
                for q in pool:
                    ff=filter_fiber(ff,[(q,truth_response(mid,q))])
                if len(typeset(ff))<=1:continue
            return make_task(mid,lane,regime,demos,pool,fib)
    raise RuntimeError(f'cannot generate {truth_type} {regime}')

def make_task(mid,lane,regime,demos,pool,fib):
    typ=MODELS[mid].typ;sig=MODELS[mid].sig;perm=PERMS[int(h((mid,regime))[:8],16)%len(PERMS)]
    return Task(h((mid,lane,regime,demos,pool))[:20],lane,regime,mid,typ,sig,tuple(demos),tuple(pool),tuple(fib),perm)

def generate_private(n_each=4):
    out=[];regimes=('TYPE_AND_OPERATOR_AMBIG','TYPE_FORM_OPERATOR_AMBIG','ALREADY_FORM','ANTI')
    for ti,t in enumerate(PRIVATE_TYPES):
        for ri,r in enumerate(regimes):
            for i in range(n_each):out.append(search_task(t,r,SEED+ti*100000+ri*10000+i,'PRIVATE_OOD_TYPE'))
    # Negative type-nonidentifiability lane is instantiated only where the declared query jurisdiction
    # actually admits it. This avoids fabricating a null regime for HIGHER_CLOSURE when its available
    # interventions always reveal the semantic type.
    neg_types=('BINARY_NONCOMM','EQUIV_QUOTIENT','GRAPH_NEIGHBOR')
    for ti,t in enumerate(neg_types):
        for i in range(n_each+2):out.append(search_task(t,'JURISDICTION_NONIDENT_TYPE',SEED+700000+ti*10000+i,'PRIVATE_TYPE_NONIDENT'))
    return out

def generate_dev(n_each=3):
    out=[]
    for ti,t in enumerate(DEV_TYPES):
        for ri,r in enumerate(('TYPE_AND_OPERATOR_AMBIG','TYPE_FORM_OPERATOR_AMBIG','ALREADY_FORM')):
            for i in range(n_each):out.append(search_task(t,r,SEED//2+ti*10000+ri*1000+i,'DEV'))
    return out

# ---------- sealed transfer ----------
def sealed_signature_ok(task,mid):
    # same semantic signature must survive independent carrier relabeling.
    m=MODELS[mid];tt=transform_table(m.typ,m.table,task.sealed_perm);return signature(m.typ,tt)==m.sig

# ---------- evaluate ----------
def eval_method(task,name,strat,budget=3):
    fib=tuple(task.pre_fiber) if task.regime!='ANTI' else tuple()
    rem=list(task.query_pool);used=[]
    if not fib:
        return {'task_id':task.task_id,'lane':task.lane,'regime':task.regime,'truth_type':task.truth_type,'method':name,'type_state':'-1','operator_state':'-1','operator_form':False,'sealed_certificate':False,'queries':used,'post_models':0,'post_types':0,'post_sigs':0,'prediction_exact':False,'false_form_promotion':False}
    for _ in range(budget):
        if len(sigset(fib))<=1:break
        q=strat(task,fib,rem)
        if q is None:break
        y=truth_response(task.truth_mid,q);used.append((q,y));fib=filter_fiber(fib,[(q,y)]);rem.remove(q)
    ts=claim_state(fib,rem,'type');os_=claim_state(fib,rem,'operator')
    form=os_=='1' and task.truth_sig in sigset(fib)
    cert=form and all(sealed_signature_ok(task,m) for m in fib if MODELS[m].sig==task.truth_sig)
    # generic prediction endpoint: truth response on first unseen query is exact iff fiber agrees.
    unseen=next((q for q in QDOMAIN if q not in {a for a,b in task.demos} and q not in {a for a,b in used}),0)
    vals={MODELS[m].table[unseen] for m in fib};pred=len(vals)==1 and truth_response(task.truth_mid,unseen) in vals
    return {'task_id':task.task_id,'lane':task.lane,'regime':task.regime,'truth_type':task.truth_type,'method':name,'type_state':ts,'operator_state':os_,'operator_form':form and cert,'sealed_certificate':cert,'queries':used,'post_models':len(fib),'post_types':len(typeset(fib)),'post_sigs':len(sigset(fib)),'prediction_exact':pred,'false_form_promotion':form and not cert}

def universal_table_control(task):
    # can memorize queried values but never certifies semantic type/operator Form.
    fib=tuple(task.pre_fiber)
    return {'task_id':task.task_id,'lane':task.lane,'regime':task.regime,'truth_type':task.truth_type,'method':'UNIVERSAL_TABLE_COMPLETION','type_state':'0' if fib else '-1','operator_state':'0' if fib else '-1','operator_form':False,'sealed_certificate':False,'queries':[],'post_models':len(fib),'post_types':len(typeset(fib)) if fib else 0,'post_sigs':len(sigset(fib)) if fib else 0,'prediction_exact':False,'false_form_promotion':False}

def unary_perm_control(task):
    mids=tuple(m for m in MIDS if MODELS[m].typ=='UNARY_TOTAL_NONBIJ' and len(set(MODELS[m].table[:4]))==4)
    fib=filter_fiber(mids,task.demos)
    return {'task_id':task.task_id,'lane':task.lane,'regime':task.regime,'truth_type':task.truth_type,'method':'G4_UNARY_BIJECTION_ONLY','type_state':'0' if fib else '-1','operator_state':'0' if fib else '-1','operator_form':False,'sealed_certificate':False,'queries':[],'post_models':len(fib),'post_types':len(typeset(fib)) if fib else 0,'post_sigs':len(sigset(fib)) if fib else 0,'prediction_exact':False,'false_form_promotion':False}

def summarize(rows):
    out={}
    for m in sorted({r['method'] for r in rows}):
        z=[r for r in rows if r['method']==m];amb=[r for r in z if r['regime']=='TYPE_AND_OPERATOR_AMBIG'];allc=[r for r in z if r['regime']!='ANTI']
        out[m]={'operator_form_rate_ambiguous':sum(r['operator_form'] for r in amb)/len(amb) if amb else None,'type_form_rate_ambiguous':sum(r['type_state']=='1' for r in amb)/len(amb) if amb else None,'operator_form_rate_nonanti':sum(r['operator_form'] for r in allc)/len(allc) if allc else None,'prediction_exact_rate':sum(r['prediction_exact'] for r in allc)/len(allc) if allc else None,'false_form_rate':sum(r['false_form_promotion'] for r in z)/len(z)}
    return out

def paired_boot(rows,a,b,n=3000):
    aa={r['task_id']:int(r['operator_form']) for r in rows if r['method']==a and r['regime']=='TYPE_AND_OPERATOR_AMBIG'};bb={r['task_id']:int(r['operator_form']) for r in rows if r['method']==b and r['regime']=='TYPE_AND_OPERATOR_AMBIG'};ids=sorted(set(aa)&set(bb));d=np.array([aa[i]-bb[i] for i in ids],float);rng=np.random.default_rng(SEED);bs=[float(np.mean(rng.choice(d,size=len(d),replace=True))) for _ in range(n)];return {'delta':float(d.mean()),'ci':[float(np.quantile(bs,.025)),float(np.quantile(bs,.975))],'n':len(d),'a_only':sum(aa[i]>bb[i] for i in ids),'b_only':sum(bb[i]>aa[i] for i in ids)}

def exact_sign_p(aonly,bonly):
    n=aonly+bonly
    if not n:return 1.0
    from math import comb
    k=min(aonly,bonly);return min(1.0,2*sum(comb(n,i) for i in range(k+1))/(2**n))

def main():
    out=Path(os.environ.get('G41_WORKDIR','/mnt/data/CFL_G4_1_TYPED_METAOPERATOR_RUN'));out.mkdir(parents=True,exist_ok=True)
    dev=generate_dev(2);private=generate_private(4);tasks=dev+private
    write_jsonl(out/'evidence'/'TASKS.jsonl',[{'task_id':t.task_id,'lane':t.lane,'regime':t.regime,'truth_type_hash':h(t.truth_type),'truth_sig_hash':h(t.truth_sig),'demos':t.demos,'query_pool':t.query_pool,'pre_models':len(t.pre_fiber),'pre_types':len(typeset(t.pre_fiber)) if t.pre_fiber else 0,'pre_sigs':len(sigset(t.pre_fiber)) if t.pre_fiber else 0} for t in tasks])
    rows=[]
    for t in tasks:
        for name,fn in STRATS.items():rows.append(eval_method(t,name,fn,3))
        rows.append(universal_table_control(t));rows.append(unary_perm_control(t))
    write_jsonl(out/'results'/'PREDICTIONS.jsonl',rows)
    priv=[r for r in rows if r['lane']=='PRIVATE_OOD_TYPE'];summ=summarize(priv);write_json(out/'results'/'SUMMARY.json',summ)
    tos='TOS_FULL_TYPED_METAOPERATOR_GENESIS';best=max([m for m in STRATS if m!=tos],key=lambda m:summ[m]['operator_form_rate_ambiguous'])
    boot=paired_boot(priv,tos,best);p=exact_sign_p(boot['a_only'],boot['b_only'])
    # by type
    bytype={}
    for typ in PRIVATE_TYPES:
        z=[r for r in priv if r['method']==tos and r['truth_type']==typ and r['regime']=='TYPE_AND_OPERATOR_AMBIG'];bytype[typ]={'form':sum(r['operator_form'] for r in z),'n':len(z),'rate':sum(r['operator_form'] for r in z)/len(z) if z else None}
    support=boot['delta']>=.02 and boot['ci'][0]>0 and sum(v['rate'] is not None and v['rate']>summ[best]['operator_form_rate_ambiguous'] for v in bytype.values())>=3 and summ[tos]['false_form_rate']<=.02
    outcome='G4_1_LOCAL_SUPPORT' if support else ('G4_1_NO_SUPPORT_POINT_ESTIMATE_INFERIOR' if boot['delta']<0 else 'G4_1_BASELINE_EQUIVALENT')
    adj={'program_id':PROGRAM_ID,'version':VERSION,'outcome':outcome,'universe':{'models':len(MIDS),'by_type':{t:len(BYTYPE[t]) for t in ALL_TYPES}},'private_truth_types':PRIVATE_TYPES,'dev_truth_types':DEV_TYPES,'dev_private_type_overlap':len(set(DEV_TYPES)&set(PRIVATE_TYPES)),'strongest_baseline':best,'tos_operator_form_rate_ambiguous':summ[tos]['operator_form_rate_ambiguous'],'baseline_operator_form_rate_ambiguous':summ[best]['operator_form_rate_ambiguous'],'paired_bootstrap':boot,'paired_exact_sign_p':p,'tos_by_private_type':bytype,'form_semantics':'CATEGORICAL_NONPROBABILISTIC_ONLY','sealed_certificate':'representation-invariant semantic signature under carrier relabeling','benchmark_state':'+0_TYPED_METAOPERATOR_GENESIS_BENCHMARK_PROTOFORM','o3_claim_state':'0_NO_SUPPORT' if not support else '+0_UNREPLICATED','authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED','scope_limit':'finite bounded type universe supplied; G4.1 does not yet invent a wholly new semantic type outside the listed universe.'}
    write_json(out/'results'/'FINAL_ADJUDICATION.json',adj)
    write_json(out/'results'/'RUN_MANIFEST.json',{'program_id':PROGRAM_ID,'version':VERSION,'tasks':len(tasks),'private_tasks':len(private),'models':len(MIDS),'task_hash':h([(t.task_id,t.truth_type,t.regime) for t in tasks]),'adjudication':adj})
    print(json.dumps(adj,indent=2))

if __name__=='__main__':main()
