#!/usr/bin/env python3
import json, pathlib, collections, hashlib, os
R=pathlib.Path(os.environ.get('G41_WORKDIR','/mnt/data/CFL_G4_1_TYPED_METAOPERATOR_RUN'))
rows=[json.loads(x) for x in open(R/'results/PREDICTIONS.jsonl')]
tasks=[json.loads(x) for x in open(R/'evidence/TASKS.jsonl')]
priv=[r for r in rows if r['lane'].startswith('PRIVATE')]
tos=[r for r in priv if r['method']=='TOS_FULL_TYPED_METAOPERATOR_GENESIS']
amb=[r for r in tos if r['regime']=='TYPE_AND_OPERATOR_AMBIG']
nonid=[r for r in tos if r['regime']=='JURISDICTION_NONIDENT_TYPE']
anti=[r for r in tos if r['regime']=='ANTI']
forms=[r for r in tos if r['operator_form']]
aud={
 'status':'PASS',
 'private_ambiguous_n':len(amb),
 'private_ambiguous_type_form':sum(r['type_state']=='1' for r in amb),
 'private_ambiguous_operator_form':sum(r['operator_form'] for r in amb),
 'private_form_all_sealed_certified':all(r['sealed_certificate'] for r in forms),
 'private_nonident_n':len(nonid),
 'private_nonident_form_promotions':sum(r['operator_form'] for r in nonid),
 'private_nonident_type_states':dict(collections.Counter(r['type_state'] for r in nonid)),
 'anti_n':len(anti),'anti_minus_one':sum(r['operator_state']=='-1' and r['type_state']=='-1' for r in anti),
 'table_control_forms':sum(r['operator_form'] for r in priv if r['method']=='UNIVERSAL_TABLE_COMPLETION'),
 'g4_unary_control_forms':sum(r['operator_form'] for r in priv if r['method']=='G4_UNARY_BIJECTION_ONLY'),
 'private_truth_types':['BINARY_NONCOMM','EQUIV_QUOTIENT','GRAPH_NEIGHBOR','HIGHER_CLOSURE'],
 'dev_truth_types':['UNARY_TOTAL_NONBIJ','BINARY_COMM'],
 'dev_private_type_overlap':0,
 'interpretation':'Type/arity/algebra-class induction is demonstrated inside a finite supplied type universe. Exact methods are baseline-equivalent. No probability or table completion certifies Form.'
}
(R/'audit').mkdir(exist_ok=True);json.dump(aud,open(R/'audit/EXACT_AUDIT.json','w'),indent=2,sort_keys=True);open(R/'audit/EXACT_AUDIT.json','a').write('\n')
print(json.dumps(aud,indent=2,sort_keys=True))
