#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, sys, os, json, math, random, itertools, statistics, hashlib, time
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np

G34_PATH=Path(os.environ.get('G35_G34_PATH','/mnt/data/g34src/run_g34.py'))
spec=importlib.util.spec_from_file_location('g34mod',G34_PATH)
g34=importlib.util.module_from_spec(spec); sys.modules[spec.name]=g34; assert spec.loader; spec.loader.exec_module(g34)
g=g34.g

PROGRAM_ID='CFL-UEP-G3.5-ACTIVE-TOPOLOGY-DISAMBIGUATION'
VERSION='0.1.0'; SEED=350928
DOMAINS=g.DOMAINS

# ---------- helpers ----------
def canon(v): return g.canon(v)
def cjson(v): return g.cjson(v)
def h(v): return g.h(v)
def write_json(p,v): g.write_json(Path(p),v)
def write_jsonl(p,v): g.write_jsonl(Path(p),v)

def replace_task(t, **kw):
    d=t.__dict__.copy(); d.update(kw); return g.Task(**d)

def trim_task(t, n):
    return replace_task(t,
        demos_x_obs=t.demos_x_obs[:n], o1=t.o1[:n], o2=t.o2[:n],
        truth_x_latent=t.truth_x_latent[:n], truth_y_latent=t.truth_y_latent[:n])

def named_fits(t):
    preds,fits,evals=g.identify_exact(t)
    return preds, fits, evals

def model_key(fit):
    c,A,b,_=fit; return cjson({'c':c,'A':A,'b':b})

def family_of_chart(c):
    if isinstance(c,tuple) and c and c[0]=='COMPOSE': return 'COMPOSE'
    return str(c[0])

def unique_fits(fits):
    out={}
    for q in fits: out[model_key(q)]=q
    return list(out.values())

# ---------- composition lane ----------
def primitive_subset(domain,d):
    allc=g34.chart_candidates(domain,d)
    # deterministic, diverse compact primitive set; keep all families represented when possible.
    by=defaultdict(list)
    for c in allc: by[str(c[0])].append(c)
    out=[]
    for fam in g34.FAMILIES:
        z=sorted(by[fam], key=cjson)
        if z: out.extend(z[:2])
    if domain=='graph':
        out.extend([('PERM',(1,0,2,3,4)),('PERM',(0,2,1,3,4)),('PERM',(4,1,2,3,0))])
    return out

def _apply_primitive(domain,c,v):
    if c[0]=='PERM':
        perm=c[1]; return tuple(v[i] for i in perm)
    return g34.chart_apply(domain,c,v)

def _inv_primitive(domain,c,w):
    if c[0]=='PERM':
        perm=c[1]; inv=[0]*len(perm)
        for i,j in enumerate(perm): inv[j]=i
        return tuple(w[inv[i]] for i in range(len(inv)))
    return g34.chart_inv(domain,c,w)

def comp_apply(domain,c,v):
    if c[0]!='COMPOSE': return _apply_primitive(domain,c,v)
    _,c1,c2=c
    return _apply_primitive(domain,c2,_apply_primitive(domain,c1,v))

def comp_inv(domain,c,w):
    if c[0]!='COMPOSE': return _inv_primitive(domain,c,w)
    _,c1,c2=c
    return _inv_primitive(domain,c1,_inv_primitive(domain,c2,w))

def composition_candidates(domain,d):
    prim=primitive_subset(domain,d)
    named=list(g34.chart_candidates(domain,d))
    primitives=[c for c in prim if c[0]=='PERM']
    comps=[('COMPOSE',a,b) for a in prim for b in prim if a!=b]
    # open bounded composition grammar includes extra primitives plus their depth-2 compositions.
    out=[]; seen=set()
    for c in named+primitives+comps:
        k=cjson(c)
        if k not in seen: seen.add(k); out.append(c)
    return out

def solve_fiber(t, candidates, apply_chart, inv_chart):
    fits=[]; preds=defaultdict(list); yjoint=[tuple(a)+tuple(b) for a,b in zip(t.o1,t.o2)]
    for c in candidates:
        try:
            xs=[inv_chart(t.domain,c,v) for v in t.demos_x_obs]
            ys=[inv_chart(t.domain,c,v) for v in yjoint]
            tx=inv_chart(t.domain,c,t.target_x_obs)
        except Exception: continue
        status,A,b=g.solve_affine(t.domain,xs,ys)
        if status!='IDENTIFIED': continue
        if any(g.apply_op(t.domain,A,b,x)!=y for x,y in zip(xs,ys)): continue
        ty=g.apply_op(t.domain,A,b,tx)
        if not g.valid(t.domain,ty): continue
        yobs=apply_chart(t.domain,c,ty)
        fit=(c,A,b,yobs); fits.append(fit); preds[yobs].append(fit)
    return dict(preds), unique_fits(fits)

def make_composition_task(domain, split, seed, regime='A', max_attempts=4000):
    rng=random.Random(seed); d=g.DIMS[domain]
    comps=[c for c in composition_candidates(domain,d) if c[0]=='COMPOSE']
    named=list(g34.chart_candidates(domain,d)); full=composition_candidates(domain,d)
    for attempt in range(max_attempts):
        c=rng.choice(comps); A,b=g.generate_operator(domain,d,rng,3)
        n=(d+3 if regime=='C' else d+1)
        xs=[g.sample_x(domain,rng) for _ in range(n)]
        if g.affine_rank(xs,domain)<d+1: continue
        ys=[g.apply_op(domain,A,b,x) for x in xs]
        tx=g.sample_x(domain,rng); ty=g.apply_op(domain,A,b,tx)
        if not all(g.valid(domain,v) for v in ys+[ty]): continue
        xobs=[comp_apply(domain,c,v) for v in xs]; yobs=[comp_apply(domain,c,v) for v in ys]
        txo=comp_apply(domain,c,tx); tyo=comp_apply(domain,c,ty); qs=(d+1)//2
        t=g.Task(f'g35_comp_{domain}_{seed}_{attempt}',domain,split,'CONSTRUCT',d,xobs,[v[:qs] for v in yobs],[v[qs:] for v in yobs],txo,tyo,xs,ys,A,b,c,qs,False,{'lane':'COMPOSITION'})
        npreds,nfits=solve_fiber(t,named,g34.chart_apply,g34.chart_inv)
        cpreds,cfits=solve_fiber(t,full,comp_apply,comp_inv)
        if npreds: continue  # truth must be outside named meta-catalogue in observed evidence.
        if not cfits or tyo not in cpreds: continue
        if regime=='A' and len(cpreds)==1 and len(cfits)>=2: return t
        if regime=='B' and len(cpreds)>=2: return t
        if regime=='C' and len(cfits)==1: return t
    raise RuntimeError(f'composition generation failed {domain} {regime}')

# ---------- standard task generation for A/B/C ----------
def gen_standard(domain, split, regime, seed, max_attempts=5000):
    d=g.DIMS[domain]
    for k in range(max_attempts):
        # start from an exact truth task, then trim to minimum affine-identifying count.
        t=g.make_task(domain,split,'CONSTRUCT',seed+k*100003)
        t=trim_task(t,d+1)
        preds,fits,_=named_fits(t); fits=unique_fits(fits)
        if not fits or t.truth_y_obs not in preds: continue
        if regime=='A' and len(preds)==1 and len(fits)>=2: return replace_task(t,task_id=f'g35_{domain}_{split}_A_{seed}_{k}',metadata={**t.metadata,'g35_regime':'A'})
        if regime=='B' and len(preds)>=2: return replace_task(t,task_id=f'g35_{domain}_{split}_B_{seed}_{k}',metadata={**t.metadata,'g35_regime':'B'})
        if regime=='C' and len(fits)==1: return replace_task(t,task_id=f'g35_{domain}_{split}_C_{seed}_{k}',metadata={**t.metadata,'g35_regime':'C'})
    raise RuntimeError(f'generation failed {domain} {regime}')

# ---------- experiment design ----------
def predict_fit(t,fit,qobs,apply_chart,inv_chart):
    c,A,b,_=fit
    try: x=inv_chart(t.domain,c,qobs)
    except Exception: return ('INVALID',)
    if not g.valid(t.domain,x): return ('INVALID',)
    y=g.apply_op(t.domain,A,b,x)
    if not g.valid(t.domain,y): return ('INVALID',)
    try: return tuple(apply_chart(t.domain,c,y))
    except Exception: return ('INVALID',)

def truth_response(t,qobs,apply_chart,inv_chart):
    try: x=inv_chart(t.domain,t.truth_chart,qobs)
    except Exception: return ('INVALID',)
    y=g.apply_op(t.domain,t.truth_A,t.truth_b,x)
    if not g.valid(t.domain,y): return ('INVALID',)
    return tuple(apply_chart(t.domain,t.truth_chart,y))

def entropy_counts(vals):
    n=len(vals)
    if n<=1:return 0.0
    c=Counter(vals); return -sum((v/n)*math.log2(v/n) for v in c.values())

def conditional_family_entropy(fits,responses):
    # H(F|Y) with model-uniform prior
    n=len(fits); by=defaultdict(list)
    for fit,r in zip(fits,responses): by[r].append(family_of_chart(fit[0]))
    h=0.0
    for vals in by.values(): h+=(len(vals)/n)*entropy_counts(vals)
    return h

def query_stats(t,fits,q,apply_chart,inv_chart):
    responses=[predict_fit(t,f,q,apply_chart,inv_chart) for f in fits]
    fams=[family_of_chart(f[0]) for f in fits]
    model_ig=entropy_counts(responses) # deterministic models, uniform prior
    family_ig=entropy_counts(fams)-conditional_family_entropy(fits,responses)
    # target-output ambiguity is claim-relevant in regime B.
    target_preds=[f[3] for f in fits]
    # for each possible query response, expected entropy of target predictions afterwards.
    prior_target_h=entropy_counts(target_preds); by=defaultdict(list)
    for f,r in zip(fits,responses):by[r].append(f[3])
    post=sum((len(v)/len(fits))*entropy_counts(v) for v in by.values())
    target_ig=prior_target_h-post
    return {'model_ig':model_ig,'family_ig':family_ig,'target_ig':target_ig,'responses':responses,'distinct_responses':len(set(responses))}

def query_pool(t,fits,apply_chart,inv_chart,n=24):
    rng=random.Random(int(hashlib.sha256((t.task_id+'querypool').encode()).hexdigest()[:16],16))
    qs=[];seen=set();tries=0
    while len(qs)<n and tries<4000:
        tries+=1; x=g.sample_x(t.domain,rng); q=comp_apply(t.domain,t.truth_chart,x) if t.truth_chart and t.truth_chart[0]=='COMPOSE' else g34.chart_apply(t.domain,t.truth_chart,x)
        if q==t.target_x_obs or q in seen or q in t.demos_x_obs: continue
        seen.add(q);qs.append(q)
    return qs

def choose(method,t,fits,pool,apply_chart,inv_chart,regime):
    if len(fits)<=1:
        return None, {'reason':'fiber_singleton'}
    stats=[query_stats(t,fits,q,apply_chart,inv_chart) for q in pool]
    if method in ('EXACT_CLAIM_AWARE_EIG','TOS_FULL_ACTIVE_TOPOLOGY_O3'):
        # Claim-aware lexicographic objective: first resolve target when ambiguous, then family, then full model fiber.
        def key(i):
            s=stats[i]
            if regime=='B': return (s['target_ig'],s['family_ig'],s['model_ig'],-i)
            return (s['family_ig'],s['model_ig'],s['target_ig'],-i)
        i=max(range(len(pool)),key=key)
    elif method=='EXACT_MODEL_EIG': i=max(range(len(pool)),key=lambda j:(stats[j]['model_ig'],-j))
    elif method=='EXACT_FAMILY_EIG': i=max(range(len(pool)),key=lambda j:(stats[j]['family_ig'],stats[j]['model_ig'],-j))
    elif method=='MAX_PREDICTIVE_VARIANCE':
        def varscore(j):
            rr=[r for r in stats[j]['responses'] if r!=('INVALID',)]
            if not rr:return -1
            A=np.asarray(rr,float);return float(np.mean(np.var(A,axis=0)))
        i=max(range(len(pool)),key=lambda j:(varscore(j),-j))
    elif method=='MDL_DISAGREEMENT':
        # Prefer family separation, penalize query outputs requiring large observed magnitude.
        i=max(range(len(pool)),key=lambda j:(stats[j]['family_ig']-.001*sum(abs(int(x)) for x in pool[j]),stats[j]['model_ig'],-j))
    elif method=='RANDOM_QUERY':
        rng=random.Random(int(hashlib.sha256((t.task_id+method).encode()).hexdigest()[:16],16));i=rng.randrange(len(pool))
    elif method=='TOS_NO_PHI': i=0
    elif method=='TOS_NO_O3': return None, {'reason':'O3_withheld'}
    else: raise KeyError(method)
    return pool[i],stats[i]

def evaluate_selected(t,fits,q,apply_chart,inv_chart):
    pre_models=len(fits); pre_fams=len(set(family_of_chart(f[0]) for f in fits)); pre_targets=len(set(f[3] for f in fits))
    if q is None:
        post=fits
    else:
        y=truth_response(t,q,apply_chart,inv_chart)
        post=[f for f in fits if predict_fit(t,f,q,apply_chart,inv_chart)==y]
    post_models=len(post); post_fams=len(set(family_of_chart(f[0]) for f in post)); post_targets=len(set(f[3] for f in post))
    return {
        'pre_models':pre_models,'post_models':post_models,'model_reduction':1-post_models/pre_models if pre_models else 0,
        'pre_families':pre_fams,'post_families':post_fams,'family_reduction':1-post_fams/pre_fams if pre_fams else 0,
        'pre_targets':pre_targets,'post_targets':post_targets,'target_resolved':post_targets==1,
        'family_resolved':post_fams==1,'model_resolved':post_models==1,'truth_model_retained':any(model_key(f)==model_key((t.truth_chart,t.truth_A,t.truth_b,t.truth_y_obs)) for f in post)
    }

METHODS=('EXACT_CLAIM_AWARE_EIG','EXACT_MODEL_EIG','EXACT_FAMILY_EIG','MAX_PREDICTIVE_VARIANCE','MDL_DISAGREEMENT','RANDOM_QUERY','TOS_NO_PHI','TOS_NO_O3','TOS_FULL_ACTIVE_TOPOLOGY_O3')

def run_lane(tasks,lane):
    rows=[]
    for ti,(t,regime) in enumerate(tasks):
        if lane=='COMPOSITION':
            candidates=composition_candidates(t.domain,t.d); apply_chart=comp_apply; inv_chart=comp_inv
            preds,fits=solve_fiber(t,candidates,apply_chart,inv_chart)
        else:
            preds,fits,_=named_fits(t); apply_chart=g34.chart_apply; inv_chart=g34.chart_inv; fits=unique_fits(fits)
        pool=query_pool(t,fits,apply_chart,inv_chart)
        for m in METHODS:
            q,qs=choose(m,t,fits,pool,apply_chart,inv_chart,regime)
            ev=evaluate_selected(t,fits,q,apply_chart,inv_chart)
            need=regime in ('A','B')
            correct_abstain=(regime=='C' and q is None)
            # Success is claim-specific: B must resolve target; A must reduce family and preferably resolve; C abstains.
            if regime=='B': success=bool(q is not None and ev['target_resolved'] and ev['truth_model_retained'])
            elif regime=='A': success=bool(q is not None and ev['post_families'] < ev['pre_families'] and ev['truth_model_retained'])
            else: success=correct_abstain
            rows.append({'task_id':t.task_id,'domain':t.domain,'lane':lane,'regime':regime,'method':m,'query':q,'query_stats':qs,'success':success,'unnecessary_query':bool(regime=='C' and q is not None),**ev})
    return rows

def summarize(rows):
    out={}
    for m in METHODS:
        z=[r for r in rows if r['method']==m]; out[m]={
            'success':sum(r['success'] for r in z)/len(z),
            'mean_model_reduction':float(np.mean([r['model_reduction'] for r in z])),
            'mean_family_reduction':float(np.mean([r['family_reduction'] for r in z])),
            'target_resolution_rate_B':float(np.mean([r['target_resolved'] for r in z if r['regime']=='B'])) if any(r['regime']=='B' for r in z) else None,
            'family_resolution_rate_A':float(np.mean([r['family_resolved'] for r in z if r['regime']=='A'])) if any(r['regime']=='A' for r in z) else None,
            'correct_abstention_C':float(np.mean([not r['unnecessary_query'] for r in z if r['regime']=='C'])) if any(r['regime']=='C' for r in z) else None,
            'unnecessary_query_rate':float(np.mean([r['unnecessary_query'] for r in z]))
        }
    return out

def paired_boot(rows,a,b,metric='success',n=4000):
    A={(r['task_id'],r['lane']):float(r[metric]) for r in rows if r['method']==a};B={(r['task_id'],r['lane']):float(r[metric]) for r in rows if r['method']==b};ids=sorted(set(A)&set(B));d=np.asarray([A[i]-B[i] for i in ids]);rng=np.random.default_rng(SEED);bs=[float(np.mean(rng.choice(d,size=len(d),replace=True))) for _ in range(n)];return {'delta':float(d.mean()),'ci':[float(np.quantile(bs,.025)),float(np.quantile(bs,.975))],'n':len(d)}

def gen_standard_C_full(domain,split,seed,max_attempts=1000):
    for k in range(max_attempts):
        t=g.make_task(domain,split,'CONSTRUCT',seed+k*100003)
        preds,fits,_=named_fits(t); fits=unique_fits(fits)
        if len(fits)==1 and t.truth_y_obs in preds:
            return replace_task(t,task_id=f'g35_{domain}_{split}_C_{seed}_{k}',metadata={**t.metadata,'g35_regime':'C'})
    raise RuntimeError(f'full C generation failed {domain}')

def generate_standard_set(split, base=710000):
    out=[]
    for di,d in enumerate(DOMAINS):
        for i in range(6): out.append((gen_standard(d,split,'A',base+di*100000+i*100), 'A'))
        if d in ('graph','algebra'):
            for i in range(8): out.append((gen_standard(d,split,'B',base+di*100000+10000+i*100), 'B'))
        for i in range(6): out.append((gen_standard_C_full(d,split,base+di*100000+20000+i*100), 'C'))
    return out

def generate_composition_set(split, base=910000):
    out=[]
    schedule={'graph':(), 'algebra':('A','B','C'),'number':('A',),'mechanics':('A','C')}
    for di,d in enumerate(DOMAINS):
        for ri,reg in enumerate(schedule[d]):
            for i in range(3): out.append((make_composition_task(d,split,base+di*100000+ri*10000+i*100,reg),reg))
    return out

def main():
    out=Path(os.environ.get('G35_WORKDIR','/mnt/data/CFL_G3_5_ACTIVE_TOPOLOGY_RUN'));out.mkdir(parents=True,exist_ok=True)
    t0=time.time(); print('generate standard',flush=True)
    standard=generate_standard_set('PRIVATE_HELDOUT',base=710000)
    print('generate composition',flush=True)
    comp=generate_composition_set('OOD_COMPOSITION',base=910000)
    print('evaluate standard',flush=True); rows=run_lane(standard,'NAMED')
    print('evaluate composition',flush=True); rows+=run_lane(comp,'COMPOSITION')
    write_jsonl(out/'results'/'QUERY_RESULTS.jsonl',rows)
    named=[r for r in rows if r['lane']=='NAMED']; comp_rows=[r for r in rows if r['lane']=='COMPOSITION']
    sums={'NAMED':summarize(named),'COMPOSITION':summarize(comp_rows),'ALL':summarize(rows)};write_json(out/'results'/'SUMMARY.json',sums)
    tos='TOS_FULL_ACTIVE_TOPOLOGY_O3'; base='EXACT_CLAIM_AWARE_EIG'
    boot=paired_boot(rows,tos,base)
    # Fiber-reduction comparison to exact claim-aware baseline.
    bootfam=paired_boot(rows,tos,base,'family_reduction');bootmod=paired_boot(rows,tos,base,'model_reduction')
    adj={'program_id':PROGRAM_ID,'version':VERSION,'material_gate':'PASS_LOCAL','private_named_tasks':len(standard),'ood_composition_tasks':len(comp),
         'active_observation_design_demonstrated':sums['ALL'][tos]['success']>=.9,
         'tos_success':sums['ALL'][tos]['success'],'exact_claim_aware_eig_success':sums['ALL'][base]['success'],
         'paired_success':boot,'paired_family_reduction':bootfam,'paired_model_reduction':bootmod,
         'composition_lane_tos_success':sums['COMPOSITION'][tos]['success'],'composition_lane_exact_success':sums['COMPOSITION'][base]['success'],
         'outcome':'G3_5_BASELINE_EQUIVALENT' if boot['delta']==0 else ('G3_5_LOCAL_SUPPORT' if boot['ci'][0]>0 else 'G3_5_NOT_SUPPORTED'),
         'benchmark_state':'+0_ACTIVE_TOPOLOGY_DISAMBIGUATION_BENCHMARK_PROTOFORM','o3_claim_state':'0_BASELINE_EQUIVALENT' if boot['delta']==0 else '+0_UNREPLICATED',
         'authority':'NONE','promotion':'BLOCKED','canonicalization':'BLOCKED','elapsed_s':time.time()-t0,
         'interpretation':'O3 is evaluated as active experiment design over the compatible explanatory fiber. Exact claim-aware information gain is a matched strong baseline; the composition lane removes the named-family shortcut but still supplies a bounded composition grammar.'}
    write_json(out/'results'/'FINAL_ADJUDICATION.json',adj)
    # public/truth receipts
    truth=[]
    for t,r in standard+comp:
        truth.append({'task_id':t.task_id,'domain':t.domain,'lane':t.metadata.get('lane','NAMED'),'regime':r,'truth_chart_hash':h(t.truth_chart),'truth_operator_hash':h({'A':t.truth_A,'b':t.truth_b}),'truth_target_hash':h(t.truth_y_obs)})
    write_jsonl(out/'evidence'/'TRUTH_MANIFEST.jsonl',truth)
    (out/'results'/'REPORT.md').write_text(f'''# CFL G3.5 Active Topology Disambiguation\n\nOutcome: **{adj['outcome']}**\n\nTOS success {adj['tos_success']:.4f}; exact claim-aware EIG {adj['exact_claim_aware_eig_success']:.4f}; paired delta {boot['delta']:.4f}, CI {boot['ci']}.\n\nThis gate makes the explanatory model fiber the object of O3. Regime A has prediction-identifiable/model-ambiguous tasks, B has both target and model ambiguity, and C has a singleton model fiber where the correct action is abstention. OOD_COMPOSITION hides the truth outside the named chart catalogue but retains a bounded depth-2 composition grammar.\n''')
    print(json.dumps(adj,indent=2),flush=True)
if __name__=='__main__': main()
