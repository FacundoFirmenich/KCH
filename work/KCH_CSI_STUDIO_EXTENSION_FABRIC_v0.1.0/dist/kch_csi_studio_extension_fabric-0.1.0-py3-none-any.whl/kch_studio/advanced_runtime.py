from __future__ import annotations

import json
import os
import uuid
from pathlib import Path
from typing import Any, Callable

from .account_broker import AccountPermissionBroker
from .audio_hub import AudioHub
from .clipboard_hub import ClipboardHub
from .checkpoints import CheckpointManager
from .constitutional import Actor, ConstitutionalWorkspace
from .construct_mode import ConstructMode
from .diction_learning import DictionLearning
from .kwandata import KwanData
from .launcher import Capability, ProactiveLauncher
from .mis_service import MISService
from .permissions import PermissionGovernor
from .persistence import PersistenceHub
from .proactive import ProgrammedPolicy
from .recovery import RecoveryVault
from .safeguards import RiskAdvisor
from .scheduler import KCHScheduler
from .universal_text import PlanBuildEngine


def schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {"type": "object", "properties": properties, "required": required, "additionalProperties": False}


S = {"type": "string"}
B = {"type": "boolean"}
I = {"type": "integer", "minimum": 1}
O = {"type": "object"}
A = {"type": "array"}


def tool(name: str, title: str, description: str, properties: dict[str, Any], required: list[str], *, read_only: bool) -> dict[str, Any]:
    return {"name": name, "title": title, "description": description, "inputSchema": schema(properties, required), "readOnly": read_only}


ADVANCED_TOOLS = [
    tool("kch_next_status", "Inspect integrated KCH-next layers", "Aggregate constitutional, launcher, recovery, data, permission, persistence, account, clipboard, audio, scheduler and MIS state.", {}, [], read_only=True),
    tool("constitution_state", "Read constitutional workspace", "Read the ranked, nested, connected user constitution. Models cannot mutate it.", {}, [], read_only=True),
    tool("constitution_effective", "Compile effective constitution", "Compile active constitutional boxes in rank order without changing them.", {}, [], read_only=True),
    tool("constitution_propose", "Propose constitutional amendment", "Store a model proposal separately; it does not enact or alter constitutional authority.", {"proposal": O}, ["proposal"], read_only=False),
    tool("programmed_policy_status", "Read programmed proactive policy", "Inspect direct if/then/else rules and startup-announcement preference.", {}, [], read_only=True),
    tool("programmed_policy_evaluate", "Evaluate proactive event", "Evaluate every applicable programmed rule; does not execute it.", {"event": O}, ["event"], read_only=True),
    tool("proactive_launcher_status", "Inspect background launcher", "Inspect background state, capability coverage, and blind spots.", {}, [], read_only=True),
    tool("proactive_event_publish", "Publish proactive event", "Queue an event for background governed dispatch.", {"event": O}, ["event"], read_only=False),
    tool("recovery_checkpoint", "Create recovery checkpoint", "Persist an optional event payload and snapshot all current master-vault assets.", {"label": S, "payload": O}, ["label"], read_only=False),
    tool("recovery_verify", "Verify recovery chains", "Verify append-only master recovery chains.", {}, [], read_only=True),
    tool("risk_assess", "Advise on risky change", "Warn about dependency, history, authority, external-write, and lossy-conversion risk; does not censor.", {"proposal": O}, ["proposal"], read_only=True),
    tool("plan_build_plan", "Plan universal data build", "Persist a reviewable ingest/transform/restore plan without executing it.", {"operations": A}, ["operations"], read_only=False),
    tool("plan_build_execute", "Execute universal data plan", "Execute a previously persisted plan inside the KCH runtime with original-byte custody.", {"plan_id": S}, ["plan_id"], read_only=False),
    tool("persistence_status", "Inspect chat persistence", "Inspect exact KCH/SCO custody coverage and external-host transport limits.", {}, [], read_only=True),
    tool("persistence_chat_create", "Create persistent chat", "Create a KCH chat record with explicit platform and capture mode.", {"platform": S, "title": S, "native_id": S, "source_uri": S, "capture_mode": S}, ["platform"], read_only=False),
    tool("persistence_turn_append", "Append persistent chat turn", "Append exact JSON payload to a chat hash chain.", {"chat_id": S, "role": S, "payload": {}, "timestamp": S}, ["chat_id", "role", "payload"], read_only=False),
    tool("persistence_superchat_create", "Create SCO manifest", "Orchestrate existing chats without merging their context or identity.", {"title": S, "members": A}, ["title", "members"], read_only=False),
    tool("kwandata_status", "Inspect KwanData", "Inspect source, record, tag, supertag, program and layer counts.", {}, [], read_only=True),
    tool("kwandata_ingest", "Ingest into KwanData", "Ingest an authorized local file with exact source custody and deterministic structuring.", {"source": S, "program_id": S}, ["source"], read_only=False),
    tool("kwandata_query", "Query KwanData", "Query structured records and tags.", {"query": S, "limit": I}, ["query"], read_only=True),
    tool("permission_status", "Inspect permission governor", "Inspect governed capability domains and receipt counts.", {}, [], read_only=True),
    tool("permission_check", "Evaluate permission", "Evaluate and record one actor/resource/operation decision.", {"actor": S, "resource": S, "operation": S, "session_id": S}, ["actor", "resource", "operation"], read_only=False),
    tool("scheduler_status", "Inspect scheduler", "Inspect agendas, active one-shot/interval/cron schedules, and occurrence history.", {}, [], read_only=True),
    tool("scheduler_create", "Create finite schedule", "Create a persisted schedule that publishes events to the proactive launcher.", {"name": S, "kind": S, "expression": S, "event": O, "agenda_id": S, "timezone": S, "announce": B}, ["name", "kind", "expression", "event"], read_only=False),
    tool("clipboard_status", "Inspect superclipboard", "Inspect clipboard monitor, persistent items, and post-it database.", {}, [], read_only=True),
    tool("clipboard_capture_text", "Capture clipboard text", "Capture explicit text into the local clipboard history with secret detection.", {"text": S, "persist": B}, ["text"], read_only=False),
    tool("clipboard_search", "Search clipboard and post-its", "Search non-secret previews and post-it text.", {"query": S, "limit": I}, ["query"], read_only=True),
    tool("clipboard_postit_create", "Create persistent post-it", "Create a versioned post-it from text or a clipboard item.", {"title": S, "body": S, "source_item_id": S, "parent_postit_id": S, "color": S, "tags": A}, [], read_only=False),
    tool("clipboard_postit_edit", "Edit persistent post-it", "Autosave a post-it revision.", {"postit_id": S, "title": S, "body": S, "color": S}, ["postit_id"], read_only=False),
    tool("clipboard_explanation_context", "Read selected context", "Return one user-selected clipboard item for ad hoc explanation.", {"item_id": S}, ["item_id"], read_only=True),
    tool("account_broker_status", "Inspect temporal account broker", "Inspect providers, finite duration classes and local/remote revocation limits.", {}, [], read_only=True),
    tool("account_permission_request", "Request finite account access", "Create a terminal-first, finite-duration account permission request; does not approve or authenticate.", {"provider": S, "scopes": A, "purpose": S, "account_hint": S}, ["provider", "scopes", "purpose"], read_only=False),
    tool("audio_status", "Inspect voice/audio hub", "Inspect transcription, microphone and TTS backends without activating the microphone.", {}, [], read_only=True),
    tool("audio_ingest_transcribe", "Ingest and transcribe audio", "Custody an authorized audio clip and transcribe with an available local backend.", {"source": S, "culture": S, "consent_basis": S}, ["source", "consent_basis"], read_only=False),
    tool("voice_notify", "Speak proactive notice", "Preserve a KCH message transcript and synthesize it locally when available.", {"text": S, "culture": S}, ["text"], read_only=False),
    tool("diction_status", "Inspect diction learning", "Inspect OBL lexicon, resolution and PHL-shadow correction counts.", {}, [], read_only=True),
    tool("diction_resolve", "Resolve transcription diction", "Preserve raw text and compute an auditable normalized overlay.", {"raw_transcription": S, "source_audio_id": S}, ["raw_transcription"], read_only=False),
    tool("mis_full_status", "Inspect full MIS integration", "Distinguish real MIS mathematics from the formerly amputated KCH 0.11 surface.", {}, [], read_only=True),
    tool("mis_describe", "Describe MIS service", "Describe the full bounded MIS v0.3.1 mathematical service.", {}, [], read_only=True),
    tool("mis_exact_decide", "Compute exact MIS decision", "Compute a rational Bayesian loss decision for declared inputs; creates no execution authority.", {"request": O}, ["request"], read_only=True),
    tool("mis_historical_audit", "Replay full MIS historical gate", "Recompute the exact 480-record/60-ledger bounded historical audit.", {}, [], read_only=True),
    tool("mis_certificate_verify_full", "Verify MIS certificate", "Verify the packaged historical certificate or a supplied MIS certificate.", {"certificate": O}, [], read_only=True),
    tool("mis_csi_lowering", "Read MIS CSI lowering", "Read and verify the bounded four-instruction CSI lowering with its operational limitation.", {}, [], read_only=True),
    tool("kch_mode_status", "Inspect PLAN/RUN/CONSTRUCT modes", "Inspect the three canonical modes and the successor-only CONSTRUCT pointer.", {}, [], read_only=True),
    tool("checkpoint_status", "Inspect checkpoint persistence", "Inspect structured and full checkpoint coverage without creating a checkpoint.", {}, [], read_only=True),
    tool("checkpoint_estimate", "Estimate checkpoint size", "Calculate exact current logical bytes and warn before any full checkpoint.", {}, [], read_only=True),
    tool("checkpoint_full_plan", "Plan a full checkpoint", "Create a warning-bearing plan; it does not create the large full checkpoint.", {"label": S}, ["label"], read_only=False),
]


class KCHAdvancedRuntime:
    def __init__(
        self, root: str | Path, *,
        extra_handlers: dict[str, Callable[[dict[str, Any]], Any]] | None = None,
        extra_tools: list[dict[str, Any]] | None = None,
        stable_root: str | Path | None = None,
    ):
        self.root = Path(root).resolve(); self.root.mkdir(parents=True, exist_ok=True)
        self.recovery = RecoveryVault(self.root / "master_recovery")
        self.constitution = ConstitutionalWorkspace(self.root / "constitution")
        self.policy = ProgrammedPolicy(self.root / "proactive_policy")
        self.risk = RiskAdvisor(self.root / "risk")
        self.plan_build = PlanBuildEngine(self.root / "plan_build")
        self.persistence = PersistenceHub(self.root / "persistence")
        self.kwandata = KwanData(self.root / "kwandata")
        self.permissions = PermissionGovernor(self.root / "permissions")
        self.clipboard = ClipboardHub(self.root / "clipboard")
        self.diction = DictionLearning(self.root / "diction")
        self.mis = MISService()
        self.voice_chat_id = self.persistence.create_chat(platform="KCH_AUDIO", title="KCH Voice Inbox")["chat_id"]
        self.audio = AudioHub(self.root / "audio", on_transcript=self._on_transcript)
        self.account_broker = AccountPermissionBroker(self.root / "accounts", self.permissions)
        source_root = Path(stable_root or os.environ.get("KCH_CONSTRUCT_STABLE_ROOT", Path(__file__).resolve().parents[2])).resolve()
        self.construct = ConstructMode(self.root / "construct", source_root)
        self.checkpoints = CheckpointManager(
            self.root / "checkpoints",
            {"runtime": self.root, "stable": source_root},
        )

        self.handlers: dict[str, Callable[[dict[str, Any]], Any]] = {
            "kch_next_status": lambda _a: self.status(),
            "constitution_state": lambda _a: self.constitution.state(),
            "constitution_effective": lambda _a: self.constitution.effective_mandates(),
            "constitution_propose": lambda a: self.constitution.propose(dict(a["proposal"])),
            "programmed_policy_status": lambda _a: self.policy.state(),
            "programmed_policy_evaluate": lambda a: self.policy.evaluate_all(dict(a["event"])),
            "proactive_launcher_status": lambda _a: self.launcher.status(),
            "proactive_event_publish": lambda a: self.launcher.publish(dict(a["event"])),
            "recovery_checkpoint": self._checkpoint,
            "recovery_verify": lambda _a: self.recovery.verify(),
            "risk_assess": lambda a: self.risk.assess(dict(a["proposal"])),
            "plan_build_plan": lambda a: self.plan_build.plan(list(a["operations"])),
            "plan_build_execute": lambda a: self.plan_build.build(str(a["plan_id"])),
            "persistence_status": lambda _a: {"coverage": self.persistence.coverage()},
            "persistence_chat_create": self._chat_create,
            "persistence_turn_append": self._turn_append,
            "persistence_superchat_create": lambda a: self.persistence.create_superchat(title=str(a["title"]), members=list(a["members"])),
            "kwandata_status": lambda _a: self.kwandata.status(),
            "kwandata_ingest": self._kwandata_ingest_model,
            "kwandata_query": lambda a: self.kwandata.query(str(a["query"]), limit=int(a.get("limit", 50))),
            "permission_status": lambda _a: self.permissions.status(),
            "permission_check": lambda a: self.permissions.decide(actor=str(a["actor"]), resource=str(a["resource"]), operation=str(a["operation"]), session_id=a.get("session_id")),
            "scheduler_status": lambda _a: self.scheduler.status(),
            "scheduler_create": self._scheduler_create_model,
            "clipboard_status": lambda _a: self.clipboard.status(),
            "clipboard_capture_text": lambda a: self.clipboard.capture(str(a["text"]), kind="TEXT", media_type="text/plain; charset=utf-8", explicit_persist=bool(a.get("persist", False))),
            "clipboard_search": lambda a: self.clipboard.search(str(a["query"]), limit=int(a.get("limit", 50))),
            "clipboard_postit_create": lambda a: self.clipboard.create_postit(title=str(a.get("title", "")), body=str(a.get("body", "")), source_item_id=a.get("source_item_id"), parent_postit_id=a.get("parent_postit_id"), color=str(a.get("color", "#FFF4A3")), tags=list(a.get("tags", []))),
            "clipboard_postit_edit": lambda a: self.clipboard.edit_postit(str(a["postit_id"]), title=a.get("title"), body=a.get("body"), color=a.get("color")),
            "clipboard_explanation_context": lambda a: self.clipboard.explanation_context(str(a["item_id"])),
            "account_broker_status": lambda _a: self.account_broker.status(),
            "account_permission_request": lambda a: self.account_broker.request(provider=str(a["provider"]), scopes=list(a["scopes"]), purpose=str(a["purpose"]), account_hint=a.get("account_hint")),
            "audio_status": lambda _a: self.audio.status(),
            "audio_ingest_transcribe": self._audio_ingest_model,
            "voice_notify": self._voice_notify_model,
            "diction_status": lambda _a: self.diction.status(),
            "diction_resolve": lambda a: self.diction.resolve(str(a["raw_transcription"]), source_audio_id=a.get("source_audio_id")),
            "mis_full_status": lambda _a: self.mis.status(),
            "mis_describe": lambda _a: self.mis.describe(),
            "mis_exact_decide": lambda a: self.mis.exact_decide(dict(a["request"])),
            "mis_historical_audit": lambda _a: self.mis.audit_historical(),
            "mis_certificate_verify_full": lambda a: self.mis.verify_certificate(a.get("certificate")),
            "mis_csi_lowering": lambda _a: self.mis.csi_lowering(),
            "kch_mode_status": lambda _a: self.construct.status(),
            "checkpoint_status": lambda _a: self.checkpoints.status(),
            "checkpoint_estimate": lambda _a: self.checkpoints.estimate(),
            "checkpoint_full_plan": lambda a: self.checkpoints.full_plan(str(a["label"])),
        }
        if extra_handlers:
            overlap = set(self.handlers) & set(extra_handlers)
            if overlap:
                raise ValueError(f"duplicate advanced/host handlers: {sorted(overlap)}")
            self.handlers.update(extra_handlers)
        tool_by_name = {item["name"]: item for item in [*ADVANCED_TOOLS, *(extra_tools or [])]}
        missing_descriptors = set(self.handlers) - set(tool_by_name)
        if missing_descriptors:
            raise ValueError(f"tool descriptors missing for handlers: {sorted(missing_descriptors)}")
        capabilities = [
            Capability(
                name=name,
                purpose=tool_by_name[name]["description"],
                mode="DEFAULT_AUTO" if name in {"constitution_effective", "recovery_checkpoint", "risk_assess"} else "USER_PROGRAMMABLE",
                event_types=("capability.requested",),
                mutating=not bool(tool_by_name[name]["readOnly"]),
                external_side_effect=name in {"voice_notify", "kwandata_ingest", "audio_ingest_transcribe"},
            ) for name in self.handlers
        ]
        self.launcher = ProactiveLauncher(self.root / "launcher", self.policy, self.handlers, capabilities)
        self.scheduler = KCHScheduler(self.root / "scheduler", self.launcher.publish)
        self.launch_receipt = self.launcher.start()
        self.scheduler.start()
        self.clipboard.start_monitor()
        start_event = self.launcher.publish({"type": "session.start", "authority": "KCH_SYSTEM", "runtime_root": str(self.root)})
        self.session_start_result = self.launcher.wait(start_event["event_id"])

    def _checkpoint(self, args: dict[str, Any]) -> dict[str, Any]:
        label = str(args.get("label", "checkpoint")); payload = args.get("payload")
        custody = None
        if payload is not None:
            custody = self.recovery.save_json(f"events/{label}/{uuid.uuid4()}.json", payload, kind="PROACTIVE_EVENT", actor="KCH_SYSTEM", operation="AUTOMATIC_CHECKPOINT")
        return {"custody": custody, "snapshot": self.recovery.snapshot(label)}

    def _chat_create(self, args: dict[str, Any]) -> dict[str, Any]:
        return self.persistence.create_chat(platform=str(args["platform"]), title=str(args.get("title", "")), native_id=args.get("native_id"), source_uri=args.get("source_uri"), capture_mode=str(args.get("capture_mode", "KCH_NATIVE_AUTOMATIC")))

    def _turn_append(self, args: dict[str, Any]) -> dict[str, Any]:
        return self.persistence.append_turn(str(args["chat_id"]), role=str(args["role"]), payload=args["payload"], timestamp=args.get("timestamp"))

    def _kwandata_ingest_model(self, args: dict[str, Any]) -> dict[str, Any]:
        source = str(Path(args["source"]).resolve())
        permission = self.permissions.decide(actor="MODEL", resource="file://external/" + source, operation="READ")
        if not permission["authorized"]: return {"state": "PERMISSION_REQUIRED", "permission": permission}
        return self.kwandata.ingest(source, program_id=args.get("program_id"))

    def _scheduler_create_model(self, args: dict[str, Any]) -> dict[str, Any]:
        permission = self.permissions.decide(actor="MODEL", resource="scheduler://runtime", operation="SCHEDULE")
        if not permission["authorized"]: return {"state": "PERMISSION_REQUIRED", "permission": permission}
        return self.scheduler.create_schedule(name=str(args["name"]), kind=str(args["kind"]), expression=str(args["expression"]), event=dict(args["event"]), agenda_id=str(args.get("agenda_id", "AGENDA-DEFAULT")), timezone=args.get("timezone"), announce=bool(args.get("announce", True)), created_by="MODEL_WITH_PERMISSION")

    def _audio_ingest_model(self, args: dict[str, Any]) -> dict[str, Any]:
        source = str(Path(args["source"]).resolve())
        permission = self.permissions.decide(actor="MODEL", resource="file://external/" + source, operation="READ")
        if not permission["authorized"]: return {"state": "PERMISSION_REQUIRED", "permission": permission}
        return self.audio.ingest_and_transcribe(source, culture=str(args.get("culture", "es-ES")), consent_basis=str(args["consent_basis"]))

    def _voice_notify_model(self, args: dict[str, Any]) -> dict[str, Any]:
        permission = self.permissions.decide(actor="PROACTIVE_LAUNCHER", resource="voice://local/alerts", operation="SPEAK")
        if not permission["authorized"]: return {"state": "PERMISSION_REQUIRED", "permission": permission}
        return self.audio.speak(str(args["text"]), culture=str(args.get("culture", "es-ES")))

    def _on_transcript(self, transcript: dict[str, Any]) -> None:
        resolution = self.diction.resolve(transcript["text"], source_audio_id=transcript["clip_id"])
        self.persistence.append_turn(
            self.voice_chat_id,
            role="user",
            payload={"raw_transcription": transcript["text"], "normalized_transcription": resolution["normalized_transcription"], "resolution": resolution, "audio_clip_id": transcript["clip_id"]},
        )
        if hasattr(self, "launcher"):
            self.launcher.publish({"type": "audio.transcribed", "authority": "KCH_SYSTEM", "transcript": transcript, "diction_resolution": resolution})

    def status(self) -> dict[str, Any]:
        components = {
            "constitution": self.constitution.effective_mandates(),
            "programmed_policy": self.policy.session_announcement(),
            "launcher": self.launcher.status(),
            "recovery": self.recovery.verify(),
            "persistence": self.persistence.coverage(),
            "kwandata": self.kwandata.status(),
            "permissions": self.permissions.status(),
            "scheduler": self.scheduler.status(),
            "clipboard": self.clipboard.status(),
            "accounts": self.account_broker.status(),
            "audio": self.audio.status(),
            "diction": self.diction.status(),
            "mis": self.mis.status(),
            "modes": self.construct.status(),
            "checkpoints": self.checkpoints.status(),
        }
        return {
            "schema": "kch.integrated-pre2g-runtime-status.v0.1.0",
            "components": components,
            "background_launcher_running": components["launcher"]["running"],
            "capability_blind_spots": components["launcher"]["coverage"]["unbound"],
            "phl_real_executed": False,
            "external_installation_performed": False,
        }

    def close(self) -> None:
        self.clipboard.stop_monitor(); self.scheduler.stop(); self.audio.stop_monitor(); self.launcher.stop()
