from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Callable

from .contracts import ArtifactSpec
from .advanced_runtime import ADVANCED_TOOLS, KCHAdvancedRuntime
from .extension import ExtensionFabric, RecommendationEngine, RuntimeInventory
from .installation import ConsentDecision, InstallPlan, IsolatedInstaller
from .studio import Studio


SERVER_INFO = {"name": "kch-csi-studio", "version": "0.1.0"}
PROTOCOL_VERSION = "2025-06-18"


def obj(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {"type": "object", "properties": properties, "required": required, "additionalProperties": False}


STRING = {"type": "string"}
INTEGER = {"type": "integer", "minimum": 1, "maximum": 100}


BASE_TOOLS = [
    {"name": "studio_status", "title": "Inspect CSI Studio", "description": "Inspect Studio, governance, providers, and sessions without changing state.", "inputSchema": obj({}, []), "readOnly": True},
    {"name": "studio_create_session", "title": "Create CSI build session", "description": "Validate and persist a governed artifact specification.", "inputSchema": obj({"spec": {"type": "object"}}, ["spec"]), "readOnly": False},
    {"name": "studio_generate", "title": "Generate staged artifact", "description": "Generate only inside KCH staging; does not install or enable.", "inputSchema": obj({"session_id": STRING}, ["session_id"]), "readOnly": False},
    {"name": "studio_validate", "title": "Validate staged artifact", "description": "Run provider, custody, and ledger validation.", "inputSchema": obj({"session_id": STRING}, ["session_id"]), "readOnly": False},
    {"name": "studio_seal", "title": "Seal candidate", "description": "Seal a validated candidate without installation authority.", "inputSchema": obj({"session_id": STRING}, ["session_id"]), "readOnly": False},
    {"name": "extension_inventory", "title": "Inventory local runtimes", "description": "Read runtime and host availability without reading secrets.", "inputSchema": obj({}, []), "readOnly": True},
    {"name": "extension_search", "title": "Search extension source", "description": "Search a declared provider; search does not download or install.", "inputSchema": obj({"provider": STRING, "query": STRING, "limit": INTEGER}, ["provider", "query"]), "readOnly": True},
    {"name": "extension_recommend", "title": "Adjudicate extension candidates", "description": "Evaluate independent recommendation lanes without a global winner score.", "inputSchema": obj({"records": {"type": "array", "items": {"type": "object"}}, "objective": STRING, "available_runtimes": {"type": "array", "items": STRING}}, ["records", "objective", "available_runtimes"]), "readOnly": True},
    {"name": "isolated_install_plan", "title": "Plan isolated install", "description": "Create a reviewable install and rollback plan; does not execute it.", "inputSchema": obj({"source": STRING, "artifact_kind": STRING, "target_name": STRING}, ["source", "artifact_kind", "target_name"]), "readOnly": True},
    {"name": "isolated_install_execute", "title": "Execute isolated install", "description": "Execute only within the disposable KCH sandbox and only with one of the four explicit consent choices.", "inputSchema": obj({"plan": {"type": "object"}, "consent": {"type": "string", "enum": [item.value for item in ConsentDecision]}}, ["plan", "consent"]), "readOnly": False},
    {"name": "isolated_install_rollback", "title": "Rollback isolated install", "description": "Remove the exact disposable target described by a receipt.", "inputSchema": obj({"receipt": {"type": "object"}}, ["receipt"]), "readOnly": False},
]
TOOLS = [*BASE_TOOLS, *ADVANCED_TOOLS]


class StudioMCP:
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.studio = Studio(self.root / "studio")
        self.fabric = ExtensionFabric(self.root / "extension_fabric")
        self.installer = IsolatedInstaller(self.root / "isolated_installs")
        self.handlers: dict[str, Callable[[dict[str, Any]], Any]] = {
            "studio_status": lambda _args: self.studio.status(),
            "studio_create_session": lambda args: self.studio.create_session(ArtifactSpec.from_dict(dict(args["spec"]))),
            "studio_generate": lambda args: self.studio.generate(str(args["session_id"])),
            "studio_validate": lambda args: self.studio.validate(str(args["session_id"])),
            "studio_seal": lambda args: self.studio.seal(str(args["session_id"])),
            "extension_inventory": lambda _args: RuntimeInventory().collect(),
            "extension_search": lambda args: self.fabric.search(str(args["provider"]), str(args["query"]), int(args.get("limit", 10))),
            "extension_recommend": lambda args: RecommendationEngine().evaluate(args["records"], objective=str(args["objective"]), available_runtimes=args["available_runtimes"]),
            "isolated_install_plan": lambda args: self.installer.plan(args["source"], artifact_kind=str(args["artifact_kind"]), target_name=str(args["target_name"])).to_dict(),
            "isolated_install_execute": self._install,
            "isolated_install_rollback": lambda args: self.installer.rollback(dict(args["receipt"])),
        }
        self.advanced = KCHAdvancedRuntime(
            self.root / "advanced",
            extra_handlers=self.handlers,
            extra_tools=BASE_TOOLS,
        )
        self.handlers.update({name: handler for name, handler in self.advanced.handlers.items() if name not in self.handlers})

    def _install(self, args: dict[str, Any]) -> dict[str, Any]:
        plan_value = dict(args["plan"])
        plan_value["preconditions"] = tuple(plan_value["preconditions"])
        plan_value["rollback"] = tuple(plan_value["rollback"])
        plan = InstallPlan(**plan_value)
        return self.installer.execute(plan, ConsentDecision(str(args["consent"])))

    def call(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if name not in self.handlers:
            raise ValueError(f"unknown tool: {name}")
        value = self.handlers[name](arguments)
        return {
            "content": [{"type": "text", "text": json.dumps(value, ensure_ascii=False, sort_keys=True)}],
            "structuredContent": value,
        }

    def handle(self, message: dict[str, Any]) -> dict[str, Any] | None:
        request_id = message.get("id")
        method = message.get("method")
        if method == "notifications/initialized":
            return None
        try:
            if method == "initialize":
                result: Any = {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {"tools": {}},
                    "serverInfo": SERVER_INFO,
                    "instructions": "KCH governance is HARNESS > AGENTS > RULES. The user constitution and programmed DIRECT rules govern orchestration. PLAN, RUN and CONSTRUCT are distinct; CONSTRUCT changes only a versioned successor. Search is not install. Installation requires four-way consent and remains isolated. Full checkpoints require a size warning and explicit confirmation. PHL real is disabled.",
                }
            elif method == "tools/list":
                result = {
                    "tools": [
                        {
                            "name": tool["name"],
                            "title": tool["title"],
                            "description": tool["description"],
                            "inputSchema": tool["inputSchema"],
                            "annotations": {"readOnlyHint": tool["readOnly"]},
                        }
                        for tool in TOOLS
                    ]
                }
            elif method == "tools/call":
                params = dict(message.get("params", {}))
                result = self.call(str(params.get("name", "")), dict(params.get("arguments", {})))
            elif method == "ping":
                result = {}
            else:
                return {"jsonrpc": "2.0", "id": request_id, "error": {"code": -32601, "message": f"method not found: {method}"}}
            return {"jsonrpc": "2.0", "id": request_id, "result": result}
        except Exception as exc:
            return {"jsonrpc": "2.0", "id": request_id, "error": {"code": -32602, "message": str(exc)}}


def main() -> None:
    root = Path(os.environ.get("KCH_STUDIO_RUNTIME", Path.cwd() / ".kch-studio-runtime"))
    server = StudioMCP(root)
    try:
        for line in sys.stdin:
            if not line.strip():
                continue
            try:
                message = json.loads(line)
                response = server.handle(message)
            except Exception as exc:
                response = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": str(exc)}}
            if response is not None:
                sys.stdout.write(json.dumps(response, ensure_ascii=False, separators=(",", ":")) + "\n")
                sys.stdout.flush()
    finally:
        server.advanced.close()


if __name__ == "__main__":
    main()
