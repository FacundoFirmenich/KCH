from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .contracts import sha256_bytes


class MISService:
    """Full bounded MIS v0.3.1 surface; calculation is not execution authority."""

    def __init__(self, evidence_root: str | Path | None = None):
        candidates = [
            Path(os.environ["KCH_MIS_ROOT"]).resolve() if os.environ.get("KCH_MIS_ROOT") else None,
            Path(evidence_root).resolve() if evidence_root else None,
            Path(__file__).resolve().parents[3] / "KCH_MIS03_REEXTRACT_v0.1.0",
        ]
        self.root = next((path for path in candidates if path and (path / "evidence").is_dir()), None)
        self._adapter: Any | None = None
        self._error: str | None = None

    def _paths(self) -> dict[str, Path]:
        if self.root is None:
            raise FileNotFoundError("MIS v0.3.1 evidence root unavailable")
        return {
            "wheel": self.root / "vendor" / "mis_qualitative_bayes-0.3.1-py3-none-any.whl",
            "corpus": self.root / "evidence" / "KHC_TWO_BATTERY_MASTER_RESULTS_v2.0.7.json",
            "report": self.root / "evidence" / "MIS_v0_3_EXPERIMENT_REPORT.json",
            "ledgers": self.root / "evidence" / "MIS_v0_3_KHC_FUTURE_ONLY_LEDGERS.json",
            "manifest": self.root / "evidence" / "MIS_RELEASE_MANIFEST_v0.3.1.json",
            "historical_certificate": self.root / "results" / "KCH_MIS_V03_HISTORICAL_CERTIFICATE_v0.1.0.json",
            "csi_lowering": self.root / "results" / "KCH_MIS_V03_CSI_LOWERING_v0.1.0.json",
            "gate_result": self.root / "results" / "KCH_MIS_V03_EFFECTIVE_INTEGRATION_RESULT_v0.1.0.json",
        }

    def _load(self) -> Any:
        if self._adapter is not None:
            return self._adapter
        try:
            from kch_mis_v03_integration import MISV03Adapter
            self._adapter = MISV03Adapter(**{key: value for key, value in self._paths().items() if key in {"wheel", "corpus", "report", "ledgers", "manifest"}})
            return self._adapter
        except Exception as exc:
            self._error = f"{type(exc).__name__}: {exc}"
            raise

    def status(self) -> dict[str, Any]:
        paths: dict[str, Path] = {}
        missing: list[str] = []
        if self.root is not None:
            paths = self._paths()
            missing = [key for key, path in paths.items() if not path.is_file()]
        adapter_available = False
        if not missing and self.root is not None:
            try:
                self._load(); adapter_available = True
            except Exception:
                adapter_available = False
        return {
            "schema": "kch.mis.full-service-status.v0.1.0",
            "root": None if self.root is None else str(self.root),
            "evidence_files": {key: {"path": str(path), "available": path.is_file()} for key, path in paths.items()},
            "missing": missing,
            "adapter_available": adapter_available,
            "adapter_error": self._error,
            "surface": ["status", "describe", "exact_decide", "audit_historical_khc", "verify_certificate", "csi_lowering"],
            "KCH_0_11_original_surface": ["certificate.verify"],
            "integration_assessment": "MATHEMATICS_REAL_KCH_0_11_DAILY_SURFACE_PREVIOUSLY_AMPUTATED",
            "authority_created": False,
            "execution_authorized": False,
            "phl_real_executed": False,
        }

    def describe(self) -> dict[str, Any]:
        return self._load().describe()

    def exact_decide(self, request: dict[str, Any]) -> dict[str, Any]:
        return self._load().exact_decide(request)

    def audit_historical(self) -> dict[str, Any]:
        return self._load().audit_historical_khc()

    def verify_certificate(self, certificate: dict[str, Any] | None = None) -> dict[str, Any]:
        if certificate is None:
            path = self._paths()["historical_certificate"]
            certificate = json.loads(path.read_text(encoding="utf-8-sig"))
        return self._load().verify_certificate(certificate)

    def csi_lowering(self) -> dict[str, Any]:
        path = self._paths()["csi_lowering"]
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        observed = sha256_bytes(json.dumps(value["raw_csi_program"], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"))
        if observed != value["raw_csi_program_sha256"]:
            raise ValueError("MIS CSI lowering hash mismatch")
        return {
            **value,
            "operational_assessment": "BOUNDED_FOUR_INSTRUCTION_DECLARATIVE_LOWERING_NOT_FULL_KCH_GOVERNANCE",
        }

