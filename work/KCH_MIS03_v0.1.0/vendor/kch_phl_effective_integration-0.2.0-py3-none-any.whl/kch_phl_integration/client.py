from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any
from uuid import uuid4

from .service import ConflictError, IntegrationError


class IntegrationClient:
    def __init__(self, base_url: str, token: str, client_id: str, client_instance_id: str):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.identity = {"client_id": client_id, "client_instance_id": client_instance_id}
        self.head_hash: str | None = None

    def _request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            self.base_url + path,
            data=body,
            method=method,
            headers={"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                data = json.loads(exc.read().decode("utf-8"))
                if exc.code == 409:
                    raise ConflictError(data["error"]) from exc
                raise IntegrationError(data.get("error", f"HTTP {exc.code}")) from exc
            finally:
                exc.close()

    def refresh(self) -> dict[str, Any]:
        result = self._request("GET", "/v1/projection")
        self.head_hash = result["head_hash"]
        return result

    def _write(self, path: str, payload: dict[str, Any], request_id: str | None = None) -> dict[str, Any]:
        if self.head_hash is None:
            self.refresh()
        envelope = {
            "client": self.identity,
            "request_id": request_id or str(uuid4()),
            "expected_head_hash": self.head_hash,
            "payload": payload,
        }
        result = self._request("POST", path, envelope)
        self.head_hash = result["resulting_head_hash"]
        return result

    def register_decision(self, decision: dict[str, Any], request_id: str | None = None) -> dict[str, Any]:
        return self._write("/v1/decisions", decision, request_id)

    def start_phl(self, trigger: str = "USER_EXPLICIT_WORKBENCH_START", request_id: str | None = None) -> dict[str, Any]:
        return self._write("/v1/phl/start", {"trigger": trigger}, request_id)

    def close_phl(self, session_id: str, request_id: str | None = None) -> dict[str, Any]:
        return self._write("/v1/phl/close", {"session_id": session_id}, request_id)
